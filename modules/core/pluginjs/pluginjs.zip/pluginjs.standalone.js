(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
	typeof define === 'function' && define.amd ? define(['exports'], factory) :
	(factory((global['@pluginjs/pluginjs'] = {})));
}(this, (function (exports) { 'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) {
  return typeof obj;
} : function (obj) {
  return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
};





var asyncGenerator = function () {
  function AwaitValue(value) {
    this.value = value;
  }

  function AsyncGenerator(gen) {
    var front, back;

    function send(key, arg) {
      return new Promise(function (resolve, reject) {
        var request = {
          key: key,
          arg: arg,
          resolve: resolve,
          reject: reject,
          next: null
        };

        if (back) {
          back = back.next = request;
        } else {
          front = back = request;
          resume(key, arg);
        }
      });
    }

    function resume(key, arg) {
      try {
        var result = gen[key](arg);
        var value = result.value;

        if (value instanceof AwaitValue) {
          Promise.resolve(value.value).then(function (arg) {
            resume("next", arg);
          }, function (arg) {
            resume("throw", arg);
          });
        } else {
          settle(result.done ? "return" : "normal", result.value);
        }
      } catch (err) {
        settle("throw", err);
      }
    }

    function settle(type, value) {
      switch (type) {
        case "return":
          front.resolve({
            value: value,
            done: true
          });
          break;

        case "throw":
          front.reject(value);
          break;

        default:
          front.resolve({
            value: value,
            done: false
          });
          break;
      }

      front = front.next;

      if (front) {
        resume(front.key, front.arg);
      } else {
        back = null;
      }
    }

    this._invoke = send;

    if (typeof gen.return !== "function") {
      this.return = undefined;
    }
  }

  if (typeof Symbol === "function" && Symbol.asyncIterator) {
    AsyncGenerator.prototype[Symbol.asyncIterator] = function () {
      return this;
    };
  }

  AsyncGenerator.prototype.next = function (arg) {
    return this._invoke("next", arg);
  };

  AsyncGenerator.prototype.throw = function (arg) {
    return this._invoke("throw", arg);
  };

  AsyncGenerator.prototype.return = function (arg) {
    return this._invoke("return", arg);
  };

  return {
    wrap: function (fn) {
      return function () {
        return new AsyncGenerator(fn.apply(this, arguments));
      };
    },
    await: function (value) {
      return new AwaitValue(value);
    }
  };
}();





var classCallCheck = function (instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
};

var createClass = function () {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  return function (Constructor, protoProps, staticProps) {
    if (protoProps) defineProperties(Constructor.prototype, protoProps);
    if (staticProps) defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();





var defineProperty = function (obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
};

var _extends = Object.assign || function (target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];

    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }

  return target;
};



var inherits = function (subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      enumerable: false,
      writable: true,
      configurable: true
    }
  });
  if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
};









var objectWithoutProperties = function (obj, keys) {
  var target = {};

  for (var i in obj) {
    if (keys.indexOf(i) >= 0) continue;
    if (!Object.prototype.hasOwnProperty.call(obj, i)) continue;
    target[i] = obj[i];
  }

  return target;
};

var possibleConstructorReturn = function (self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return call && (typeof call === "object" || typeof call === "function") ? call : self;
};





var slicedToArray = function () {
  function sliceIterator(arr, i) {
    var _arr = [];
    var _n = true;
    var _d = false;
    var _e = undefined;

    try {
      for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
        _arr.push(_s.value);

        if (i && _arr.length === i) break;
      }
    } catch (err) {
      _d = true;
      _e = err;
    } finally {
      try {
        if (!_n && _i["return"]) _i["return"]();
      } finally {
        if (_d) throw _e;
      }
    }

    return _arr;
  }

  return function (arr, i) {
    if (Array.isArray(arr)) {
      return arr;
    } else if (Symbol.iterator in Object(arr)) {
      return sliceIterator(arr, i);
    } else {
      throw new TypeError("Invalid attempt to destructure non-iterable instance");
    }
  };
}();













var toConsumableArray = function (arr) {
  if (Array.isArray(arr)) {
    for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) arr2[i] = arr[i];

    return arr2;
  } else {
    return Array.from(arr);
  }
};

var Emitter = function () {
  function Emitter() {
    classCallCheck(this, Emitter);

    this.listeners = {};
    this.sortedListeners = {};
  }

  createClass(Emitter, [{
    key: 'emit',
    value: function emit(event) {
      var listeners = this.getListeners(event);

      for (var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }

      for (var i = 0; i < listeners.length; i++) {
        var context = null;

        if (listeners[i].context !== null) {
          context = listeners[i].context;
        } else {
          context = { type: event };
        }

        var result = listeners[i].listener.apply(context, args);

        if (result === false) {
          return false;
        }
      }

      return true;
    }
  }, {
    key: 'on',
    value: function on(event, listener, context, priority) {
      return this.addListener(event, listener, context, priority);
    }
  }, {
    key: 'once',
    value: function once(event, listener, context, priority) {
      return this.addOneTimeListener(event, listener, context, priority);
    }
  }, {
    key: 'off',
    value: function off(event, listener) {
      if (typeof listener === 'undefined') {
        return this.removeAllListeners(event);
      }

      return this.removeListener(event, listener);
    }

    /* Lower numbers correspond with earlier execution,
    /* and functions with the same priority are executed
    /* in the order in which they were added to the action. */

  }, {
    key: 'addListener',
    value: function addListener(event, listener) {
      var context = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;
      var priority = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 10;

      this.ensureListener(listener);

      if (!this.listeners[event]) {
        this.listeners[event] = {};
      }
      if (!this.listeners[event][priority]) {
        this.listeners[event][priority] = [];
      }

      this.listeners[event][priority].push({
        context: context,
        listener: listener
      });
      this.clearSortedListeners(event);

      return this;
    }
  }, {
    key: 'addOneTimeListener',
    value: function addOneTimeListener(event, listener, context) {
      var priority = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 10;

      var that = this;
      function wrapper() {
        that.removeListener(event, wrapper);

        return listener.apply(undefined, arguments);
      }

      this.addListener(event, wrapper, context, priority);

      return this;
    }
  }, {
    key: 'removeListener',
    value: function removeListener(event, listener) {
      this.clearSortedListeners(event);
      var listeners = this.hasListeners(event) ? this.listeners[event] : [];

      for (var priority in listeners) {
        if (Object.prototype.hasOwnProperty.call(listeners, priority)) {
          listeners[priority] = listeners[priority].filter(function (value) {
            return value.listener !== listener;
          });

          if (listeners[priority].length === 0) {
            delete listeners[priority];
          }
        }
      }

      this.listeners[event] = listeners;

      return this;
    }
  }, {
    key: 'removeAllListeners',
    value: function removeAllListeners(event) {
      this.clearSortedListeners(event);

      if (this.hasListeners(event)) {
        delete this.listeners[event];
      }

      return this;
    }
  }, {
    key: 'ensureListener',
    value: function ensureListener(listener) {
      var type = typeof listener === 'undefined' ? 'undefined' : _typeof(listener);
      if (type === 'function') {
        return listener;
      }
      throw new TypeError('Listeners should be function or closure. Received type: ' + type);
    }
  }, {
    key: 'hasListeners',
    value: function hasListeners(event) {
      if (!this.listeners[event] || Object.keys(this.listeners[event]).length === 0) {
        return false;
      }

      return true;
    }
  }, {
    key: 'getListeners',
    value: function getListeners(event) {
      if (!this.sortedListeners.hasOwnProperty(event)) {
        this.sortedListeners[event] = this.getSortedListeners(event);
      }

      return this.sortedListeners[event];
    }
  }, {
    key: 'getSortedListeners',
    value: function getSortedListeners(event) {
      if (!this.hasListeners(event)) {
        return [];
      }

      var listeners = this.listeners[event];

      var priorities = Object.keys(listeners);
      priorities.sort(function (a, b) {
        return a - b;
      });

      var sortedlisteners = [];
      for (var i = 0; i < priorities.length; i++) {
        sortedlisteners = sortedlisteners.concat(listeners[priorities[i]]);
      }

      return sortedlisteners;
    }
  }, {
    key: 'clearSortedListeners',
    value: function clearSortedListeners(event) {
      delete this.sortedListeners[event];
    }
  }]);
  return Emitter;
}();

var Plugin = function () {
  function Plugin(namespace, element) {
    classCallCheck(this, Plugin);

    this.plugin = namespace;
    this.element = element;
    if (window.Pj && window.Pj.instances[this.plugin]) {
      window.Pj.instances[this.plugin].push(this);
    }
  }

  createClass(Plugin, [{
    key: 'getDataOptions',
    value: function getDataOptions() {
      var _this = this;

      var data = this.element.dataset;
      var length = Object.keys(data).length;
      var newData = {};

      if (length > 0) {
        Object.entries(data).forEach(function (_ref) {
          var _ref2 = slicedToArray(_ref, 2),
              name = _ref2[0],
              content = _ref2[1];

          var cache = {};
          var items = name.split('-');
          // let items = name.split('-');

          var deep = items.length;

          if (deep > 1) {
            for (var j = 0; j < deep; j++) {
              var item = items[j].substring(0, 1).toLowerCase() + items[j].substring(1);

              if (j === 0) {
                cache[item] = {};
              } else if (j === deep - 1) {} else {}
            }
          } else if (items[0] === 'as' + _this.plugin.substring(0, 1).toUpperCase() + _this.plugin.substring(1)) {
            cache = content;
          } else {
            cache[name] = content;
          }

          Object.assign(newData, cache);
        });
      }

      return newData;
    }
  }, {
    key: 'destroy',
    value: function destroy() {
      var _this2 = this;

      this.plugin = null;
      this.element = null;
      if (window.Pj && window.Pj.instances[this.plugin]) {
        window.Pj.instances[this.plugin] = window.Pj.instances[this.plugin].filter(function (plugin) {
          return plugin.element === _this2.element;
        });
      }
    }
  }], [{
    key: 'of',
    value: function of() {
      for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      return new (Function.prototype.bind.apply(this, [null].concat(args)))();
    }
  }]);
  return Plugin;
}();

var GlobalComponent = function (_Plugin) {
  inherits(GlobalComponent, _Plugin);

  function GlobalComponent(namespace) {
    classCallCheck(this, GlobalComponent);

    var _this3 = possibleConstructorReturn(this, (GlobalComponent.__proto__ || Object.getPrototypeOf(GlobalComponent)).call(this, namespace, window.Pj.doc));

    if (!window.Pj.instances[_this3.plugin]) {
      return possibleConstructorReturn(_this3);
    }
    _this3.instanceId = window.Pj.instances[_this3.plugin].length + 1;
    window.Pj.instances[_this3.plugin].push(_this3);
    return _this3;
  }

  createClass(GlobalComponent, [{
    key: 'destroy',
    value: function destroy() {
      var _this4 = this;

      window.Pj.instances[this.plugin] = window.Pj.instances[this.plugin].filter(function (instance) {
        return instance !== _this4;
      });
      window.Pj[this.plugin] = null;
    }
  }]);
  return GlobalComponent;
}(Plugin);

var asyncGenerator$1 = function () {
  function AwaitValue(value) {
    this.value = value;
  }

  function AsyncGenerator(gen) {
    var front, back;

    function send(key, arg) {
      return new Promise(function (resolve, reject) {
        var request = {
          key: key,
          arg: arg,
          resolve: resolve,
          reject: reject,
          next: null
        };

        if (back) {
          back = back.next = request;
        } else {
          front = back = request;
          resume(key, arg);
        }
      });
    }

    function resume(key, arg) {
      try {
        var result = gen[key](arg);
        var value = result.value;

        if (value instanceof AwaitValue) {
          Promise.resolve(value.value).then(function (arg) {
            resume("next", arg);
          }, function (arg) {
            resume("throw", arg);
          });
        } else {
          settle(result.done ? "return" : "normal", result.value);
        }
      } catch (err) {
        settle("throw", err);
      }
    }

    function settle(type, value) {
      switch (type) {
        case "return":
          front.resolve({
            value: value,
            done: true
          });
          break;

        case "throw":
          front.reject(value);
          break;

        default:
          front.resolve({
            value: value,
            done: false
          });
          break;
      }

      front = front.next;

      if (front) {
        resume(front.key, front.arg);
      } else {
        back = null;
      }
    }

    this._invoke = send;

    if (typeof gen.return !== "function") {
      this.return = undefined;
    }
  }

  if (typeof Symbol === "function" && Symbol.asyncIterator) {
    AsyncGenerator.prototype[Symbol.asyncIterator] = function () {
      return this;
    };
  }

  AsyncGenerator.prototype.next = function (arg) {
    return this._invoke("next", arg);
  };

  AsyncGenerator.prototype.throw = function (arg) {
    return this._invoke("throw", arg);
  };

  AsyncGenerator.prototype.return = function (arg) {
    return this._invoke("return", arg);
  };

  return {
    wrap: function wrap(fn) {
      return function () {
        return new AsyncGenerator(fn.apply(this, arguments));
      };
    },
    await: function _await(value) {
      return new AwaitValue(value);
    }
  };
}();

var _extends$1 = Object.assign || function (target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];

    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }

  return target;
};

function nub(arr) {
  return Array.from(new Set(arr));
}
function isPaintObject(data) {
  if ((typeof data === "undefined" ? "undefined" : _typeof(data)) !== 'object') {
    return false;
  }

  if (data === null) {
    return false;
  }

  if (data instanceof Set || data instanceof Map) {
    return false;
  }

  if (Array.isArray(data)) {
    return false;
  }

  return true;
}
function deepMergeTwo(x, y) {
  if (isPaintObject(y) && isPaintObject(x) || isPaintObject(x) && Array.isArray(y)) {
    return fromPairs(nub(Object.keys(x).concat(Object.keys(y))).map(function (key) {
      return [key, deepMergeTwo(x[key], y[key])];
    }));
  }

  if (isPaintObject(y) && typeof x === 'function') {
    return Object.assign(function () {
      for (var _len2 = arguments.length, args = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
        args[_key2] = arguments[_key2];
      }

      return x.apply(this, args);
    }, y);
  }

  if (isPaintObject(y) && Array.isArray(x)) {
    return Object.assign([], x, y);
  }

  if (isPaintObject(x) && typeof y === 'function') {
    return Object.assign(function () {
      for (var _len3 = arguments.length, args = Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
        args[_key3] = arguments[_key3];
      }

      return y.apply(this, args);
    }, x);
  }

  if (Array.isArray(y) && Array.isArray(x)) {
    // return x.concat(y)
    return nub(Object.keys(y).concat(Object.keys(x))).map(function (index) {
      return deepMergeTwo(x[index], y[index]);
    });
  }

  if (typeof y === 'undefined') {
    return x;
  }
  return y;
}
function isObject(obj) {
  return Object(obj) === obj;
}
function deepMerge() {
  for (var _len4 = arguments.length, args = Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
    args[_key4] = arguments[_key4];
  }

  return args.filter(isObject).reduce(deepMergeTwo);
}

var curry = function curry(fn) {
  var args = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
  return function () {
    for (var _len5 = arguments.length, subArgs = Array(_len5), _key5 = 0; _key5 < _len5; _key5++) {
      subArgs[_key5] = arguments[_key5];
    }

    var currylen = fn.currylen || fn.length;
    var collect = args.concat(subArgs);
    if (collect.length >= currylen) {
      return fn.apply(undefined, toConsumableArray(collect));
    }
    return curry(fn, collect);
  };
};

var compose = function compose() {
  for (var _len6 = arguments.length, fn = Array(_len6), _key6 = 0; _key6 < _len6; _key6++) {
    fn[_key6] = arguments[_key6];
  }

  var callback = function callback() {
    for (var _len7 = arguments.length, args = Array(_len7), _key7 = 0; _key7 < _len7; _key7++) {
      args[_key7] = arguments[_key7];
    }

    return fn.reduceRight(function (r, i, index) {
      if (Array.isArray(r) && index === fn.length - 1) {
        return i.apply(undefined, toConsumableArray(r));
      }
      return i(r);
    }, args);
  };
  callback.currylen = fn[fn.curylen || fn.length - 1].length;
  return callback;
};

function camelize(word) {
  var first = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;

  word = word.replace(/[_.-\s](\w|$)/g, function (_, x) {
    return x.toUpperCase();
  });

  if (first) {
    word = word.substring(0, 1).toUpperCase() + word.substring(1);
  }
  return word;
}

/* Credit to https://github.com/jonschlinkert/get-value MIT */
function getValueByPath(obj, path) {
  if (Object(obj) !== obj || typeof path === 'undefined') {
    return obj;
  }

  if (path in obj) {
    return obj[path];
  }

  var segs = path.split('.');
  var length = segs.length;
  if (!length) {
    return undefined;
  }
  var i = -1;

  while (obj && ++i < length) {
    var key = segs[i];
    while (key[key.length - 1] === '\\') {
      key = key.slice(0, -1) + "." + segs[++i];
    }
    obj = obj[key];
  }
  return obj;
}

/* Throttle execution of a function.
 * Especially useful for rate limiting execution of
 * handlers on events like resize and scroll. */
function throttle(func, delay) {
  var _this = this;

  var running = false;
  function resetRunning() {
    running = false;
  }

  if (delay !== undefined || delay !== null) {
    return function () {
      for (var _len8 = arguments.length, args = Array(_len8), _key8 = 0; _key8 < _len8; _key8++) {
        args[_key8] = arguments[_key8];
      }

      var that = _this;

      if (running) {
        return;
      }
      running = true;
      func.apply(that, args);
      window.setTimeout(resetRunning, delay);
    };
  }

  return function () {
    for (var _len9 = arguments.length, args = Array(_len9), _key9 = 0; _key9 < _len9; _key9++) {
      args[_key9] = arguments[_key9];
    }

    var that = _this;

    if (running) {
      return;
    }
    running = true;
    window.requestAnimationFrame(function () {
      func.apply(that, args);
      resetRunning();
    });
  };
}

function fromPairs(arr) {
  return arr.reduce(function (r, _ref10) {
    var _ref11 = slicedToArray(_ref10, 2),
        k = _ref11[0],
        v = _ref11[1];

    return _extends$1({}, r, defineProperty({}, k, v));
  }, {});
}

var asyncGenerator$2 = function () {
  function AwaitValue(value) {
    this.value = value;
  }

  function AsyncGenerator(gen) {
    var front, back;

    function send(key, arg) {
      return new Promise(function (resolve, reject) {
        var request = {
          key: key,
          arg: arg,
          resolve: resolve,
          reject: reject,
          next: null
        };

        if (back) {
          back = back.next = request;
        } else {
          front = back = request;
          resume(key, arg);
        }
      });
    }

    function resume(key, arg) {
      try {
        var result = gen[key](arg);
        var value = result.value;

        if (value instanceof AwaitValue) {
          Promise.resolve(value.value).then(function (arg) {
            resume("next", arg);
          }, function (arg) {
            resume("throw", arg);
          });
        } else {
          settle(result.done ? "return" : "normal", result.value);
        }
      } catch (err) {
        settle("throw", err);
      }
    }

    function settle(type, value) {
      switch (type) {
        case "return":
          front.resolve({
            value: value,
            done: true
          });
          break;

        case "throw":
          front.reject(value);
          break;

        default:
          front.resolve({
            value: value,
            done: false
          });
          break;
      }

      front = front.next;

      if (front) {
        resume(front.key, front.arg);
      } else {
        back = null;
      }
    }

    this._invoke = send;

    if (typeof gen.return !== "function") {
      this.return = undefined;
    }
  }

  if (typeof Symbol === "function" && Symbol.asyncIterator) {
    AsyncGenerator.prototype[Symbol.asyncIterator] = function () {
      return this;
    };
  }

  AsyncGenerator.prototype.next = function (arg) {
    return this._invoke("next", arg);
  };

  AsyncGenerator.prototype.throw = function (arg) {
    return this._invoke("throw", arg);
  };

  AsyncGenerator.prototype.return = function (arg) {
    return this._invoke("return", arg);
  };

  return {
    wrap: function wrap(fn) {
      return function () {
        return new AsyncGenerator(fn.apply(this, arguments));
      };
    },
    await: function _await(value) {
      return new AwaitValue(value);
    }
  };
}();

/* Credit to https://github.com/jonschlinkert/get-value MIT */
function getValueByPath$1(obj, path) {
  if (Object(obj) !== obj || typeof path === 'undefined') {
    return obj;
  }

  if (path in obj) {
    return obj[path];
  }

  var segs = path.split('.');
  var length = segs.length;
  if (!length) {
    return undefined;
  }
  var i = -1;

  while (obj && ++i < length) {
    var key = segs[i];
    while (key[key.length - 1] === '\\') {
      key = key.slice(0, -1) + "." + segs[++i];
    }
    obj = obj[key];
  }
  return obj;
}

/* Credit to https://github.com/Matt-Esch/string-template MIT */
var template = function () {
  var pattern = /\{\s*([.0-9a-zA-Z_]+)\s*\}/g;

  function render(string) {
    for (var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
      args[_key - 1] = arguments[_key];
    }

    if (args.length === 1 && _typeof(args[0]) === 'object') {
      args = args[0];
    }

    if (!args || !args.hasOwnProperty) {
      args = {};
    }

    return string.replace(pattern, function (match, i, index) {
      var result = null;

      if (string[index - 1] === '{' && string[index + match.length] === '}') {
        return i;
      }

      if (args.hasOwnProperty(i)) {
        result = args[i];
      } else if (i.indexOf('.') !== -1) {
        result = getValueByPath$1(args, i);
      }

      if (result === null || result === undefined) {
        return '';
      }

      return result;
    });
  }

  return {
    render: render,
    compile: function compile(str) {
      return function () {
        for (var _len2 = arguments.length, args = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
          args[_key2] = arguments[_key2];
        }

        return render.apply(undefined, [str].concat(args));
      };
    },
    parse: function parse(str) {
      var matches = str.match(pattern);

      if (matches === null) {
        return false;
      }

      var parsed = [];
      for (var i = 0; i < matches.length; i++) {
        if (!matches[i].match(/^\{\{.+\}\}$/g)) {
          parsed.push(matches[i].substring(1, matches[i].length - 1).trim());
        }
      }

      return parsed;
    }
  };
}();

var I18N = function () {
  function I18N(defaults$$1, translations) {
    classCallCheck(this, I18N);

    this.defaults = deepMerge({}, I18N.defaults, defaults$$1);

    this.translations = translations ? translations : {};
  }

  createClass(I18N, [{
    key: 'hasTranslation',
    value: function hasTranslation(locale) {
      return locale in this.translations;
    }
  }, {
    key: 'addTranslation',
    value: function addTranslation(locale, translation) {
      if (this.translations[locale]) {
        Object.assign(this.translations[locale], translation);
      } else {
        this.translations[locale] = translation;
      }
    }
  }, {
    key: 'getTranslation',
    value: function getTranslation(locale) {
      if (this.translations[locale]) {
        return this.translations[locale];
      }
      return {};
    }
  }, {
    key: 'instance',
    value: function instance() {
      var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      var that = this;

      var _options = Object.assign({}, that.defaults, options);
      var _locale = _options.locale;

      function getMessage(key, locale) {
        var translation = that.getTranslation(locale);
        var message = getValueByPath(translation, key);

        return message;
      }

      return {
        translate: function translate(key) {
          var args = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
          var locale = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : _locale;

          var message = getMessage(key, locale);

          if (message === undefined && _options.fallbacks) {
            var locales = locale.split('-');
            if (locales.length > 1 && that.hasTranslation(locales[0])) {
              message = getMessage(key, locales[0]);
            }

            if (message === undefined) {
              var fallbackLocale = void 0;
              if (_options.fallbacks !== true && that.hasTranslation(_options.fallbacks)) {
                fallbackLocale = _options.fallbacks;
              } else {
                fallbackLocale = that.defaults.locale;
              }

              message = getMessage(key, fallbackLocale);
            }
          }

          if (Object.prototype.toString.call(message) === '[object Array]' && message.length >= 2) {
            if (typeof args._number === 'string') {
              if (typeof args[args._number] !== 'undefined') {
                var _number = parseInt(args[args._number], 10);

                if (_number === 1) {
                  message = message[0];
                } else if (_number > 1) {
                  message = message[1];
                } else if (_number === 0 && message.length >= 3) {
                  message = message[2];
                }
              }
            }
          }

          if (typeof message === 'string') {
            var parsed = template.parse(message);
            if (!parsed) {
              return message;
            }
            var _key = void 0;
            for (var i = 0; i < parsed.length; i++) {
              _key = parsed[i];
              if (typeof args[_key] === 'undefined') {
                args[_key] = _options.missingPlaceholder(_key);
              } else if (args[_key] === null) {
                args[_key] = _options.nullPlaceholder(_key);
              }
            }
            return template.render(message, args);
          }

          if (Object(message) === message) {
            return message;
          }

          return '[missing "' + locale + '.' + key + '" translation]';
        },
        setLocale: function setLocale(locale) {
          _locale = locale;
        },
        getLocale: function getLocale() {
          return _locale;
        }
      };
    }
  }, {
    key: 'setTranslations',
    value: function setTranslations(translations) {
      this.translations = translations;
    }
  }]);
  return I18N;
}();

I18N.defaults = {
  locale: 'en',
  fallbacks: true,
  nullPlaceholder: function nullPlaceholder(key) {
    return '[missing {{' + key + '}} value]';
  },
  missingPlaceholder: function missingPlaceholder(key) {
    return '[missing {{' + key + '}} value]';
  }
};

/*eslint-disable */
/* Credit to http://is.js.org MIT */
var toString = Object.prototype.toString;
var is = {
  // Type checks
  /* -------------------------------------------------------------------------- */
  // is a given value Arguments?
  arguments: function _arguments(value) {
    // fallback check is for IE
    return toString.call(value) === '[object Arguments]' || value != null && (typeof value === 'undefined' ? 'undefined' : _typeof(value)) === 'object' && 'callee' in value;
  },

  // is a given value Array?
  array: function array(val) {
    if (Array.isArray) {
      return Array.isArray(val);
    }
    return toString.call(val) === '[object Array]';
  },

  // is a given value Boolean?
  boolean: function boolean(val) {
    return val === true || val === false || toString.call(val) === '[object Boolean]';
  },

  // is a given value Char?
  char: function char(val) {
    return this.string(val) && val.length === 1;
  },

  // is a given value Date Object?
  date: function date(value) {
    return toString.call(value) === '[object Date]';
  },

  // is a given object a DOM node?
  domNode: function domNode(object) {
    return this.object(object) && object.nodeType > 0;
  },

  // is a given value Error object?
  error: function error(val) {
    return toString.call(val) === '[object Error]';
  },

  // is a given value function?
  function: function _function(val) {
    // fallback check is for IE
    return toString.call(val) === '[object Function]' || typeof val === 'function';
  },

  // is given value a pure JSON object?
  json: function json(value) {
    return toString.call(value) === '[object Object]';
  },

  // is a given value NaN?
  nan: function nan(val) {
    // NaN is number :) Also it is the only value which does not equal itself
    return val !== val;
  },

  // is a given value null?
  null: function _null(val) {
    return val === null;
  },

  // is a given value number?
  number: function number(val) {
    return !this.nan(val) && toString.call(val) === '[object Number]';
  },

  // is a given value object?
  object: function object(val) {
    return Object(val) === val;
  },

  // is a given value empty object?
  emptyObject: function emptyObject(val) {
    return this.object(val) && Object.getOwnPropertyNames(val).length == 0;
  },

  // is a given value RegExp?
  regexp: function regexp(val) {
    return toString.call(val) === '[object RegExp]';
  },

  // is a given value String?
  string: function string(val) {
    return typeof val === 'string' || toString.call(val) === '[object String]';
  },

  // is a given value undefined?
  undefined: function undefined(val) {
    return val === void 0;
  },

  // Arithmetic checks
  /* -------------------------------------------------------------------------- */
  // is a given value numeric?
  numeric: function numeric(n) {
    return (this.number(n) || this.string(n)) && !this.nan(n - parseFloat(n));
  },

  // is a given number percentage?
  percentage: function percentage(n) {
    return typeof n === 'string' && n.indexOf('%') !== -1;
  },

  // is a given number decimal?
  decimal: function decimal(n) {
    return this.number(n) && n % 1 !== 0;
  },

  // is a given number finite?
  finite: function finite(n) {
    if (isFinite) {
      return isFinite(n);
    }
    return !this.infinite(n) && !this.nan(n);
  },

  // is a given number infinite?
  infinite: function infinite(n) {
    return n === Infinity || n === -Infinity;
  },

  integer: function integer(n) {
    return this.number(n) && n % 1 === 0;
  },

  // is a given number negative?
  negative: function negative(n) {
    return this.number(n) && n < 0;
  },

  // is a given number positive?
  positive: function positive(n) {
    return this.number(n) && n > 0;
  }
};

var find = curry(function (selector, parent) {
  return parent.querySelector(selector);
});

var finds = curry(function (selector, parent) {
  return Array.from(parent.querySelectorAll(selector));
});

var remove = function remove(el) {
  return el.remove();
};

var html = curry(function (content, el) {
  el.innerHTML = content;
  return el;
});

var children = function children(el) {
  return Array.from(el.children);
};















var parent = function parent(el) {
  return el.parentNode;
};
// 解析 HTML/SVG/XML 字符串
var parseHTML = function parseHTML() {
  for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }

  var htmlString = Array.isArray(args[0]) ? args[0].reduce(function (result, str, index) {
    return result + args[index] + str;
  }) : args[0];
  var childNodes = compose(children, html(htmlString))(document.createElement('div'));
  if (childNodes.length === 1) {
    return childNodes[0];
  }
  return childNodes;
};











var next = function next(el) {
  return el.nextElementSibling;
};

var attr = curry(function (args, el) {
  if (typeof args === 'string') {
    return el.getAttribute(args);
  }
  Object.entries(args).forEach(function (_ref5) {
    var _ref6 = slicedToArray(_ref5, 2),
        k = _ref6[0],
        v = _ref6[1];

    return el.setAttribute(k, v);
  });
  return el;
});
var removeAttribute = curry(function (name, el) {
  return el.removeAttribute(name);
});

var dataset = curry(function (args, el) {
  if (typeof args === 'string') {
    return el.dataset[args];
  }
  Object.entries(args).forEach(function (_ref7) {
    var _ref8 = slicedToArray(_ref7, 2),
        k = _ref8[0],
        v = _ref8[1];

    el.dataset[k] = v;
  });
  return el;
});

var text = curry(function (content, el) {
  el.textContent = content;
  return el;
});

var append = curry(function (child, el) {
  if (is.string(child)) {
    el.insertAdjacentHTML('beforeend', child);
  } else {
    el.append(child);
  }
  return el;
});

var prepend = curry(function (child, el) {
  if (is.string(child)) {
    el.insertAdjacentHTML('afterbegin', child);
  } else {
    el.prepend(child);
  }
  return el;
});

var insertBefore = curry(function (newElement, el) {
  if (is.string(newElement)) {
    el.insertAdjacentHTML('beforebegin', newElement);
  } else {
    el.insertAdjacentElement('beforebegin', newElement);
  }
  return el;
});

var insertAfter = curry(function (newElement, el) {
  if (is.string(newElement)) {
    el.insertAdjacentHTML('afterend', newElement);
  } else {
    el.insertAdjacentElement('afterend', newElement);
  }
  return el;
});

var wrap = curry(function (wrapElement, el) {
  if (is.string(wrapElement)) {
    wrapElement = parseHTML(wrapElement);
  }
  // compose(append(wrapElement), clone, insertBefore(wrapElement))(el)
  insertBefore(wrapElement, el);
  remove(el);
  append(el, wrapElement);
  return wrapElement;
});









var parentWith = curry(function (fn, el) {
  var parentElement = parent(el);
  if (parentElement === document) {
    return false;
  }
  if (fn(parentElement)) {
    return parentElement;
  }
  return parentWith(fn, parentElement);
});



var contains = curry(function (el, parent) {
  return parent.contains(el);
});

var closest = curry(function (selector, el) {
  if (el.matches(selector)) {
    return el;
  }
  return parentWith(function (el) {
    return el.matches(selector);
  }, el);
});

var nextElementWith = curry(function (fn, el) {
  var nextElement = next(el);
  if (fn(nextElement)) {
    return nextElement;
  }
  return nextElementWith(fn, nextElement);
});

var outputIdentity = function outputIdentity(identity) {
  if (!identity) {
    return { type: 'self', value: '' };
  }
  if (typeof identity === 'string') {
    return { type: 'selector', value: identity };
  }

  return identity;
};

var tupleToStyleSelector = function tupleToStyleSelector(tuple, prefix) {
  if (typeof tuple === 'string') {
    return tuple;
  }
  return Object.entries(tuple).map(function (kv) {
    return '[' + prefix + kv.join('=') + ']';
  }).join('');
};

var dispatch = function dispatch(event) {
  var target = event.target,
      currentTarget = event.currentTarget;

  var eventStorage = EventStorage.getEventStorage(currentTarget);
  var eventName = event.type;

  var attrVerify$$1 = {
    self: function self(node) {
      return node === currentTarget;
    },
    class: function _class(node, value) {
      return node.matches('.' + value);
    },
    selector: function selector(node, value) {
      return node.matches(value);
    },
    id: function id(node, value) {
      return node.matches('#' + value);
    },
    tagName: function tagName(node, value) {
      return node.matches(value);
    },
    dom: function dom(node, value) {
      return node === value;
    },
    dataset: function dataset$$1(node, value) {
      return node.matches(tupleToStyleSelector(value, 'data-'));
    },
    attribute: function attribute(node, value) {
      return node.matches(tupleToStyleSelector(value));
    },
    func: function func(node, value) {
      return Boolean(value(node));
    }
  };

  var nodeTreeCheck = function nodeTreeCheck(node) {
    var result = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];

    if (!currentTarget.contains(node)) {
      return result;
    }

    var matchEventList = eventStorage.listeners[eventName].filter(function (_ref) {
      var identity = _ref.identity;
      var type = identity.type,
          value = identity.value;

      var identityMapper = attrVerify$$1[type];
      if (identityMapper && identityMapper(node, value)) {
        return true;
      }
      return false;
    });
    return nodeTreeCheck(parent(node), result.concat(matchEventList));
  };
  // nodeTreeCheck(target).map(e => console.log(e.handler.toString()))
  nodeTreeCheck(target).reduce(function (result, _ref2) {
    var handler = _ref2.handler;
    return result !== false && handler(event);
  }, true);
};

var EventStorage = function () {
  function EventStorage(element) {
    classCallCheck(this, EventStorage);

    this.element = element;
    this.listeners = {};
  }

  createClass(EventStorage, [{
    key: 'on',
    value: function on(_ref3) {
      var identity = _ref3.identity,
          handler = _ref3.handler,
          eventName = _ref3.eventName,
          namespace = _ref3.namespace;

      this.ensureHandler(handler);

      if (!this.hasListeners(eventName)) {
        this.createEventListener(eventName);
      }

      if (this.checkRepeats(eventName, handler)) {
        return;
      }

      this.listeners[eventName].push({ identity: identity, handler: handler, namespace: namespace });
    }
  }, {
    key: 'once',
    value: function once(_ref4) {
      var _this = this;

      var identity = _ref4.identity,
          handler = _ref4.handler,
          eventName = _ref4.eventName,
          namespace = _ref4.namespace;

      this.ensureHandler(handler);

      if (!this.hasListeners(eventName)) {
        this.createEventListener(eventName);
      }

      var callback = function callback(event) {
        _this.removeListener(eventName, callback);

        return handler(event);
      };

      this.listeners[eventName].push({ identity: identity, handler: callback, namespace: namespace });
    }
  }, {
    key: 'off',
    value: function off(_eventName, handler) {
      if (typeof handler === 'undefined') {
        return this.removeAllListeners(_eventName);
      }
      return this.removeListener(_eventName, handler);
    }
  }, {
    key: 'trigger',
    value: function trigger(eventName, data) {
      var event = new CustomEvent(eventName, {
        detail: data
      });
      this.element.dispatchEvent(event);
    }
  }, {
    key: 'clear',
    value: function clear() {
      var _this2 = this;

      Object.entries(this.listeners).map(function (_ref5) {
        var _ref6 = slicedToArray(_ref5, 2),
            key = _ref6[0];

        _this2.deleteEventListener(key);
      });

      this.listener = {};
    }
  }, {
    key: 'removeListener',
    value: function removeListener(_eventName, handler) {
      var _this3 = this;

      var _eventName$split = _eventName.split('.'),
          _eventName$split2 = slicedToArray(_eventName$split, 2),
          eventName = _eventName$split2[0],
          namespace = _eventName$split2[1];
      //   .example  || click  || click.example


      if (!eventName && namespace) {
        Object.entries(this.listeners).map(function (_ref7) {
          var _ref8 = slicedToArray(_ref7, 2),
              key = _ref8[0];

          _this3.listeners[key] = _this3.listeners[key].filter(function (eventTuple) {
            return eventTuple.handler !== handler || eventTuple.namespace !== namespace;
          });

          if (_this3.listeners[key].length === 0) {
            _this3.deleteEventListener(key);
          }
        });
      } else if (eventName && !namespace) {
        // console.log('eventName')
        this.listeners[eventName] = this.listeners[eventName].filter(function (eventTuple) {
          return eventTuple.handler !== handler;
        });

        if (this.listeners[eventName].length === 0) {
          this.deleteEventListener(eventName);
        }
      } else if (eventName && namespace) {
        this.listeners[eventName] = this.listeners[eventName].filter(function (eventTuple) {
          return eventTuple.handler !== handler || eventTuple.namespace !== namespace;
        });

        if (this.listeners[eventName].length === 0) {
          this.deleteEventListener(eventName);
        }
      }
    }
  }, {
    key: 'removeAllListeners',
    value: function removeAllListeners(_eventName) {
      var _this4 = this;

      var _eventName$split3 = _eventName.split('.'),
          _eventName$split4 = slicedToArray(_eventName$split3, 2),
          eventName = _eventName$split4[0],
          namespace = _eventName$split4[1];
      //   .example  || click  || click.example


      if (!eventName && namespace) {
        Object.entries(this.listeners).map(function (_ref9) {
          var _ref10 = slicedToArray(_ref9, 2),
              key = _ref10[0];

          _this4.listeners[key] = _this4.listeners[key].filter(function (eventTuple) {
            return eventTuple.namespace !== namespace;
          });

          if (_this4.listeners[key].length === 0) {
            _this4.deleteEventListener(key);
          }
        });
      } else if (eventName && !namespace) {
        this.deleteEventListener(eventName);
      } else if (eventName && namespace && this.listeners[eventName]) {
        this.listeners[eventName] = this.listeners[eventName].filter(function (eventTuple) {
          return eventTuple.namespace !== namespace;
        });

        if (this.listeners[eventName].length === 0) {
          this.deleteEventListener(eventName);
        }
      }

      return this;
    }
  }, {
    key: 'createEventListener',
    value: function createEventListener(eventName) {
      this.listeners[eventName] = [];
      this.element.addEventListener(eventName, dispatch, false);
    }
  }, {
    key: 'deleteEventListener',
    value: function deleteEventListener(eventName) {
      this.element.removeEventListener(eventName, dispatch);
      delete this.listeners[eventName];
    }
  }, {
    key: 'checkRepeats',
    value: function checkRepeats(eventName, handler) {
      return this.listeners[eventName].filter(function (value) {
        return value.handler === handler;
      }).length !== 0;
    }
  }, {
    key: 'hasListeners',
    value: function hasListeners(eventName) {
      if (!this.listeners[eventName] || Object.keys(this.listeners[eventName]).length === 0) {
        return false;
      }

      return true;
    }
  }, {
    key: 'ensureHandler',
    value: function ensureHandler(handler) {
      var type = typeof handler === 'undefined' ? 'undefined' : _typeof(handler);
      if (type === 'function') {
        return handler;
      }
      throw new TypeError('Listeners should be function or closure. Received type: ' + type);
    }
  }], [{
    key: 'of',
    value: function of(_ref11, element) {
      var _eventName = _ref11.type,
          identity = _ref11.identity,
          handler = _ref11.handler;

      if (!element.__eventStorage) {
        element.__eventStorage = new this(element);
      }

      var _eventName$split5 = _eventName.split('.'),
          _eventName$split6 = slicedToArray(_eventName$split5, 2),
          eventName = _eventName$split6[0],
          namespace = _eventName$split6[1];

      var eventStorage = this.getEventStorage(element);

      eventStorage.on({
        identity: outputIdentity(identity),
        handler: handler,
        eventName: eventName,
        namespace: namespace
      });
    }
  }, {
    key: 'once',
    value: function once(_ref12, element) {
      var _eventName = _ref12.type,
          identity = _ref12.identity,
          handler = _ref12.handler;

      if (!element.__eventStorage) {
        element.__eventStorage = new this(element);
      }

      var _eventName$split7 = _eventName.split('.'),
          _eventName$split8 = slicedToArray(_eventName$split7, 2),
          eventName = _eventName$split8[0],
          namespace = _eventName$split8[1];

      var eventStorage = this.getEventStorage(element);

      eventStorage.once({
        identity: outputIdentity(identity),
        handler: handler,
        eventName: eventName,
        namespace: namespace
      });
    }
  }, {
    key: 'delete',
    value: function _delete(options, element) {
      var eventStorage = this.getEventStorage(element);
      if (!eventStorage) {
        return;
      }

      var _options$type = options.type,
          _eventName = _options$type === undefined ? options : _options$type,
          handler = options.handler;

      eventStorage.off(_eventName, handler);
    }
  }, {
    key: 'getEventStorage',
    value: function getEventStorage(element) {
      return element.__eventStorage;
    }
  }]);
  return EventStorage;
}();

var trigger = curry(function (options, el) {
  var _options$type = options.type,
      type = _options$type === undefined ? options : _options$type,
      data = options.data;

  var eventName = type;

  var eventStorage = EventStorage.getEventStorage(el);
  if (eventStorage && eventStorage.hasListeners(eventName)) {
    eventStorage.trigger(eventName, data);
  }

  return el;
});
/**
 * bindEvent ({
 *   type: 'example:CustomEvent',
 *   handler: event => {
 *     let { instance } = event.detail
 *   }
 * }, elemment)
 *
 * trigger({
 *   type: 'example:CustomEvent',
 *   data: {instance: this}
 * }, elemment)
 */

var bindEvent = curry(function (options, element) {
  EventStorage.of(options, element);
  return element;
});
/**
 * bindEvent ({
 *   type: eventName,
 *   handler
 * }, el)
 * bindEvent ({
 *   type: eventName,
 *   identity: '.className',
 *   handler
 * }, el)
 * bindEvent ({
 *   type,
 *   identity: {
 *     type: '[selector |class | id | attr | dataset]',
 *     value
 *   },
 *   handler
 * }, el)
 * example:
 * <li><a href="#" data-test="example">test</a></li>
 * bindEvent ({
 *   type,
 *   identity: {
 *     type: 'dataset',
 *     value: {test: 'example'}
 *   },
 *   handler
 * }, el)
 */
var removeEvent = curry(function (options, element) {
  EventStorage.delete(options, element);
  return element;
});
/**
 * removeEvent (this.eventName(), el)
 * removeEvent (eventName, el)
 * removeEvent ({
 *   type: [this.eventName() || eventName],
 *   handler
 * }, el)
 */
var bindEventOnce = curry(function (options, element) {
  EventStorage.once(options, element);
  return element;
});

// import './polyfills'
var envParamters = {
  body: window.document.body,
  doc: window.document
};

if (!window.Pj) {
  window.Pj = _extends({}, envParamters, {
    emitter: new Emitter(),
    plugins: {},
    instances: {},
    get windowWidth() {
      return window.document.documentElement.clientWidth;
    },
    get windowHeight() {
      return window.document.documentElement.clientHeight;
    },
    get: function get$$1(name) {
      if (typeof this.plugins[name] !== 'undefined') {
        return this.plugins[name];
      }
      return null;
    }
  });
}

var Pj = window.Pj;

function globalResizeHandle() {
  Pj.emitter.emit('resize');
}

function globalScrollHanle() {
  Pj.emitter.emit('scroll');
}

function register(name) {
  var obj = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var info = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

  return function (plugin) {
    var _obj$defaults = obj.defaults,
        options = _obj$defaults === undefined ? {} : _obj$defaults,
        _obj$methods = obj.methods,
        methods = _obj$methods === undefined ? [] : _obj$methods,
        _obj$dependencies = obj.dependencies,
        dependencies = _obj$dependencies === undefined ? {} : _obj$dependencies,
        others = objectWithoutProperties(obj, ['defaults', 'methods', 'dependencies']);


    if (Pj.get(name)) {
      /* eslint no-console: "off" */
      console.warn('Plugin \'' + name + '\' already exists.');
    }
    Pj.instances[name] = [];

    Pj.plugins[name] = Object.assign(plugin, _extends({
      setDefaults: function setDefaults() {
        var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        plugin.defaults = deepMerge(plugin.defaults, options);
      },

      defaults: plugin.defaults ? deepMerge(plugin.defaults, options) : options,
      methods: plugin.methods ? deepMerge(plugin.methods, methods) : methods,
      dependencies: plugin.dependencies ? deepMerge(plugin.dependencies, dependencies) : dependencies
    }, others), info);

    if (dependencies.length > 0) {
      var dependency = void 0;
      for (var i = 0; i < dependencies.length; i++) {
        dependency = dependencies[i];

        if (is.undefined(window[dependency]) && is.undefined(Pj.plugins[dependency])) {
          /* eslint no-console: "off" */
          console.warn('Plugin \'' + name + '\' require \'' + dependency + '\'.');
        }
      }
    }

    if (plugin.prototype.resize && is.undefined(plugin.resize)) {
      plugin.resize = function () {
        var instances = Pj.instances[name];

        for (var _i = 0; _i < instances.length; _i++) {
          instances[_i].resize(Pj.windowWidth, Pj.windowHeight);
        }
      };
    }

    if (is.function(plugin.resize)) {
      Pj.emitter.on('resize', plugin.resize);
    }

    if (plugin.prototype instanceof GlobalComponent) {
      Pj[name] = plugin;
    } else {
      Pj[name] = function (selector, options) {
        for (var _len = arguments.length, args = Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
          args[_key - 2] = arguments[_key];
        }

        var elements = typeof selector === 'string' ? Array.from(document.querySelectorAll(selector)) : [selector];
        if (!elements) {
          throw new Error('element is not exists');
        }

        var APIS = [];
        var apiCallback = function apiCallback(method) {
          for (var _len2 = arguments.length, args = Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
            args[_key2 - 1] = arguments[_key2];
          }

          var res = [];
          APIS.map(function (api) {
            res.push(api.apply(undefined, [method].concat(args)));
          });
          if (res.length !== 1) {
            return res;
          }
          return res[0];
        };

        elements.forEach(function (element) {
          var instance = new plugin(element, options);
          var API = function API(method) {
            for (var _len3 = arguments.length, args = Array(_len3 > 1 ? _len3 - 1 : 0), _key3 = 1; _key3 < _len3; _key3++) {
              args[_key3 - 1] = arguments[_key3];
            }

            if (!methods.includes(method)) {
              throw new Error('not find method: ' + method);
            }

            if (/^get/.test(method) || /^is/.test(method) || method === 'val' && args.length === 0) {
              if (instance && typeof instance[method] === 'function') {
                return instance[method].apply(instance, args);
              }
              return element;
            }

            if (typeof instance[method] === 'function') {
              return instance[method].apply(instance, args);
            }
          };
          APIS.push(API);
        });
        return apiCallback;
      };
    }
    return plugin;
  };
}

function stateable() {
  return function (plugin) {
    plugin.prototype.initStates = function () {
      var states = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      this._states = states;
    };

    // Checks whether the plugin is in a specific state or not.
    plugin.prototype.is = function (state) {
      if (this._states[state] && this._states[state] > 0) {
        return true;
      }
      return false;
    };

    // Enters a state.
    plugin.prototype.enter = function (state) {
      if (this._states[state] === undefined) {
        this._states[state] = 0;
      }

      // this._states[state]++;
      this._states[state] = 1;
    };

    // Leaves a state.
    plugin.prototype.leave = function (state) {
      if (this._states[state] === undefined) {
        this._states[state] = 0;
      }

      // this._states[state]--;
      this._states[state] = 0;
    };
  };
}

function eventable() {
  var events = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

  return function (plugin) {
    plugin.events = events;

    plugin.setEvents = function () {
      var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      deepMerge(plugin.events, options);
    };

    plugin.prototype.eventName = function (events) {
      if (typeof events !== 'string' || events === '') {
        return '.' + this.plugin;
      }
      events = events.split(' ');

      var length = events.length;
      for (var i = 0; i < length; i++) {
        events[i] = events[i] + '.' + this.plugin;
      }
      return events.join(' ');
    };

    plugin.prototype.eventNameWithId = function (events) {
      if (typeof events !== 'string' || events === '') {
        return '.' + this.plugin + '-' + this.instanceId;
      }

      events = events.split(' ');

      var length = events.length;
      for (var i = 0; i < length; i++) {
        events[i] = events[i] + '.' + this.plugin + '-' + this.instanceId;
      }
      return events.join(' ');
    };

    plugin.prototype.trigger = function (eventType) {
      for (var _len4 = arguments.length, params = Array(_len4 > 1 ? _len4 - 1 : 0), _key4 = 1; _key4 < _len4; _key4++) {
        params[_key4 - 1] = arguments[_key4];
      }

      if (eventType instanceof Event) {
        trigger(eventType, this.element);
        var type = camelize(eventType.type);
        var onFunction = 'on' + type;

        if (typeof this.options[onFunction] === 'function') {
          this.options[onFunction].apply(this, params);
        }
      } else {
        trigger({
          type: this.plugin + ':' + eventType,
          data: { instance: this, data: params }
        }, this.element);
        eventType = camelize(eventType);
        var _onFunction = 'on' + eventType;

        if (typeof this.options[_onFunction] === 'function') {
          this.options[_onFunction].apply(this, params);
        }
      }
    };

    plugin.prototype.selfEventName = function (eventType) {
      return this.plugin + ':' + eventType;
    };
  };
}

function themeable() {
  return function (plugin) {
    plugin.prototype.getThemeClass = function (themes, THEME) {
      if (is.undefined(themes) && this.options.theme) {
        return this.getThemeClass(this.options.theme);
      }
      if (is.string(themes)) {
        if (is.undefined(THEME)) {
          THEME = this.classes.THEME;
        }
        themes = themes.split(' ');

        if (THEME) {
          for (var i = 0; i < themes.length; i++) {
            themes[i] = THEME.replace('{theme}', themes[i]);
          }
        } else {
          for (var _i2 = 0; _i2 < themes.length; _i2++) {
            themes[_i2] = this.getClass(themes[_i2]);
          }
        }
        return themes.join(' ');
      }

      return '';
    };
  };
}

function styleable() {
  var classes = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

  return function (plugin) {
    plugin.classes = classes;
    plugin.setClasses = function () {
      var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      deepMerge(plugin.classes, options);
    };

    plugin.prototype.getClass = function (classname, arg, value) {
      if (!is.undefined(arg)) {
        return this.getClass(classname.replace('{' + arg + '}', value));
      }
      return classname.replace('{namespace}', this.classes.NAMESPACE || '');
    };

    plugin.prototype.initClasses = function (defaults$$1, options) {
      var _this = this;

      if (is.undefined(options) && is.object(this.options.classes)) {
        options = this.options.classes;
      }

      function conventKeyToUpperCase(obj) {
        var upperObj = {};
        for (var name in obj) {
          if (Object.hasOwnProperty.call(obj, name)) {
            if (is.string(obj[name])) {
              upperObj[name.toUpperCase()] = obj[name];
            } else if (is.object(obj[name])) {
              upperObj[name.toUpperCase()] = conventKeyToUpperCase(obj[name]);
            }
          }
        }
        return upperObj;
      }

      this.classes = deepMerge({}, defaults$$1, conventKeyToUpperCase(options || {}));

      if (!is.undefined(this.classes.NAMESPACE)) {
        var injectNamespace = function injectNamespace(obj) {
          for (var name in obj) {
            if (Object.hasOwnProperty.call(obj, name)) {
              if (is.string(obj[name])) {
                obj[name] = _this.getClass(obj[name]);
              } else if (is.object(obj[name])) {
                obj[name] = injectNamespace(obj[name]);
              }
            }
          }
          return obj;
        };

        this.classes = injectNamespace(this.classes);
      }
    };
  };
}

function translateable(translations) {
  return function (plugin) {
    window.deepMerge = deepMerge;
    plugin.I18N = new I18N({
      locale: plugin.defaults.locale,
      fallbacks: plugin.defaults.localeFallbacks
    }, translations);
    Object.assign(plugin.prototype, {
      setupI18n: function setupI18n() {
        this.i18n = plugin.I18N.instance({
          locale: this.options.locale,
          fallbacks: this.options.localeFallbacks
        });
      },
      translate: function translate(key, args) {
        return this.i18n.translate(key, args);
      },
      setLocale: function setLocale(locale) {
        return this.i18n.setLocale(locale);
      },
      getLocale: function getLocale() {
        return this.i18n.getLocale();
      }
    });
  };
}

window.addEventListener('orientationchange', globalResizeHandle);
window.addEventListener('resize', throttle(globalResizeHandle));
window.addEventListener('scroll', throttle(globalScrollHanle));

exports.register = register;
exports.stateable = stateable;
exports.eventable = eventable;
exports.themeable = themeable;
exports.styleable = styleable;
exports.translateable = translateable;
exports['default'] = Pj;

Object.defineProperty(exports, '__esModule', { value: true });

})));
