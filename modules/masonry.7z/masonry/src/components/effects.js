const EFFECTS = {
  fadeInUp: {
    translateX: function() {
      return [this.position.x, this.position.x]
    },
    translateY: function() {
      return [this.position.y + 100, this.position.y]
    },
    delay: function() {
      return this.index * this.options.delay
    },
    easing: 'easeOutQuad',
    opacity: [0, 1]
  },
  fadeInDown: {
    translateX: function() {
      return [this.position.x, this.position.x]
    },
    translateY: function() {
      return [this.position.y - 100, this.position.y]
    },
    delay: function() {
      return this.index * this.options.delay
    },
    easing: 'easeOutQuad',
    opacity: [0, 1]
  },
  fadeInLeft: {
    translateX: function() {
      return [this.position.x + 100, this.position.x]
    },
    translateY: function() {
      return [this.position.y, this.position.y]
    },
    delay: function() {
      return this.index * this.options.delay
    },
    easing: 'easeOutQuad',
    opacity: [0, 1]
  },
  fadeInRight: {
    translateX: function() {
      return [this.position.x - 100, this.position.x]
    },
    translateY: function() {
      return [this.position.y, this.position.y]
    },
    delay: function() {
      return this.index * this.options.delay
    },
    easing: 'easeOutQuad',
    opacity: [0, 1]
  },
  zoomIn: {
    translateX: function() {
      return [this.position.x, this.position.x]
    },
    translateY: function() {
      return [this.position.y, this.position.y]
    },
    delay: function() {
      return this.index * this.options.delay
    },
    easing: 'easeOutExpo',
    opacity: [0, 1],
    scale: [1.5, 1]
  },
  zoomOut: {
    translateX: function() {
      return [this.position.x, this.position.x]
    },
    translateY: function() {
      return [this.position.y, this.position.y]
    },
    delay: function() {
      return this.index * this.options.delay
    },
    easing: 'easeOutExpo',
    opacity: [0, 1],
    scale: [0, 1]
  },
  bounce: {
    translateX: function() {
      return [this.position.x, this.position.x]
    },
    translateY: function() {
      return [this.position.y, this.position.y]
    },
    delay: function() {
      return this.index * this.options.delay
    },
    easing: 'easeOutBack',
    opacity: [0, 1],
    scaleX: [0.4, 1],
    scaleY: [0.6, 1]
  },
  bounceIn: {
    translateX: function() {
      let test = Math.random(0, 1) > 0.5 ? 100 : -100
      return [this.position.x + test, this.position.x]
    },
    translateY: function() {
      let test = Math.random(0, 1) > 0.5 ? 100 : -100
      return [this.position.y + test, this.position.y]
    },
    delay: function() {
      return this.index * this.options.delay
    },
    easing: 'easeInOutBack',
    opacity: [0, 1],
    scaleX: [0.4, 1],
    scaleY: [0.6, 1]
  },
  cards: {
    translateX: function() {
      return [this.instance.width / 2, this.position.x]
    },
    translateY: function() {
      return [this.position.y + 200, this.position.y]
    },
    delay: function() {
      return this.index * this.options.delay
    },
    easing: 'easeOutExpo',
    opacity: [0, 1]
  },
  unfold: {
    translateX: function() {
      return [this.instance.width / 2, this.position.x]
    },
    translateY: function() {
      return [this.position.y + 200, this.position.y]
    },
    delay: function() {
      return this.options.delay * (this.length - this.index)
    },
    easing: 'easeOutExpo',
    opacity: [0, 1]
  },
  fan: {
    translateX: function() {
      return [this.position.x, this.position.x]
    },
    translateY: function() {
      return [this.position.y - 200, this.position.y]
    },
    delay: function() {
      return this.options.delay * (this.length - this.index)
    },
    easing: 'easeOutExpo',
    opacity: [0, 1]
  }
}

export default EFFECTS
