import { html as render, query } from '@pluginjs/dom'
import Slider from '@pluginjs/slider'

const data = [
	{
		"src": "https://picsum.photos/800/600"
	},
	{
		"src": "https://picsum.photos/800/600"
	},
	{
		"src": "https://picsum.photos/800/600"
	},
	{
		"src": "https://picsum.photos/800/600"
	},
	{
		"src": "https://picsum.photos/800/600"
	},
	{
		"src": "https://picsum.photos/800/600"
	},
	{
		"src": "https://picsum.photos/800/600"
	},
	{
		"src": "https://picsum.photos/800/600"
	},
	{
		"src": "https://picsum.photos/800/600"
	}
]

const element = query('#default .slider')
Slider.of(element, {
  data
})
