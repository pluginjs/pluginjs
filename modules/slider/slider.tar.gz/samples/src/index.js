// import accordion css
import '@pluginjs/slider/src/css/slider.scss'

// import sections
import './sections/default/index.js'
