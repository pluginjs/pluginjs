const namespace = 'slider'

const events = {
  READY: 'ready',
  ENABLE: 'enable',
  DISABLE: 'disable',
  DESTROY: 'destroy',
  RESIZE: 'resize',
  PREV: 'prev',
  NEXT: 'next'
}

const classes = {
  NAMESPACE: `pj-${namespace}`,
  CONTAINER: '{namespace}',
  ITEMS: '{namespace}-items',
  ITEM: '{namespace}-item',
  ACTIVE: '{namespace}-active',
  VERTICAL: '{namespace}-vertical',
  DISABLED: '{namespace}-disabled'
}

const methods = [
  'enable',
  'disable',
  'destroy',
  'prev',
  'next'
]

const defaults = {
  data: null,
  arrows: false,
  vertical: false,
  locale: 'en',
  templates: {
    cards() {
      return '<div class="{classes.ITEMS}"></div>'
    },
    card() {
      return (
        '<div class="{classes.ITEM}">' +
        '<div class="{classes.LOADER}"></div>' +
        '</div>'
      )
    },
    img() {
      return '<img class="{classes.IMG}">'
    }
  }
}

const dependencies = ['arrows']

export { classes, defaults, events, methods, namespace, dependencies }
