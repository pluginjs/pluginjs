import Emitter from '@pluginjs/emitter';
import GlobalComponent from '@pluginjs/global-plugin';
import I18N from '@pluginjs/i18n';
import is from '@pluginjs/is';
import { camelize, compose, curry, deepMerge, throttle } from '@pluginjs/utils';

const find = curry((selector, parent) => parent.querySelector(selector));

const finds = curry((selector, parent) => Array.from(parent.querySelectorAll(selector)));

const remove = el => el.remove();

const html = curry((content, el) => {
  el.innerHTML = content;
  return el;
});

const children = el => Array.from(el.children);















const parent = el => el.parentNode;
// 解析 HTML/SVG/XML 字符串
const parseHTML = (...args) => {
  const htmlString = Array.isArray(args[0]) ? args[0].reduce((result, str, index) => result + args[index] + str) : args[0];
  const childNodes = compose(children, html(htmlString))(document.createElement('div'));
  if (childNodes.length === 1) {
    return childNodes[0];
  }
  return childNodes;
};











const next = el => el.nextElementSibling;

const attr = curry((args, el) => {
  if (typeof args === 'string') {
    return el.getAttribute(args);
  }
  Object.entries(args).forEach(([k, v]) => el.setAttribute(k, v));
  return el;
});
const removeAttribute = curry((name, el) => el.removeAttribute(name));

const dataset = curry((args, el) => {
  if (typeof args === 'string') {
    return el.dataset[args];
  }
  Object.entries(args).forEach(([k, v]) => {
    el.dataset[k] = v;
  });
  return el;
});

const text = curry((content, el) => {
  el.textContent = content;
  return el;
});

const append = curry((child, el) => {
  if (is.string(child)) {
    el.insertAdjacentHTML('beforeend', child);
  } else {
    el.append(child);
  }
  return el;
});

const prepend = curry((child, el) => {
  if (is.string(child)) {
    el.insertAdjacentHTML('afterbegin', child);
  } else {
    el.prepend(child);
  }
  return el;
});

const insertBefore = curry((newElement, el) => {
  if (is.string(newElement)) {
    el.insertAdjacentHTML('beforebegin', newElement);
  } else {
    el.insertAdjacentElement('beforebegin', newElement);
  }
  return el;
});

const insertAfter = curry((newElement, el) => {
  if (is.string(newElement)) {
    el.insertAdjacentHTML('afterend', newElement);
  } else {
    el.insertAdjacentElement('afterend', newElement);
  }
  return el;
});

const wrap = curry((wrapElement, el) => {
  if (is.string(wrapElement)) {
    wrapElement = parseHTML(wrapElement);
  }
  // compose(append(wrapElement), clone, insertBefore(wrapElement))(el)
  insertBefore(wrapElement, el);
  remove(el);
  append(el, wrapElement);
  return wrapElement;
});









const parentWith = curry((fn, el) => {
  const parentElement = parent(el);
  if (parentElement === document) {
    return false;
  }
  if (fn(parentElement)) {
    return parentElement;
  }
  return parentWith(fn, parentElement);
});



const contains = curry((el, parent) => parent.contains(el));

const closest = curry((selector, el) => {
  if (el.matches(selector)) {
    return el;
  }
  return parentWith(el => el.matches(selector), el);
});

const nextElementWith = curry((fn, el) => {
  const nextElement = next(el);
  if (fn(nextElement)) {
    return nextElement;
  }
  return nextElementWith(fn, nextElement);
});

const outputIdentity = identity => {
  if (!identity) {
    return { type: 'self', value: '' };
  }
  if (typeof identity === 'string') {
    return { type: 'selector', value: identity };
  }

  return identity;
};

const tupleToStyleSelector = (tuple, prefix) => {
  if (typeof tuple === 'string') {
    return tuple;
  }
  return Object.entries(tuple).map(kv => `[${prefix}${kv.join('=')}]`).join('');
};

const dispatch = event => {
  const { target, currentTarget } = event;
  const eventStorage = EventStorage.getEventStorage(currentTarget);
  const eventName = event.type;

  const attrVerify$$1 = {
    self: node => node === currentTarget,
    class: (node, value) => node.matches(`.${value}`),
    selector: (node, value) => node.matches(value),
    id: (node, value) => node.matches(`#${value}`),
    tagName: (node, value) => node.matches(value),
    dom: (node, value) => node === value,
    dataset: (node, value) => node.matches(tupleToStyleSelector(value, 'data-')),
    attribute: (node, value) => node.matches(tupleToStyleSelector(value)),
    func: (node, value) => Boolean(value(node))
  };

  const nodeTreeCheck = (node, result = []) => {
    if (!currentTarget.contains(node)) {
      return result;
    }

    const matchEventList = eventStorage.listeners[eventName].filter(({ identity }) => {
      const { type, value } = identity;
      const identityMapper = attrVerify$$1[type];
      if (identityMapper && identityMapper(node, value)) {
        return true;
      }
      return false;
    });
    return nodeTreeCheck(parent(node), result.concat(matchEventList));
  };
  // nodeTreeCheck(target).map(e => console.log(e.handler.toString()))
  nodeTreeCheck(target).reduce((result, { handler }) => result !== false && handler(event), true);
};

let EventStorage = class EventStorage {
  constructor(element) {
    this.element = element;
    this.listeners = {};
  }

  on({ identity, handler, eventName, namespace }) {
    this.ensureHandler(handler);

    if (!this.hasListeners(eventName)) {
      this.createEventListener(eventName);
    }

    if (this.checkRepeats(eventName, handler)) {
      return;
    }

    this.listeners[eventName].push({ identity, handler, namespace });
  }

  once({ identity, handler, eventName, namespace }) {
    this.ensureHandler(handler);

    if (!this.hasListeners(eventName)) {
      this.createEventListener(eventName);
    }

    const callback = event => {
      this.removeListener(eventName, callback);

      return handler(event);
    };

    this.listeners[eventName].push({ identity, handler: callback, namespace });
  }

  off(_eventName, handler) {
    if (typeof handler === 'undefined') {
      return this.removeAllListeners(_eventName);
    }
    return this.removeListener(_eventName, handler);
  }

  trigger(eventName, data) {
    const event = new CustomEvent(eventName, {
      detail: data
    });
    this.element.dispatchEvent(event);
  }

  clear() {
    Object.entries(this.listeners).map(([key, value]) => {
      this.deleteEventListener(key);
    });

    this.listener = {};
  }

  removeListener(_eventName, handler) {
    const [eventName, namespace] = _eventName.split('.');
    //   .example  || click  || click.example
    if (!eventName && namespace) {
      Object.entries(this.listeners).map(([key, value]) => {
        this.listeners[key] = this.listeners[key].filter(eventTuple => eventTuple.handler !== handler || eventTuple.namespace !== namespace);

        if (this.listeners[key].length === 0) {
          this.deleteEventListener(key);
        }
      });
    } else if (eventName && !namespace) {
      // console.log('eventName')
      this.listeners[eventName] = this.listeners[eventName].filter(eventTuple => eventTuple.handler !== handler);

      if (this.listeners[eventName].length === 0) {
        this.deleteEventListener(eventName);
      }
    } else if (eventName && namespace) {
      this.listeners[eventName] = this.listeners[eventName].filter(eventTuple => eventTuple.handler !== handler || eventTuple.namespace !== namespace);

      if (this.listeners[eventName].length === 0) {
        this.deleteEventListener(eventName);
      }
    }
  }

  removeAllListeners(_eventName) {
    const [eventName, namespace] = _eventName.split('.');
    //   .example  || click  || click.example
    if (!eventName && namespace) {
      Object.entries(this.listeners).map(([key, value]) => {
        this.listeners[key] = this.listeners[key].filter(eventTuple => eventTuple.namespace !== namespace);

        if (this.listeners[key].length === 0) {
          this.deleteEventListener(key);
        }
      });
    } else if (eventName && !namespace) {
      this.deleteEventListener(eventName);
    } else if (eventName && namespace && this.listeners[eventName]) {
      this.listeners[eventName] = this.listeners[eventName].filter(eventTuple => eventTuple.namespace !== namespace);

      if (this.listeners[eventName].length === 0) {
        this.deleteEventListener(eventName);
      }
    }

    return this;
  }

  createEventListener(eventName) {
    this.listeners[eventName] = [];
    this.element.addEventListener(eventName, dispatch, false);
  }

  deleteEventListener(eventName) {
    this.element.removeEventListener(eventName, dispatch);
    delete this.listeners[eventName];
  }

  checkRepeats(eventName, handler) {
    return this.listeners[eventName].filter(value => value.handler === handler).length !== 0;
  }

  hasListeners(eventName) {
    if (!this.listeners[eventName] || Object.keys(this.listeners[eventName]).length === 0) {
      return false;
    }

    return true;
  }

  ensureHandler(handler) {
    const type = typeof handler;
    if (type === 'function') {
      return handler;
    }
    throw new TypeError(`Listeners should be function or closure. Received type: ${type}`);
  }

  static of({ type: _eventName, identity, handler }, element) {
    if (!element.__eventStorage) {
      element.__eventStorage = new this(element);
    }

    const [eventName, namespace] = _eventName.split('.');

    const eventStorage = this.getEventStorage(element);

    eventStorage.on({
      identity: outputIdentity(identity),
      handler,
      eventName,
      namespace
    });
  }

  static once({ type: _eventName, identity, handler }, element) {
    if (!element.__eventStorage) {
      element.__eventStorage = new this(element);
    }

    const [eventName, namespace] = _eventName.split('.');

    const eventStorage = this.getEventStorage(element);

    eventStorage.once({
      identity: outputIdentity(identity),
      handler,
      eventName,
      namespace
    });
  }

  static delete(options, element) {
    const eventStorage = this.getEventStorage(element);
    if (!eventStorage) {
      return;
    }

    const { type: _eventName = options, handler } = options;
    eventStorage.off(_eventName, handler);
  }

  static getEventStorage(element) {
    return element.__eventStorage;
  }
};

const trigger = curry((options, el) => {
  const { type = options, data } = options;
  const eventName = type;

  const eventStorage = EventStorage.getEventStorage(el);
  if (eventStorage && eventStorage.hasListeners(eventName)) {
    eventStorage.trigger(eventName, data);
  }

  return el;
});
/**
 * bindEvent ({
 *   type: 'example:CustomEvent',
 *   handler: event => {
 *     let { instance } = event.detail
 *   }
 * }, elemment)
 *
 * trigger({
 *   type: 'example:CustomEvent',
 *   data: {instance: this}
 * }, elemment)
 */

const bindEvent = curry((options, element) => {
  EventStorage.of(options, element);
  return element;
});
/**
 * bindEvent ({
 *   type: eventName,
 *   handler
 * }, el)
 * bindEvent ({
 *   type: eventName,
 *   identity: '.className',
 *   handler
 * }, el)
 * bindEvent ({
 *   type,
 *   identity: {
 *     type: '[selector |class | id | attr | dataset]',
 *     value
 *   },
 *   handler
 * }, el)
 * example:
 * <li><a href="#" data-test="example">test</a></li>
 * bindEvent ({
 *   type,
 *   identity: {
 *     type: 'dataset',
 *     value: {test: 'example'}
 *   },
 *   handler
 * }, el)
 */
const removeEvent = curry((options, element) => {
  EventStorage.delete(options, element);
  return element;
});
/**
 * removeEvent (this.eventName(), el)
 * removeEvent (eventName, el)
 * removeEvent ({
 *   type: [this.eventName() || eventName],
 *   handler
 * }, el)
 */
const bindEventOnce = curry((options, element) => {
  EventStorage.once(options, element);
  return element;
});

var asyncGenerator = function () {
  function AwaitValue(value) {
    this.value = value;
  }

  function AsyncGenerator(gen) {
    var front, back;

    function send(key, arg) {
      return new Promise(function (resolve, reject) {
        var request = {
          key: key,
          arg: arg,
          resolve: resolve,
          reject: reject,
          next: null
        };

        if (back) {
          back = back.next = request;
        } else {
          front = back = request;
          resume(key, arg);
        }
      });
    }

    function resume(key, arg) {
      try {
        var result = gen[key](arg);
        var value = result.value;

        if (value instanceof AwaitValue) {
          Promise.resolve(value.value).then(function (arg) {
            resume("next", arg);
          }, function (arg) {
            resume("throw", arg);
          });
        } else {
          settle(result.done ? "return" : "normal", result.value);
        }
      } catch (err) {
        settle("throw", err);
      }
    }

    function settle(type, value) {
      switch (type) {
        case "return":
          front.resolve({
            value: value,
            done: true
          });
          break;

        case "throw":
          front.reject(value);
          break;

        default:
          front.resolve({
            value: value,
            done: false
          });
          break;
      }

      front = front.next;

      if (front) {
        resume(front.key, front.arg);
      } else {
        back = null;
      }
    }

    this._invoke = send;

    if (typeof gen.return !== "function") {
      this.return = undefined;
    }
  }

  if (typeof Symbol === "function" && Symbol.asyncIterator) {
    AsyncGenerator.prototype[Symbol.asyncIterator] = function () {
      return this;
    };
  }

  AsyncGenerator.prototype.next = function (arg) {
    return this._invoke("next", arg);
  };

  AsyncGenerator.prototype.throw = function (arg) {
    return this._invoke("throw", arg);
  };

  AsyncGenerator.prototype.return = function (arg) {
    return this._invoke("return", arg);
  };

  return {
    wrap: function (fn) {
      return function () {
        return new AsyncGenerator(fn.apply(this, arguments));
      };
    },
    await: function (value) {
      return new AwaitValue(value);
    }
  };
}();















var _extends = Object.assign || function (target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];

    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }

  return target;
};













var objectWithoutProperties = function (obj, keys) {
  var target = {};

  for (var i in obj) {
    if (keys.indexOf(i) >= 0) continue;
    if (!Object.prototype.hasOwnProperty.call(obj, i)) continue;
    target[i] = obj[i];
  }

  return target;
};

// import './polyfills'
const envParamters = {
  body: window.document.body,
  doc: window.document
};

if (!window.Pj) {
  window.Pj = _extends({}, envParamters, {
    emitter: new Emitter(),
    plugins: {},
    instances: {},
    get windowWidth() {
      return window.document.documentElement.clientWidth;
    },
    get windowHeight() {
      return window.document.documentElement.clientHeight;
    },
    get(name) {
      if (typeof this.plugins[name] !== 'undefined') {
        return this.plugins[name];
      }
      return null;
    }
  });
}

const Pj = window.Pj;

function globalResizeHandle() {
  Pj.emitter.emit('resize');
}

function globalScrollHanle() {
  Pj.emitter.emit('scroll');
}

function register(name, obj = {}, info = {}) {
  return function (plugin) {
    const {
      defaults: options = {},
      methods = [],
      dependencies = {}
    } = obj,
          others = objectWithoutProperties(obj, ['defaults', 'methods', 'dependencies']);

    if (Pj.get(name)) {
      /* eslint no-console: "off" */
      console.warn(`Plugin '${name}' already exists.`);
    }
    Pj.instances[name] = [];

    Pj.plugins[name] = Object.assign(plugin, _extends({
      setDefaults(options = {}) {
        plugin.defaults = deepMerge(plugin.defaults, options);
      },
      defaults: plugin.defaults ? deepMerge(plugin.defaults, options) : options,
      methods: plugin.methods ? deepMerge(plugin.methods, methods) : methods,
      dependencies: plugin.dependencies ? deepMerge(plugin.dependencies, dependencies) : dependencies
    }, others), info);

    if (dependencies.length > 0) {
      let dependency;
      for (let i = 0; i < dependencies.length; i++) {
        dependency = dependencies[i];

        if (is.undefined(window[dependency]) && is.undefined(Pj.plugins[dependency])) {
          /* eslint no-console: "off" */
          console.warn(`Plugin '${name}' require '${dependency}'.`);
        }
      }
    }

    if (plugin.prototype.resize && is.undefined(plugin.resize)) {
      plugin.resize = function () {
        const instances = Pj.instances[name];

        for (let i = 0; i < instances.length; i++) {
          instances[i].resize(Pj.windowWidth, Pj.windowHeight);
        }
      };
    }

    if (is.function(plugin.resize)) {
      Pj.emitter.on('resize', plugin.resize);
    }

    if (plugin.prototype instanceof GlobalComponent) {
      Pj[name] = plugin;
    } else {
      Pj[name] = (selector, options, ...args) => {
        const elements = typeof selector === 'string' ? Array.from(document.querySelectorAll(selector)) : [selector];
        if (!elements) {
          throw new Error('element is not exists');
        }

        const APIS = [];
        const apiCallback = (method, ...args) => {
          const res = [];
          APIS.map(api => {
            res.push(api(method, ...args));
          });
          if (res.length !== 1) {
            return res;
          }
          return res[0];
        };

        elements.forEach(element => {
          const instance = new plugin(element, options);
          const API = (method, ...args) => {
            if (!methods.includes(method)) {
              throw new Error(`not find method: ${method}`);
            }

            if (/^get/.test(method) || /^is/.test(method) || method === 'val' && args.length === 0) {
              if (instance && typeof instance[method] === 'function') {
                return instance[method](...args);
              }
              return element;
            }

            if (typeof instance[method] === 'function') {
              return instance[method](...args);
            }
          };
          APIS.push(API);
        });
        return apiCallback;
      };
    }
    return plugin;
  };
}

function stateable() {
  return function (plugin) {
    plugin.prototype.initStates = function (states = {}) {
      this._states = states;
    };

    // Checks whether the plugin is in a specific state or not.
    plugin.prototype.is = function (state) {
      if (this._states[state] && this._states[state] > 0) {
        return true;
      }
      return false;
    };

    // Enters a state.
    plugin.prototype.enter = function (state) {
      if (this._states[state] === undefined) {
        this._states[state] = 0;
      }

      // this._states[state]++;
      this._states[state] = 1;
    };

    // Leaves a state.
    plugin.prototype.leave = function (state) {
      if (this._states[state] === undefined) {
        this._states[state] = 0;
      }

      // this._states[state]--;
      this._states[state] = 0;
    };
  };
}

function eventable(events = {}) {
  return function (plugin) {
    plugin.events = events;

    plugin.setEvents = function (options = {}) {
      deepMerge(plugin.events, options);
    };

    plugin.prototype.eventName = function (events) {
      if (typeof events !== 'string' || events === '') {
        return `.${this.plugin}`;
      }
      events = events.split(' ');

      const length = events.length;
      for (let i = 0; i < length; i++) {
        events[i] = `${events[i]}.${this.plugin}`;
      }
      return events.join(' ');
    };

    plugin.prototype.eventNameWithId = function (events) {
      if (typeof events !== 'string' || events === '') {
        return `.${this.plugin}-${this.instanceId}`;
      }

      events = events.split(' ');

      const length = events.length;
      for (let i = 0; i < length; i++) {
        events[i] = `${events[i]}.${this.plugin}-${this.instanceId}`;
      }
      return events.join(' ');
    };

    plugin.prototype.trigger = function (eventType, ...params) {
      if (eventType instanceof Event) {
        trigger(eventType, this.element);
        const type = camelize(eventType.type);
        const onFunction = `on${type}`;

        if (typeof this.options[onFunction] === 'function') {
          this.options[onFunction].apply(this, params);
        }
      } else {
        trigger({
          type: `${this.plugin}:${eventType}`,
          data: { instance: this, data: params }
        }, this.element);
        eventType = camelize(eventType);
        const onFunction = `on${eventType}`;

        if (typeof this.options[onFunction] === 'function') {
          this.options[onFunction].apply(this, params);
        }
      }
    };

    plugin.prototype.selfEventName = function (eventType) {
      return `${this.plugin}:${eventType}`;
    };
  };
}

function themeable() {
  return function (plugin) {
    plugin.prototype.getThemeClass = function (themes, THEME) {
      if (is.undefined(themes) && this.options.theme) {
        return this.getThemeClass(this.options.theme);
      }
      if (is.string(themes)) {
        if (is.undefined(THEME)) {
          THEME = this.classes.THEME;
        }
        themes = themes.split(' ');

        if (THEME) {
          for (let i = 0; i < themes.length; i++) {
            themes[i] = THEME.replace('{theme}', themes[i]);
          }
        } else {
          for (let i = 0; i < themes.length; i++) {
            themes[i] = this.getClass(themes[i]);
          }
        }
        return themes.join(' ');
      }

      return '';
    };
  };
}

function styleable(classes = {}) {
  return function (plugin) {
    plugin.classes = classes;
    plugin.setClasses = function (options = {}) {
      deepMerge(plugin.classes, options);
    };

    plugin.prototype.getClass = function (classname, arg, value) {
      if (!is.undefined(arg)) {
        return this.getClass(classname.replace(`{${arg}}`, value));
      }
      return classname.replace('{namespace}', this.classes.NAMESPACE || '');
    };

    plugin.prototype.initClasses = function (defaults$$1, options) {
      if (is.undefined(options) && is.object(this.options.classes)) {
        options = this.options.classes;
      }

      function conventKeyToUpperCase(obj) {
        const upperObj = {};
        for (const name in obj) {
          if (Object.hasOwnProperty.call(obj, name)) {
            if (is.string(obj[name])) {
              upperObj[name.toUpperCase()] = obj[name];
            } else if (is.object(obj[name])) {
              upperObj[name.toUpperCase()] = conventKeyToUpperCase(obj[name]);
            }
          }
        }
        return upperObj;
      }

      this.classes = deepMerge({}, defaults$$1, conventKeyToUpperCase(options || {}));

      if (!is.undefined(this.classes.NAMESPACE)) {
        const injectNamespace = obj => {
          for (const name in obj) {
            if (Object.hasOwnProperty.call(obj, name)) {
              if (is.string(obj[name])) {
                obj[name] = this.getClass(obj[name]);
              } else if (is.object(obj[name])) {
                obj[name] = injectNamespace(obj[name]);
              }
            }
          }
          return obj;
        };

        this.classes = injectNamespace(this.classes);
      }
    };
  };
}

function translateable(translations) {
  return function (plugin) {
    window.deepMerge = deepMerge;
    plugin.I18N = new I18N({
      locale: plugin.defaults.locale,
      fallbacks: plugin.defaults.localeFallbacks
    }, translations);
    Object.assign(plugin.prototype, {
      setupI18n() {
        this.i18n = plugin.I18N.instance({
          locale: this.options.locale,
          fallbacks: this.options.localeFallbacks
        });
      },
      translate(key, args) {
        return this.i18n.translate(key, args);
      },
      setLocale(locale) {
        return this.i18n.setLocale(locale);
      },
      getLocale() {
        return this.i18n.getLocale();
      }
    });
  };
}

window.addEventListener('orientationchange', globalResizeHandle);
window.addEventListener('resize', throttle(globalResizeHandle));
window.addEventListener('scroll', throttle(globalScrollHanle));

export { register, stateable, eventable, themeable, styleable, translateable };
export default Pj;
