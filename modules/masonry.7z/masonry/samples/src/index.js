import '@pluginjs/icons/dist/plugin-icons.css'

// import sections
import './sections/default/index.js'
import './sections/gutter/index.js'
import './sections/custom/index.js'
import './sections/add/index.js'
import './sections/loader/index.js'