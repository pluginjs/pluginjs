
(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
	typeof define === 'function' && define.amd ? define(['exports'], factory) :
	(factory((global['@pluginjs/is'] = {})));
}(this, (function (exports) { 'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) {
  return typeof obj;
} : function (obj) {
  return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
};





var asyncGenerator = function () {
  function AwaitValue(value) {
    this.value = value;
  }

  function AsyncGenerator(gen) {
    var front, back;

    function send(key, arg) {
      return new Promise(function (resolve, reject) {
        var request = {
          key: key,
          arg: arg,
          resolve: resolve,
          reject: reject,
          next: null
        };

        if (back) {
          back = back.next = request;
        } else {
          front = back = request;
          resume(key, arg);
        }
      });
    }

    function resume(key, arg) {
      try {
        var result = gen[key](arg);
        var value = result.value;

        if (value instanceof AwaitValue) {
          Promise.resolve(value.value).then(function (arg) {
            resume("next", arg);
          }, function (arg) {
            resume("throw", arg);
          });
        } else {
          settle(result.done ? "return" : "normal", result.value);
        }
      } catch (err) {
        settle("throw", err);
      }
    }

    function settle(type, value) {
      switch (type) {
        case "return":
          front.resolve({
            value: value,
            done: true
          });
          break;

        case "throw":
          front.reject(value);
          break;

        default:
          front.resolve({
            value: value,
            done: false
          });
          break;
      }

      front = front.next;

      if (front) {
        resume(front.key, front.arg);
      } else {
        back = null;
      }
    }

    this._invoke = send;

    if (typeof gen.return !== "function") {
      this.return = undefined;
    }
  }

  if (typeof Symbol === "function" && Symbol.asyncIterator) {
    AsyncGenerator.prototype[Symbol.asyncIterator] = function () {
      return this;
    };
  }

  AsyncGenerator.prototype.next = function (arg) {
    return this._invoke("next", arg);
  };

  AsyncGenerator.prototype.throw = function (arg) {
    return this._invoke("throw", arg);
  };

  AsyncGenerator.prototype.return = function (arg) {
    return this._invoke("return", arg);
  };

  return {
    wrap: function (fn) {
      return function () {
        return new AsyncGenerator(fn.apply(this, arguments));
      };
    },
    await: function (value) {
      return new AwaitValue(value);
    }
  };
}();

/*eslint-disable */
/* Credit to http://is.js.org MIT */
var toString = Object.prototype.toString;
var is = {
  // Type checks
  /* -------------------------------------------------------------------------- */
  // is a given value Arguments?
  arguments: function _arguments(value) {
    // fallback check is for IE
    return toString.call(value) === '[object Arguments]' || value != null && (typeof value === 'undefined' ? 'undefined' : _typeof(value)) === 'object' && 'callee' in value;
  },

  // is a given value Array?
  array: function array(val) {
    if (Array.isArray) {
      return Array.isArray(val);
    }
    return toString.call(val) === '[object Array]';
  },

  // is a given value Boolean?
  boolean: function boolean(val) {
    return val === true || val === false || toString.call(val) === '[object Boolean]';
  },

  // is a given value Char?
  char: function char(val) {
    return this.string(val) && val.length === 1;
  },

  // is a given value Date Object?
  date: function date(value) {
    return toString.call(value) === '[object Date]';
  },

  // is a given object a DOM node?
  domNode: function domNode(object) {
    return this.object(object) && object.nodeType > 0;
  },

  // is a given value Error object?
  error: function error(val) {
    return toString.call(val) === '[object Error]';
  },

  // is a given value function?
  function: function _function(val) {
    // fallback check is for IE
    return toString.call(val) === '[object Function]' || typeof val === 'function';
  },

  // is given value a pure JSON object?
  json: function json(value) {
    return toString.call(value) === '[object Object]';
  },

  // is a given value NaN?
  nan: function nan(val) {
    // NaN is number :) Also it is the only value which does not equal itself
    return val !== val;
  },

  // is a given value null?
  null: function _null(val) {
    return val === null;
  },

  // is a given value number?
  number: function number(val) {
    return !this.nan(val) && toString.call(val) === '[object Number]';
  },

  // is a given value object?
  object: function object(val) {
    return Object(val) === val;
  },

  // is a given value empty object?
  emptyObject: function emptyObject(val) {
    return this.object(val) && Object.getOwnPropertyNames(val).length == 0;
  },

  // is a given value RegExp?
  regexp: function regexp(val) {
    return toString.call(val) === '[object RegExp]';
  },

  // is a given value String?
  string: function string(val) {
    return typeof val === 'string' || toString.call(val) === '[object String]';
  },

  // is a given value undefined?
  undefined: function undefined(val) {
    return val === void 0;
  },

  // Arithmetic checks
  /* -------------------------------------------------------------------------- */
  // is a given value numeric?
  numeric: function numeric(n) {
    return (this.number(n) || this.string(n)) && !this.nan(n - parseFloat(n));
  },

  // is a given number percentage?
  percentage: function percentage(n) {
    return typeof n === 'string' && n.indexOf('%') !== -1;
  },

  // is a given number decimal?
  decimal: function decimal(n) {
    return this.number(n) && n % 1 !== 0;
  },

  // is a given number finite?
  finite: function finite(n) {
    if (isFinite) {
      return isFinite(n);
    }
    return !this.infinite(n) && !this.nan(n);
  },

  // is a given number infinite?
  infinite: function infinite(n) {
    return n === Infinity || n === -Infinity;
  },

  integer: function integer(n) {
    return this.number(n) && n % 1 === 0;
  },

  // is a given number negative?
  negative: function negative(n) {
    return this.number(n) && n < 0;
  },

  // is a given number positive?
  positive: function positive(n) {
    return this.number(n) && n > 0;
  }
};

exports['default'] = is;

Object.defineProperty(exports, '__esModule', { value: true });

})));

(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
	typeof define === 'function' && define.amd ? define(['exports'], factory) :
	(factory((global['@pluginjs/feature'] = {})));
}(this, (function (exports) { 'use strict';

/* eslint no-undef: "off" */

/* Credit to http://featurejs.com MIT */
/**
 * Test if it's an old device that we want to filter out
 */
var old = function old() {
  return Boolean(/(Android\s(1.|2.))|(Silk\/1.)/i.test(navigator.userAgent));
};

/**
 * Function that takes a standard CSS property name as a parameter and
 * returns it's prefixed version valid for current browser it runs in
 */
var pfx = function () {
  var prefixes = ['Webkit', 'Moz', 'O', 'ms'];
  var memory = {};
  var style = document.createElement('dummy').style;
  return function (prop) {
    if (typeof memory[prop] === 'undefined') {
      var ucProp = prop.charAt(0).toUpperCase() + prop.substr(1);
      var props = (prop + ' ' + prefixes.join(ucProp + ' ') + ucProp).split(' ');
      memory[prop] = null;

      for (var i in props) {
        if (style[props[i]] !== undefined) {
          memory[prop] = props[i];
          break;
        }
      }
    }
    return memory[prop];
  };
}();

function prefixedProperty(property) {
  return pfx(property);
}

var transitionProperty = function transitionProperty() {
  return pfx('transition');
};

var transformProperty = function transformProperty() {
  return pfx('transform');
};

var animationProperty = function animationProperty() {
  return pfx('animation');
};

var transitionEndEvent = function transitionEndEvent() {
  var eventNames = {
    transition: 'transitionend',
    OTransition: 'oTransitionEnd',
    MozTransition: 'transitionend',
    WebkitTransition: 'webkitTransitionEnd'
  };
  var style = document.createElement('dummy').style;
  for (var i in eventNames) {
    if (eventNames.hasOwnProperty(i)) {
      if (style[i] !== undefined) {
        return eventNames[i];
      }
    }
  }
  return false;
};

var animationEndEvent = function animationEndEvent() {
  var eventNames = {
    animation: 'animationend',
    OAnimation: 'oanimationend',
    msAnimation: 'MSAnimationEnd',
    MozAnimation: 'animationend',
    WebkitAnimation: 'webkitAnimationEnd'
    // const style = document.body.style
  };var style = {};
  for (var i in eventNames) {
    if (eventNames.hasOwnProperty(i)) {
      if (style[i] !== undefined) {
        return eventNames[i];
      }
    }
  }
  return false;
};

// Test if CSS 3D transforms are supported
var transform3D = function transform3D() {
  var test = !old() && pfx('perspective') !== null;
  return Boolean(test);
};

// Test if CSS transforms are supported
var transform = function transform() {
  var test = !old() && pfx('transformOrigin') !== null;
  return Boolean(test);
};

// Test if CSS transitions are supported
var transition = function transition() {
  var test = pfx('transition') !== null;
  return Boolean(test);
};

// Test if CSS sticky  are supported

var canSticky = function canSticky() {
  var _canSticky = false;
  var documentFragment = document.documentElement;
  var testElement = document.createElement('div');
  documentFragment.appendChild(testElement);
  var prefixedSticky = ['sticky', '-webkit-sticky'];

  for (var i = 0; i < prefixedSticky.length; i++) {
    testElement.style.position = prefixedSticky[i];
    _canSticky = Boolean(window.getComputedStyle(testElement).position.match('sticky'));
    if (_canSticky) {
      break;
    }
  }
  documentFragment.removeChild(testElement);

  return _canSticky;
};

// Test if SVG is supported
var isSupportedSvg = function isSupportedSvg() {
  return Boolean(document.createElementNS) && Boolean(document.createElementNS('http://www.w3.org/2000/svg', 'svg').createSVGRect);
};

// Tests if touch events are supported, but doesn't necessarily reflect a touchscreen device
var touch = Boolean('ontouchstart' in window || window.navigator && window.navigator.msPointerEnabled && window.MSGesture || window.DocumentTouch && document instanceof DocumentTouch);

var pointer = window.PointerEvent || window.MSPointerEvent ? true : false; // eslint-disable-line no-unneeded-ternary

function pointerEvent(pointerEvent) {
  return window.MSPointerEvent ? 'MSPointer' + pointerEvent.charAt(9).toUpperCase() + pointerEvent.substr(10) : pointerEvent;
}

exports.prefixedProperty = prefixedProperty;
exports.transitionProperty = transitionProperty;
exports.transformProperty = transformProperty;
exports.animationProperty = animationProperty;
exports.transitionEndEvent = transitionEndEvent;
exports.animationEndEvent = animationEndEvent;
exports.transform3D = transform3D;
exports.transform = transform;
exports.transition = transition;
exports.canSticky = canSticky;
exports.isSupportedSvg = isSupportedSvg;
exports.touch = touch;
exports.pointer = pointer;
exports.pointerEvent = pointerEvent;

Object.defineProperty(exports, '__esModule', { value: true });

})));

(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
	typeof define === 'function' && define.amd ? define(['exports'], factory) :
	(factory((global['@pluginjs/utils'] = {})));
}(this, (function (exports) { 'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) {
  return typeof obj;
} : function (obj) {
  return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
};





var asyncGenerator = function () {
  function AwaitValue(value) {
    this.value = value;
  }

  function AsyncGenerator(gen) {
    var front, back;

    function send(key, arg) {
      return new Promise(function (resolve, reject) {
        var request = {
          key: key,
          arg: arg,
          resolve: resolve,
          reject: reject,
          next: null
        };

        if (back) {
          back = back.next = request;
        } else {
          front = back = request;
          resume(key, arg);
        }
      });
    }

    function resume(key, arg) {
      try {
        var result = gen[key](arg);
        var value = result.value;

        if (value instanceof AwaitValue) {
          Promise.resolve(value.value).then(function (arg) {
            resume("next", arg);
          }, function (arg) {
            resume("throw", arg);
          });
        } else {
          settle(result.done ? "return" : "normal", result.value);
        }
      } catch (err) {
        settle("throw", err);
      }
    }

    function settle(type, value) {
      switch (type) {
        case "return":
          front.resolve({
            value: value,
            done: true
          });
          break;

        case "throw":
          front.reject(value);
          break;

        default:
          front.resolve({
            value: value,
            done: false
          });
          break;
      }

      front = front.next;

      if (front) {
        resume(front.key, front.arg);
      } else {
        back = null;
      }
    }

    this._invoke = send;

    if (typeof gen.return !== "function") {
      this.return = undefined;
    }
  }

  if (typeof Symbol === "function" && Symbol.asyncIterator) {
    AsyncGenerator.prototype[Symbol.asyncIterator] = function () {
      return this;
    };
  }

  AsyncGenerator.prototype.next = function (arg) {
    return this._invoke("next", arg);
  };

  AsyncGenerator.prototype.throw = function (arg) {
    return this._invoke("throw", arg);
  };

  AsyncGenerator.prototype.return = function (arg) {
    return this._invoke("return", arg);
  };

  return {
    wrap: function (fn) {
      return function () {
        return new AsyncGenerator(fn.apply(this, arguments));
      };
    },
    await: function (value) {
      return new AwaitValue(value);
    }
  };
}();













var defineProperty = function (obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
};

var _extends = Object.assign || function (target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];

    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }

  return target;
};













var objectWithoutProperties = function (obj, keys) {
  var target = {};

  for (var i in obj) {
    if (keys.indexOf(i) >= 0) continue;
    if (!Object.prototype.hasOwnProperty.call(obj, i)) continue;
    target[i] = obj[i];
  }

  return target;
};







var slicedToArray = function () {
  function sliceIterator(arr, i) {
    var _arr = [];
    var _n = true;
    var _d = false;
    var _e = undefined;

    try {
      for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
        _arr.push(_s.value);

        if (i && _arr.length === i) break;
      }
    } catch (err) {
      _d = true;
      _e = err;
    } finally {
      try {
        if (!_n && _i["return"]) _i["return"]();
      } finally {
        if (_d) throw _e;
      }
    }

    return _arr;
  }

  return function (arr, i) {
    if (Array.isArray(arr)) {
      return arr;
    } else if (Symbol.iterator in Object(arr)) {
      return sliceIterator(arr, i);
    } else {
      throw new TypeError("Invalid attempt to destructure non-iterable instance");
    }
  };
}();













var toConsumableArray = function (arr) {
  if (Array.isArray(arr)) {
    for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) arr2[i] = arr[i];

    return arr2;
  } else {
    return Array.from(arr);
  }
};

function fromPairs$1(arr) {
  return arr.reduce(function (r, _ref) {
    var _ref2 = slicedToArray(_ref, 2),
        k = _ref2[0],
        v = _ref2[1];

    return _extends({}, r, defineProperty({}, k, v));
  }, {});
}

function mergeWith$1() {
  for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }

  var objs = args.slice(0, -1);
  var customizer = args[args.length - 1];
  return Object.entries(args[0]).reduce(function (r, _ref3) {
    var _ref4 = slicedToArray(_ref3, 1),
        k = _ref4[0];

    return _extends({}, r, defineProperty({}, k, objs.map(function (obj) {
      return obj[k];
    }).filter(function (v) {
      return Boolean(v) || v === 0;
    }).reduce(function (r, i) {
      return customizer(r, i);
    })));
  }, {});
}

var T = {
  0: 'X',
  1: 'Y',
  2: 'Z'
};

function mapTransformToAnime(str) {
  var css3dList = ['translate', 'rotate', 'scale'];
  return css3dList.filter(function (key) {
    var regx = new RegExp(key, 'g');
    if (str.match(regx)) {
      return true;
    }
    return false;
  }).reduce(function (initialState, key) {
    var matrix = str.match(/\(([^()]+)\)/)[1].split(',');
    var map = mapMatch(key);
    return map(matrix);
  }, {});
}

function mapMatch(type) {
  switch (type) {
    case 'translate':
      return mapToTranslate;
    case 'rotate':
      return mapToRotate;
    case 'scale':
      return mapToScale;
    default:
      return function () {
        return 'no match!';
      };
  }
}

function mapToScale(matrix) {
  // console.group('scale')
  var result = matrix.map(function (value, index) {
    var n = parseFloat(value, 10);
    var result = defineProperty({}, 'scale' + T[index], n || 0);
    // console.log(result)
    return result;
  });
  return result.reduce(mergeObject);
}

function mapToTranslate(matrix) {
  var result = matrix.map(function (value, index) {
    var n = parseFloat(value.slice(0, -2), 10);
    var result = defineProperty({}, 'translate' + T[index], n || 0);
    return result;
  });
  return result.reduce(mergeObject);
}

function mapToRotate(matrix) {
  var value = matrix[matrix.length - 1].slice(0, -3);
  var transformType = matrix.slice(0, -1).map(function (n, index) {
    if (parseInt(n, 10)) {
      return 'rotate' + T[index];
    }
    return n;
  }).filter(isNotEmpty);
  return defineProperty({}, transformType[0], parseFloat(value));
}

function mergeObject(r, i) {
  return _extends({}, r, i);
}

function customizer(objValue, srcValue) {
  if (Array.isArray(objValue)) {
    return objValue.concat(srcValue);
  }
  return [objValue, srcValue];
}

function isNotEmpty(value) {
  if (value) {
    return true;
  }
  return false;
}

function filterOffset(obj) {
  var offset = obj.offset,
      result = objectWithoutProperties(obj, ['offset']);

  return result;
}

function filterEmptyValues(obj) {
  return fromPairs$1(Object.entries(obj).filter(function (_ref6) {
    var _ref7 = slicedToArray(_ref6, 2),
        v = _ref7[1];

    var arr = v.filter(function (i) {
      return Boolean(i);
    });
    if (arr.length) {
      return true;
    }
    return false;
  }).map(function (_ref8) {
    var _ref9 = slicedToArray(_ref8, 2),
        k = _ref9[0],
        v = _ref9[1];

    var value = v.map(function (i) {
      if (i === undefined) {
        if (/scale/g.test(k)) {
          return 1;
        }
        return 0;
      }
      return i;
    });
    return [k, value];
  }));
}

function mapKeyFramesToAnime(keyframes) {
  var transformNoneIndex = [];
  var transformKeys = new Set();
  var newKeyFrames = keyframes.map(function (keyframe, keyframeIndex) {
    var transform = keyframe.transform,
        newKeyFrame = objectWithoutProperties(keyframe, ['transform']);

    if (transform) {
      var arr = transform.split(') ').map(function (item, index, arr) {
        if (index !== arr.length - 1) {
          return item + ')';
        }
        return item;
      }).map(function (value) {
        if (/3d/g.test(value)) {
          var transformObject = mapTransformToAnime(value);
          Object.keys(transformObject).map(function (key) {
            return transformKeys.add(key);
          });
          return transformObject;
        }
        return value;
      }).filter(function (value) {
        return typeof value !== 'string';
      });
      // console.log(arr)
      if (!arr.length) {
        transformNoneIndex.push(keyframeIndex);
        return newKeyFrame;
      }
      return Object.assign.apply(Object, [{}, newKeyFrame].concat(toConsumableArray(arr)));
    }
    return newKeyFrame;
  });
  var emptyTransform = fromPairs$1(Array.from(transformKeys).map(function (key) {
    if (/scale/g.test(key)) {
      return [key, 1];
    }
    return [key, 0];
  }));
  if (transformNoneIndex.length) {
    var _iteratorNormalCompletion = true;
    var _didIteratorError = false;
    var _iteratorError = undefined;

    try {
      for (var _iterator = transformNoneIndex[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
        var index = _step.value;

        Object.assign(newKeyFrames[index], emptyTransform);
      }
    } catch (err) {
      _didIteratorError = true;
      _iteratorError = err;
    } finally {
      try {
        if (!_iteratorNormalCompletion && _iterator.return) {
          _iterator.return();
        }
      } finally {
        if (_didIteratorError) {
          throw _iteratorError;
        }
      }
    }
  }
  var data = mergeWith$1.apply(undefined, toConsumableArray(newKeyFrames).concat([customizer]));
  var result = filterOffset(filterEmptyValues(data));
  return result;
}

var deepClone = function deepClone(obj) {
  if (typeof obj === 'function') {
    return obj;
  }
  return JSON.parse(JSON.stringify(obj));
};
function nub(arr) {
  return Array.from(new Set(arr));
}
function isPaintObject(data) {
  if ((typeof data === 'undefined' ? 'undefined' : _typeof(data)) !== 'object') {
    return false;
  }

  if (data === null) {
    return false;
  }

  if (data instanceof Set || data instanceof Map) {
    return false;
  }

  if (Array.isArray(data)) {
    return false;
  }

  return true;
}
function deepMergeTwo(x, y) {
  if (isPaintObject(y) && isPaintObject(x) || isPaintObject(x) && Array.isArray(y)) {
    return fromPairs(nub(Object.keys(x).concat(Object.keys(y))).map(function (key) {
      return [key, deepMergeTwo(x[key], y[key])];
    }));
  }

  if (isPaintObject(y) && typeof x === 'function') {
    return Object.assign(function () {
      for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      return x.apply(this, args);
    }, y);
  }

  if (isPaintObject(y) && Array.isArray(x)) {
    return Object.assign([], x, y);
  }

  if (isPaintObject(x) && typeof y === 'function') {
    return Object.assign(function () {
      for (var _len2 = arguments.length, args = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
        args[_key2] = arguments[_key2];
      }

      return y.apply(this, args);
    }, x);
  }

  if (Array.isArray(y) && Array.isArray(x)) {
    // return x.concat(y)
    return nub(Object.keys(y).concat(Object.keys(x))).map(function (index) {
      return deepMergeTwo(x[index], y[index]);
    });
  }

  if (typeof y === 'undefined') {
    return x;
  }
  return y;
}
function isObject(obj) {
  return Object(obj) === obj;
}
function deepMerge() {
  for (var _len3 = arguments.length, args = Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
    args[_key3] = arguments[_key3];
  }

  return args.filter(isObject).reduce(deepMergeTwo);
}

var curry = function curry(fn) {
  var args = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
  return function () {
    for (var _len4 = arguments.length, subArgs = Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
      subArgs[_key4] = arguments[_key4];
    }

    var currylen = fn.currylen || fn.length;
    var collect = args.concat(subArgs);
    if (collect.length >= currylen) {
      return fn.apply(undefined, toConsumableArray(collect));
    }
    return curry(fn, collect);
  };
};

var compose = function compose() {
  for (var _len5 = arguments.length, fn = Array(_len5), _key5 = 0; _key5 < _len5; _key5++) {
    fn[_key5] = arguments[_key5];
  }

  var callback = function callback() {
    for (var _len6 = arguments.length, args = Array(_len6), _key6 = 0; _key6 < _len6; _key6++) {
      args[_key6] = arguments[_key6];
    }

    return fn.reduceRight(function (r, i, index) {
      if (Array.isArray(r) && index === fn.length - 1) {
        return i.apply(undefined, toConsumableArray(r));
      }
      return i(r);
    }, args);
  };
  callback.currylen = fn[fn.curylen || fn.length - 1].length;
  return callback;
};

var MAX_UID = 1000000;

function getUID(prefix) {
  do {
    // eslint-disable-next-line no-bitwise
    prefix += ~~(Math.random() * MAX_UID); // "~~" acts like a faster Math.floor() here
  } while (document.getElementById(prefix));
  return prefix;
}

function range(v) {
  return Array.from({ length: v }, function (v, i) {
    return i;
  });
}

function reflow(element) {
  return element.offsetHeight;
}

function arraysEqual(a, b) {
  if (a === b) {
    return true;
  }
  if (a === undefined || b === undefined) {
    return false;
  }
  if (a.length !== b.length) {
    return false;
  }

  for (var i = 0; i < a.length; ++i) {
    if (a[i] !== b[i]) {
      return false;
    }
  }
  return true;
}

function arrayDiff(a, b) {
  // let t;
  // if (a.length < b.length) {
  //   t = b;
  //   b = a;
  //   a = t;
  // }
  return a.filter(function (n) {
    return b.indexOf(n) < 0;
  });
}

function arrayIntersect(a, b) {
  var t = void 0;
  if (b.length > a.length) {
    t = b;
    b = a;
    a = t;
  }
  return a.filter(function (n) {
    return b.indexOf(n) !== -1;
  });
}

function convertPercentageToFloat(n) {
  return parseFloat(n.slice(0, -1) / 100, 10);
}

function convertFloatToPercentage(n) {
  if (n < 0) {
    n = 0;
  } else if (n > 1) {
    n = 1;
  }
  return parseFloat(n).toFixed(4) * 100 + '%';
}

function convertMatrixToArray(value) {
  if (value && value.substr(0, 6) === 'matrix') {
    return value.replace(/^.*\((.*)\)$/g, '$1').replace(/px/g, '').split(/, +/);
  }
  return false;
}

function getTime() {
  if (typeof window.performance !== 'undefined' && window.performance.now) {
    return window.performance.now();
  }
  return Date.now();
}

function camelize(word) {
  var first = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;

  word = word.replace(/[_.-\s](\w|$)/g, function (_, x) {
    return x.toUpperCase();
  });

  if (first) {
    word = word.substring(0, 1).toUpperCase() + word.substring(1);
  }
  return word;
}

/* Credit to https://github.com/jonschlinkert/get-value MIT */
function getValueByPath(obj, path) {
  if (Object(obj) !== obj || typeof path === 'undefined') {
    return obj;
  }

  if (path in obj) {
    return obj[path];
  }

  var segs = path.split('.');
  var length = segs.length;
  if (!length) {
    return undefined;
  }
  var i = -1;

  while (obj && ++i < length) {
    var key = segs[i];
    while (key[key.length - 1] === '\\') {
      key = key.slice(0, -1) + '.' + segs[++i];
    }
    obj = obj[key];
  }
  return obj;
}

/* Throttle execution of a function.
 * Especially useful for rate limiting execution of
 * handlers on events like resize and scroll. */
function throttle(func, delay) {
  var _this = this;

  var running = false;
  function resetRunning() {
    running = false;
  }

  if (delay !== undefined || delay !== null) {
    return function () {
      for (var _len7 = arguments.length, args = Array(_len7), _key7 = 0; _key7 < _len7; _key7++) {
        args[_key7] = arguments[_key7];
      }

      var that = _this;

      if (running) {
        return;
      }
      running = true;
      func.apply(that, args);
      window.setTimeout(resetRunning, delay);
    };
  }

  return function () {
    for (var _len8 = arguments.length, args = Array(_len8), _key8 = 0; _key8 < _len8; _key8++) {
      args[_key8] = arguments[_key8];
    }

    var that = _this;

    if (running) {
      return;
    }
    running = true;
    window.requestAnimationFrame(function () {
      func.apply(that, args);
      resetRunning();
    });
  };
}

/* Debounce execution of a function.
 * Debouncing, unlike throttling, guarantees that a function
 * is only executed a single time at the very end. */
function debounce(func) {
  var _this2 = this;

  var delay = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 100;

  var timer = void 0;

  return function () {
    for (var _len9 = arguments.length, args = Array(_len9), _key9 = 0; _key9 < _len9; _key9++) {
      args[_key9] = arguments[_key9];
    }

    var that = _this2;
    if (timer) {
      clearTimeout(timer);
      timer = null;
    }
    timer = setTimeout(function () {
      func.apply(that, args);
    }, delay);
  };
}

function fromPairs(arr) {
  return arr.reduce(function (r, _ref) {
    var _ref2 = slicedToArray(_ref, 2),
        k = _ref2[0],
        v = _ref2[1];

    return _extends({}, r, defineProperty({}, k, v));
  }, {});
}
function mergeWith(obj1, obj2, customizer) {
  return Object.entries(obj1).reduce(function (r, _ref3) {
    var _ref4 = slicedToArray(_ref3, 2),
        k = _ref4[0],
        v = _ref4[1];

    return _extends({}, r, defineProperty({}, k, customizer(v, obj2[k])));
  }, {});
}

exports.deepClone = deepClone;
exports.nub = nub;
exports.deepMerge = deepMerge;
exports.curry = curry;
exports.compose = compose;
exports.getUID = getUID;
exports.range = range;
exports.reflow = reflow;
exports.arraysEqual = arraysEqual;
exports.arrayDiff = arrayDiff;
exports.arrayIntersect = arrayIntersect;
exports.convertPercentageToFloat = convertPercentageToFloat;
exports.convertFloatToPercentage = convertFloatToPercentage;
exports.convertMatrixToArray = convertMatrixToArray;
exports.getTime = getTime;
exports.camelize = camelize;
exports.getValueByPath = getValueByPath;
exports.throttle = throttle;
exports.debounce = debounce;
exports.fromPairs = fromPairs;
exports.mergeWith = mergeWith;
exports.keyframes2Anime = mapKeyFramesToAnime;

Object.defineProperty(exports, '__esModule', { value: true });

})));

(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
	typeof define === 'function' && define.amd ? define(['exports'], factory) :
	(factory((global['@pluginjs/emitter'] = {})));
}(this, (function (exports) { 'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) {
  return typeof obj;
} : function (obj) {
  return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
};





var asyncGenerator = function () {
  function AwaitValue(value) {
    this.value = value;
  }

  function AsyncGenerator(gen) {
    var front, back;

    function send(key, arg) {
      return new Promise(function (resolve, reject) {
        var request = {
          key: key,
          arg: arg,
          resolve: resolve,
          reject: reject,
          next: null
        };

        if (back) {
          back = back.next = request;
        } else {
          front = back = request;
          resume(key, arg);
        }
      });
    }

    function resume(key, arg) {
      try {
        var result = gen[key](arg);
        var value = result.value;

        if (value instanceof AwaitValue) {
          Promise.resolve(value.value).then(function (arg) {
            resume("next", arg);
          }, function (arg) {
            resume("throw", arg);
          });
        } else {
          settle(result.done ? "return" : "normal", result.value);
        }
      } catch (err) {
        settle("throw", err);
      }
    }

    function settle(type, value) {
      switch (type) {
        case "return":
          front.resolve({
            value: value,
            done: true
          });
          break;

        case "throw":
          front.reject(value);
          break;

        default:
          front.resolve({
            value: value,
            done: false
          });
          break;
      }

      front = front.next;

      if (front) {
        resume(front.key, front.arg);
      } else {
        back = null;
      }
    }

    this._invoke = send;

    if (typeof gen.return !== "function") {
      this.return = undefined;
    }
  }

  if (typeof Symbol === "function" && Symbol.asyncIterator) {
    AsyncGenerator.prototype[Symbol.asyncIterator] = function () {
      return this;
    };
  }

  AsyncGenerator.prototype.next = function (arg) {
    return this._invoke("next", arg);
  };

  AsyncGenerator.prototype.throw = function (arg) {
    return this._invoke("throw", arg);
  };

  AsyncGenerator.prototype.return = function (arg) {
    return this._invoke("return", arg);
  };

  return {
    wrap: function (fn) {
      return function () {
        return new AsyncGenerator(fn.apply(this, arguments));
      };
    },
    await: function (value) {
      return new AwaitValue(value);
    }
  };
}();





var classCallCheck = function (instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
};

var createClass = function () {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  return function (Constructor, protoProps, staticProps) {
    if (protoProps) defineProperties(Constructor.prototype, protoProps);
    if (staticProps) defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();

var Emitter = function () {
  function Emitter() {
    classCallCheck(this, Emitter);

    this.listeners = {};
    this.sortedListeners = {};
  }

  createClass(Emitter, [{
    key: 'emit',
    value: function emit(event) {
      var listeners = this.getListeners(event);

      for (var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }

      for (var i = 0; i < listeners.length; i++) {
        var context = null;

        if (listeners[i].context !== null) {
          context = listeners[i].context;
        } else {
          context = { type: event };
        }

        var result = listeners[i].listener.apply(context, args);

        if (result === false) {
          return false;
        }
      }

      return true;
    }
  }, {
    key: 'on',
    value: function on(event, listener, context, priority) {
      return this.addListener(event, listener, context, priority);
    }
  }, {
    key: 'once',
    value: function once(event, listener, context, priority) {
      return this.addOneTimeListener(event, listener, context, priority);
    }
  }, {
    key: 'off',
    value: function off(event, listener) {
      if (typeof listener === 'undefined') {
        return this.removeAllListeners(event);
      }

      return this.removeListener(event, listener);
    }

    /* Lower numbers correspond with earlier execution,
    /* and functions with the same priority are executed
    /* in the order in which they were added to the action. */

  }, {
    key: 'addListener',
    value: function addListener(event, listener) {
      var context = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;
      var priority = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 10;

      this.ensureListener(listener);

      if (!this.listeners[event]) {
        this.listeners[event] = {};
      }
      if (!this.listeners[event][priority]) {
        this.listeners[event][priority] = [];
      }

      this.listeners[event][priority].push({
        context: context,
        listener: listener
      });
      this.clearSortedListeners(event);

      return this;
    }
  }, {
    key: 'addOneTimeListener',
    value: function addOneTimeListener(event, listener, context) {
      var priority = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 10;

      var that = this;
      function wrapper() {
        that.removeListener(event, wrapper);

        return listener.apply(undefined, arguments);
      }

      this.addListener(event, wrapper, context, priority);

      return this;
    }
  }, {
    key: 'removeListener',
    value: function removeListener(event, listener) {
      this.clearSortedListeners(event);
      var listeners = this.hasListeners(event) ? this.listeners[event] : [];

      for (var priority in listeners) {
        if (Object.prototype.hasOwnProperty.call(listeners, priority)) {
          listeners[priority] = listeners[priority].filter(function (value) {
            return value.listener !== listener;
          });

          if (listeners[priority].length === 0) {
            delete listeners[priority];
          }
        }
      }

      this.listeners[event] = listeners;

      return this;
    }
  }, {
    key: 'removeAllListeners',
    value: function removeAllListeners(event) {
      this.clearSortedListeners(event);

      if (this.hasListeners(event)) {
        delete this.listeners[event];
      }

      return this;
    }
  }, {
    key: 'ensureListener',
    value: function ensureListener(listener) {
      var type = typeof listener === 'undefined' ? 'undefined' : _typeof(listener);
      if (type === 'function') {
        return listener;
      }
      throw new TypeError('Listeners should be function or closure. Received type: ' + type);
    }
  }, {
    key: 'hasListeners',
    value: function hasListeners(event) {
      if (!this.listeners[event] || Object.keys(this.listeners[event]).length === 0) {
        return false;
      }

      return true;
    }
  }, {
    key: 'getListeners',
    value: function getListeners(event) {
      if (!this.sortedListeners.hasOwnProperty(event)) {
        this.sortedListeners[event] = this.getSortedListeners(event);
      }

      return this.sortedListeners[event];
    }
  }, {
    key: 'getSortedListeners',
    value: function getSortedListeners(event) {
      if (!this.hasListeners(event)) {
        return [];
      }

      var listeners = this.listeners[event];

      var priorities = Object.keys(listeners);
      priorities.sort(function (a, b) {
        return a - b;
      });

      var sortedlisteners = [];
      for (var i = 0; i < priorities.length; i++) {
        sortedlisteners = sortedlisteners.concat(listeners[priorities[i]]);
      }

      return sortedlisteners;
    }
  }, {
    key: 'clearSortedListeners',
    value: function clearSortedListeners(event) {
      delete this.sortedListeners[event];
    }
  }]);
  return Emitter;
}();

exports['default'] = Emitter;

Object.defineProperty(exports, '__esModule', { value: true });

})));

(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
	typeof define === 'function' && define.amd ? define(['exports'], factory) :
	(factory((global['@pluginjs/global-plugin'] = {})));
}(this, (function (exports) { 'use strict';

var asyncGenerator = function () {
  function AwaitValue(value) {
    this.value = value;
  }

  function AsyncGenerator(gen) {
    var front, back;

    function send(key, arg) {
      return new Promise(function (resolve, reject) {
        var request = {
          key: key,
          arg: arg,
          resolve: resolve,
          reject: reject,
          next: null
        };

        if (back) {
          back = back.next = request;
        } else {
          front = back = request;
          resume(key, arg);
        }
      });
    }

    function resume(key, arg) {
      try {
        var result = gen[key](arg);
        var value = result.value;

        if (value instanceof AwaitValue) {
          Promise.resolve(value.value).then(function (arg) {
            resume("next", arg);
          }, function (arg) {
            resume("throw", arg);
          });
        } else {
          settle(result.done ? "return" : "normal", result.value);
        }
      } catch (err) {
        settle("throw", err);
      }
    }

    function settle(type, value) {
      switch (type) {
        case "return":
          front.resolve({
            value: value,
            done: true
          });
          break;

        case "throw":
          front.reject(value);
          break;

        default:
          front.resolve({
            value: value,
            done: false
          });
          break;
      }

      front = front.next;

      if (front) {
        resume(front.key, front.arg);
      } else {
        back = null;
      }
    }

    this._invoke = send;

    if (typeof gen.return !== "function") {
      this.return = undefined;
    }
  }

  if (typeof Symbol === "function" && Symbol.asyncIterator) {
    AsyncGenerator.prototype[Symbol.asyncIterator] = function () {
      return this;
    };
  }

  AsyncGenerator.prototype.next = function (arg) {
    return this._invoke("next", arg);
  };

  AsyncGenerator.prototype.throw = function (arg) {
    return this._invoke("throw", arg);
  };

  AsyncGenerator.prototype.return = function (arg) {
    return this._invoke("return", arg);
  };

  return {
    wrap: function (fn) {
      return function () {
        return new AsyncGenerator(fn.apply(this, arguments));
      };
    },
    await: function (value) {
      return new AwaitValue(value);
    }
  };
}();





var classCallCheck = function (instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
};

var createClass = function () {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  return function (Constructor, protoProps, staticProps) {
    if (protoProps) defineProperties(Constructor.prototype, protoProps);
    if (staticProps) defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();









var inherits = function (subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      enumerable: false,
      writable: true,
      configurable: true
    }
  });
  if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
};











var possibleConstructorReturn = function (self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return call && (typeof call === "object" || typeof call === "function") ? call : self;
};





var slicedToArray = function () {
  function sliceIterator(arr, i) {
    var _arr = [];
    var _n = true;
    var _d = false;
    var _e = undefined;

    try {
      for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
        _arr.push(_s.value);

        if (i && _arr.length === i) break;
      }
    } catch (err) {
      _d = true;
      _e = err;
    } finally {
      try {
        if (!_n && _i["return"]) _i["return"]();
      } finally {
        if (_d) throw _e;
      }
    }

    return _arr;
  }

  return function (arr, i) {
    if (Array.isArray(arr)) {
      return arr;
    } else if (Symbol.iterator in Object(arr)) {
      return sliceIterator(arr, i);
    } else {
      throw new TypeError("Invalid attempt to destructure non-iterable instance");
    }
  };
}();

var Plugin = function () {
  function Plugin(namespace, element) {
    classCallCheck(this, Plugin);

    this.plugin = namespace;
    this.element = element;
    if (window.Pj && window.Pj.instances[this.plugin]) {
      window.Pj.instances[this.plugin].push(this);
    }
  }

  createClass(Plugin, [{
    key: 'getDataOptions',
    value: function getDataOptions() {
      var _this = this;

      var data = this.element.dataset;
      var length = Object.keys(data).length;
      var newData = {};

      if (length > 0) {
        Object.entries(data).forEach(function (_ref) {
          var _ref2 = slicedToArray(_ref, 2),
              name = _ref2[0],
              content = _ref2[1];

          var cache = {};
          var items = name.split('-');
          // let items = name.split('-');

          var deep = items.length;

          if (deep > 1) {
            for (var j = 0; j < deep; j++) {
              var item = items[j].substring(0, 1).toLowerCase() + items[j].substring(1);

              if (j === 0) {
                cache[item] = {};
              } else if (j === deep - 1) {} else {}
            }
          } else if (items[0] === 'as' + _this.plugin.substring(0, 1).toUpperCase() + _this.plugin.substring(1)) {
            cache = content;
          } else {
            cache[name] = content;
          }

          Object.assign(newData, cache);
        });
      }

      return newData;
    }
  }, {
    key: 'destroy',
    value: function destroy() {
      var _this2 = this;

      this.plugin = null;
      this.element = null;
      if (window.Pj && window.Pj.instances[this.plugin]) {
        window.Pj.instances[this.plugin] = window.Pj.instances[this.plugin].filter(function (plugin) {
          return plugin.element === _this2.element;
        });
      }
    }
  }], [{
    key: 'of',
    value: function of() {
      for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      return new (Function.prototype.bind.apply(this, [null].concat(args)))();
    }
  }]);
  return Plugin;
}();

var GlobalComponent = function (_Component) {
  inherits(GlobalComponent, _Component);

  function GlobalComponent(namespace) {
    classCallCheck(this, GlobalComponent);

    var _this = possibleConstructorReturn(this, (GlobalComponent.__proto__ || Object.getPrototypeOf(GlobalComponent)).call(this, namespace, window.Pj.doc));

    if (!window.Pj.instances[_this.plugin]) {
      return possibleConstructorReturn(_this);
    }
    _this.instanceId = window.Pj.instances[_this.plugin].length + 1;
    window.Pj.instances[_this.plugin].push(_this);
    return _this;
  }

  createClass(GlobalComponent, [{
    key: 'destroy',
    value: function destroy() {
      var _this2 = this;

      window.Pj.instances[this.plugin] = window.Pj.instances[this.plugin].filter(function (instance) {
        return instance !== _this2;
      });
      window.Pj[this.plugin] = null;
    }
  }]);
  return GlobalComponent;
}(Plugin);

exports['default'] = GlobalComponent;

Object.defineProperty(exports, '__esModule', { value: true });

})));

(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
	typeof define === 'function' && define.amd ? define(['exports'], factory) :
	(factory((global['@pluginjs/template'] = {})));
}(this, (function (exports) { 'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) {
  return typeof obj;
} : function (obj) {
  return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
};





var asyncGenerator$1 = function () {
  function AwaitValue(value) {
    this.value = value;
  }

  function AsyncGenerator(gen) {
    var front, back;

    function send(key, arg) {
      return new Promise(function (resolve, reject) {
        var request = {
          key: key,
          arg: arg,
          resolve: resolve,
          reject: reject,
          next: null
        };

        if (back) {
          back = back.next = request;
        } else {
          front = back = request;
          resume(key, arg);
        }
      });
    }

    function resume(key, arg) {
      try {
        var result = gen[key](arg);
        var value = result.value;

        if (value instanceof AwaitValue) {
          Promise.resolve(value.value).then(function (arg) {
            resume("next", arg);
          }, function (arg) {
            resume("throw", arg);
          });
        } else {
          settle(result.done ? "return" : "normal", result.value);
        }
      } catch (err) {
        settle("throw", err);
      }
    }

    function settle(type, value) {
      switch (type) {
        case "return":
          front.resolve({
            value: value,
            done: true
          });
          break;

        case "throw":
          front.reject(value);
          break;

        default:
          front.resolve({
            value: value,
            done: false
          });
          break;
      }

      front = front.next;

      if (front) {
        resume(front.key, front.arg);
      } else {
        back = null;
      }
    }

    this._invoke = send;

    if (typeof gen.return !== "function") {
      this.return = undefined;
    }
  }

  if (typeof Symbol === "function" && Symbol.asyncIterator) {
    AsyncGenerator.prototype[Symbol.asyncIterator] = function () {
      return this;
    };
  }

  AsyncGenerator.prototype.next = function (arg) {
    return this._invoke("next", arg);
  };

  AsyncGenerator.prototype.throw = function (arg) {
    return this._invoke("throw", arg);
  };

  AsyncGenerator.prototype.return = function (arg) {
    return this._invoke("return", arg);
  };

  return {
    wrap: function (fn) {
      return function () {
        return new AsyncGenerator(fn.apply(this, arguments));
      };
    },
    await: function (value) {
      return new AwaitValue(value);
    }
  };
}();

var asyncGenerator = function () {
  function AwaitValue(value) {
    this.value = value;
  }

  function AsyncGenerator(gen) {
    var front, back;

    function send(key, arg) {
      return new Promise(function (resolve, reject) {
        var request = {
          key: key,
          arg: arg,
          resolve: resolve,
          reject: reject,
          next: null
        };

        if (back) {
          back = back.next = request;
        } else {
          front = back = request;
          resume(key, arg);
        }
      });
    }

    function resume(key, arg) {
      try {
        var result = gen[key](arg);
        var value = result.value;

        if (value instanceof AwaitValue) {
          Promise.resolve(value.value).then(function (arg) {
            resume("next", arg);
          }, function (arg) {
            resume("throw", arg);
          });
        } else {
          settle(result.done ? "return" : "normal", result.value);
        }
      } catch (err) {
        settle("throw", err);
      }
    }

    function settle(type, value) {
      switch (type) {
        case "return":
          front.resolve({
            value: value,
            done: true
          });
          break;

        case "throw":
          front.reject(value);
          break;

        default:
          front.resolve({
            value: value,
            done: false
          });
          break;
      }

      front = front.next;

      if (front) {
        resume(front.key, front.arg);
      } else {
        back = null;
      }
    }

    this._invoke = send;

    if (typeof gen.return !== "function") {
      this.return = undefined;
    }
  }

  if (typeof Symbol === "function" && Symbol.asyncIterator) {
    AsyncGenerator.prototype[Symbol.asyncIterator] = function () {
      return this;
    };
  }

  AsyncGenerator.prototype.next = function (arg) {
    return this._invoke("next", arg);
  };

  AsyncGenerator.prototype.throw = function (arg) {
    return this._invoke("throw", arg);
  };

  AsyncGenerator.prototype.return = function (arg) {
    return this._invoke("return", arg);
  };

  return {
    wrap: function wrap(fn) {
      return function () {
        return new AsyncGenerator(fn.apply(this, arguments));
      };
    },
    await: function _await(value) {
      return new AwaitValue(value);
    }
  };
}();

/* Credit to https://github.com/jonschlinkert/get-value MIT */
function getValueByPath(obj, path) {
  if (Object(obj) !== obj || typeof path === 'undefined') {
    return obj;
  }

  if (path in obj) {
    return obj[path];
  }

  var segs = path.split('.');
  var length = segs.length;
  if (!length) {
    return undefined;
  }
  var i = -1;

  while (obj && ++i < length) {
    var key = segs[i];
    while (key[key.length - 1] === '\\') {
      key = key.slice(0, -1) + "." + segs[++i];
    }
    obj = obj[key];
  }
  return obj;
}

/* Credit to https://github.com/Matt-Esch/string-template MIT */
var template = function () {
  var pattern = /\{\s*([.0-9a-zA-Z_]+)\s*\}/g;

  function render(string) {
    for (var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
      args[_key - 1] = arguments[_key];
    }

    if (args.length === 1 && _typeof(args[0]) === 'object') {
      args = args[0];
    }

    if (!args || !args.hasOwnProperty) {
      args = {};
    }

    return string.replace(pattern, function (match, i, index) {
      var result = null;

      if (string[index - 1] === '{' && string[index + match.length] === '}') {
        return i;
      }

      if (args.hasOwnProperty(i)) {
        result = args[i];
      } else if (i.indexOf('.') !== -1) {
        result = getValueByPath(args, i);
      }

      if (result === null || result === undefined) {
        return '';
      }

      return result;
    });
  }

  return {
    render: render,
    compile: function compile(str) {
      return function () {
        for (var _len2 = arguments.length, args = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
          args[_key2] = arguments[_key2];
        }

        return render.apply(undefined, [str].concat(args));
      };
    },
    parse: function parse(str) {
      var matches = str.match(pattern);

      if (matches === null) {
        return false;
      }

      var parsed = [];
      for (var i = 0; i < matches.length; i++) {
        if (!matches[i].match(/^\{\{.+\}\}$/g)) {
          parsed.push(matches[i].substring(1, matches[i].length - 1).trim());
        }
      }

      return parsed;
    }
  };
}();

exports['default'] = template;

Object.defineProperty(exports, '__esModule', { value: true });

})));

(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@pluginjs/utils'), require('@pluginjs/template')) :
	typeof define === 'function' && define.amd ? define(['exports', '@pluginjs/utils', '@pluginjs/template'], factory) :
	(factory((global['@pluginjs/i18n'] = {}),global['@pluginjs/utils'],global['@pluginjs/template']));
}(this, (function (exports,utils,template) { 'use strict';

template = template && template.hasOwnProperty('default') ? template['default'] : template;

var asyncGenerator = function () {
  function AwaitValue(value) {
    this.value = value;
  }

  function AsyncGenerator(gen) {
    var front, back;

    function send(key, arg) {
      return new Promise(function (resolve, reject) {
        var request = {
          key: key,
          arg: arg,
          resolve: resolve,
          reject: reject,
          next: null
        };

        if (back) {
          back = back.next = request;
        } else {
          front = back = request;
          resume(key, arg);
        }
      });
    }

    function resume(key, arg) {
      try {
        var result = gen[key](arg);
        var value = result.value;

        if (value instanceof AwaitValue) {
          Promise.resolve(value.value).then(function (arg) {
            resume("next", arg);
          }, function (arg) {
            resume("throw", arg);
          });
        } else {
          settle(result.done ? "return" : "normal", result.value);
        }
      } catch (err) {
        settle("throw", err);
      }
    }

    function settle(type, value) {
      switch (type) {
        case "return":
          front.resolve({
            value: value,
            done: true
          });
          break;

        case "throw":
          front.reject(value);
          break;

        default:
          front.resolve({
            value: value,
            done: false
          });
          break;
      }

      front = front.next;

      if (front) {
        resume(front.key, front.arg);
      } else {
        back = null;
      }
    }

    this._invoke = send;

    if (typeof gen.return !== "function") {
      this.return = undefined;
    }
  }

  if (typeof Symbol === "function" && Symbol.asyncIterator) {
    AsyncGenerator.prototype[Symbol.asyncIterator] = function () {
      return this;
    };
  }

  AsyncGenerator.prototype.next = function (arg) {
    return this._invoke("next", arg);
  };

  AsyncGenerator.prototype.throw = function (arg) {
    return this._invoke("throw", arg);
  };

  AsyncGenerator.prototype.return = function (arg) {
    return this._invoke("return", arg);
  };

  return {
    wrap: function (fn) {
      return function () {
        return new AsyncGenerator(fn.apply(this, arguments));
      };
    },
    await: function (value) {
      return new AwaitValue(value);
    }
  };
}();





var classCallCheck = function (instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
};

var createClass = function () {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  return function (Constructor, protoProps, staticProps) {
    if (protoProps) defineProperties(Constructor.prototype, protoProps);
    if (staticProps) defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();

var I18N = function () {
  function I18N(defaults$$1, translations) {
    classCallCheck(this, I18N);

    this.defaults = utils.deepMerge({}, I18N.defaults, defaults$$1);

    this.translations = translations ? translations : {};
  }

  createClass(I18N, [{
    key: 'hasTranslation',
    value: function hasTranslation(locale) {
      return locale in this.translations;
    }
  }, {
    key: 'addTranslation',
    value: function addTranslation(locale, translation) {
      if (this.translations[locale]) {
        Object.assign(this.translations[locale], translation);
      } else {
        this.translations[locale] = translation;
      }
    }
  }, {
    key: 'getTranslation',
    value: function getTranslation(locale) {
      if (this.translations[locale]) {
        return this.translations[locale];
      }
      return {};
    }
  }, {
    key: 'instance',
    value: function instance() {
      var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      var that = this;

      var _options = Object.assign({}, that.defaults, options);
      var _locale = _options.locale;

      function getMessage(key, locale) {
        var translation = that.getTranslation(locale);
        var message = utils.getValueByPath(translation, key);

        return message;
      }

      return {
        translate: function translate(key) {
          var args = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
          var locale = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : _locale;

          var message = getMessage(key, locale);

          if (message === undefined && _options.fallbacks) {
            var locales = locale.split('-');
            if (locales.length > 1 && that.hasTranslation(locales[0])) {
              message = getMessage(key, locales[0]);
            }

            if (message === undefined) {
              var fallbackLocale = void 0;
              if (_options.fallbacks !== true && that.hasTranslation(_options.fallbacks)) {
                fallbackLocale = _options.fallbacks;
              } else {
                fallbackLocale = that.defaults.locale;
              }

              message = getMessage(key, fallbackLocale);
            }
          }

          if (Object.prototype.toString.call(message) === '[object Array]' && message.length >= 2) {
            if (typeof args._number === 'string') {
              if (typeof args[args._number] !== 'undefined') {
                var _number = parseInt(args[args._number], 10);

                if (_number === 1) {
                  message = message[0];
                } else if (_number > 1) {
                  message = message[1];
                } else if (_number === 0 && message.length >= 3) {
                  message = message[2];
                }
              }
            }
          }

          if (typeof message === 'string') {
            var parsed = template.parse(message);
            if (!parsed) {
              return message;
            }
            var _key = void 0;
            for (var i = 0; i < parsed.length; i++) {
              _key = parsed[i];
              if (typeof args[_key] === 'undefined') {
                args[_key] = _options.missingPlaceholder(_key);
              } else if (args[_key] === null) {
                args[_key] = _options.nullPlaceholder(_key);
              }
            }
            return template.render(message, args);
          }

          if (Object(message) === message) {
            return message;
          }

          return '[missing "' + locale + '.' + key + '" translation]';
        },
        setLocale: function setLocale(locale) {
          _locale = locale;
        },
        getLocale: function getLocale() {
          return _locale;
        }
      };
    }
  }, {
    key: 'setTranslations',
    value: function setTranslations(translations) {
      this.translations = translations;
    }
  }]);
  return I18N;
}();

I18N.defaults = {
  locale: 'en',
  fallbacks: true,
  nullPlaceholder: function nullPlaceholder(key) {
    return '[missing {{' + key + '}} value]';
  },
  missingPlaceholder: function missingPlaceholder(key) {
    return '[missing {{' + key + '}} value]';
  }
};

exports['default'] = I18N;

Object.defineProperty(exports, '__esModule', { value: true });

})));

(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@pluginjs/emitter'), require('@pluginjs/global-plugin'), require('@pluginjs/i18n'), require('@pluginjs/is'), require('@pluginjs/utils')) :
	typeof define === 'function' && define.amd ? define(['exports', '@pluginjs/emitter', '@pluginjs/global-plugin', '@pluginjs/i18n', '@pluginjs/is', '@pluginjs/utils'], factory) :
	(factory((global['@pluginjs/pluginjs'] = {}),global['@pluginjs/emitter'],global['@pluginjs/global-plugin'],global['@pluginjs/i18n'],global['@pluginjs/is'],global['@pluginjs/utils']));
}(this, (function (exports,Emitter,GlobalComponent,I18N,is,utils) { 'use strict';

Emitter = Emitter && Emitter.hasOwnProperty('default') ? Emitter['default'] : Emitter;
GlobalComponent = GlobalComponent && GlobalComponent.hasOwnProperty('default') ? GlobalComponent['default'] : GlobalComponent;
I18N = I18N && I18N.hasOwnProperty('default') ? I18N['default'] : I18N;
is = is && is.hasOwnProperty('default') ? is['default'] : is;

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) {
  return typeof obj;
} : function (obj) {
  return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
};





var asyncGenerator = function () {
  function AwaitValue(value) {
    this.value = value;
  }

  function AsyncGenerator(gen) {
    var front, back;

    function send(key, arg) {
      return new Promise(function (resolve, reject) {
        var request = {
          key: key,
          arg: arg,
          resolve: resolve,
          reject: reject,
          next: null
        };

        if (back) {
          back = back.next = request;
        } else {
          front = back = request;
          resume(key, arg);
        }
      });
    }

    function resume(key, arg) {
      try {
        var result = gen[key](arg);
        var value = result.value;

        if (value instanceof AwaitValue) {
          Promise.resolve(value.value).then(function (arg) {
            resume("next", arg);
          }, function (arg) {
            resume("throw", arg);
          });
        } else {
          settle(result.done ? "return" : "normal", result.value);
        }
      } catch (err) {
        settle("throw", err);
      }
    }

    function settle(type, value) {
      switch (type) {
        case "return":
          front.resolve({
            value: value,
            done: true
          });
          break;

        case "throw":
          front.reject(value);
          break;

        default:
          front.resolve({
            value: value,
            done: false
          });
          break;
      }

      front = front.next;

      if (front) {
        resume(front.key, front.arg);
      } else {
        back = null;
      }
    }

    this._invoke = send;

    if (typeof gen.return !== "function") {
      this.return = undefined;
    }
  }

  if (typeof Symbol === "function" && Symbol.asyncIterator) {
    AsyncGenerator.prototype[Symbol.asyncIterator] = function () {
      return this;
    };
  }

  AsyncGenerator.prototype.next = function (arg) {
    return this._invoke("next", arg);
  };

  AsyncGenerator.prototype.throw = function (arg) {
    return this._invoke("throw", arg);
  };

  AsyncGenerator.prototype.return = function (arg) {
    return this._invoke("return", arg);
  };

  return {
    wrap: function (fn) {
      return function () {
        return new AsyncGenerator(fn.apply(this, arguments));
      };
    },
    await: function (value) {
      return new AwaitValue(value);
    }
  };
}();





var classCallCheck = function (instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
};

var createClass = function () {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  return function (Constructor, protoProps, staticProps) {
    if (protoProps) defineProperties(Constructor.prototype, protoProps);
    if (staticProps) defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();







var _extends = Object.assign || function (target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];

    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }

  return target;
};













var objectWithoutProperties = function (obj, keys) {
  var target = {};

  for (var i in obj) {
    if (keys.indexOf(i) >= 0) continue;
    if (!Object.prototype.hasOwnProperty.call(obj, i)) continue;
    target[i] = obj[i];
  }

  return target;
};







var slicedToArray = function () {
  function sliceIterator(arr, i) {
    var _arr = [];
    var _n = true;
    var _d = false;
    var _e = undefined;

    try {
      for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
        _arr.push(_s.value);

        if (i && _arr.length === i) break;
      }
    } catch (err) {
      _d = true;
      _e = err;
    } finally {
      try {
        if (!_n && _i["return"]) _i["return"]();
      } finally {
        if (_d) throw _e;
      }
    }

    return _arr;
  }

  return function (arr, i) {
    if (Array.isArray(arr)) {
      return arr;
    } else if (Symbol.iterator in Object(arr)) {
      return sliceIterator(arr, i);
    } else {
      throw new TypeError("Invalid attempt to destructure non-iterable instance");
    }
  };
}();

var find = utils.curry(function (selector, parent) {
  return parent.querySelector(selector);
});

var finds = utils.curry(function (selector, parent) {
  return Array.from(parent.querySelectorAll(selector));
});

var remove = function remove(el) {
  return el.remove();
};

var html = utils.curry(function (content, el) {
  el.innerHTML = content;
  return el;
});

var children = function children(el) {
  return Array.from(el.children);
};















var parent = function parent(el) {
  return el.parentNode;
};
// 解析 HTML/SVG/XML 字符串
var parseHTML = function parseHTML() {
  for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }

  var htmlString = Array.isArray(args[0]) ? args[0].reduce(function (result, str, index) {
    return result + args[index] + str;
  }) : args[0];
  var childNodes = utils.compose(children, html(htmlString))(document.createElement('div'));
  if (childNodes.length === 1) {
    return childNodes[0];
  }
  return childNodes;
};











var next = function next(el) {
  return el.nextElementSibling;
};

var attr = utils.curry(function (args, el) {
  if (typeof args === 'string') {
    return el.getAttribute(args);
  }
  Object.entries(args).forEach(function (_ref5) {
    var _ref6 = slicedToArray(_ref5, 2),
        k = _ref6[0],
        v = _ref6[1];

    return el.setAttribute(k, v);
  });
  return el;
});
var removeAttribute = utils.curry(function (name, el) {
  return el.removeAttribute(name);
});

var dataset = utils.curry(function (args, el) {
  if (typeof args === 'string') {
    return el.dataset[args];
  }
  Object.entries(args).forEach(function (_ref7) {
    var _ref8 = slicedToArray(_ref7, 2),
        k = _ref8[0],
        v = _ref8[1];

    el.dataset[k] = v;
  });
  return el;
});

var text = utils.curry(function (content, el) {
  el.textContent = content;
  return el;
});

var append = utils.curry(function (child, el) {
  if (is.string(child)) {
    el.insertAdjacentHTML('beforeend', child);
  } else {
    el.append(child);
  }
  return el;
});

var prepend = utils.curry(function (child, el) {
  if (is.string(child)) {
    el.insertAdjacentHTML('afterbegin', child);
  } else {
    el.prepend(child);
  }
  return el;
});

var insertBefore = utils.curry(function (newElement, el) {
  if (is.string(newElement)) {
    el.insertAdjacentHTML('beforebegin', newElement);
  } else {
    el.insertAdjacentElement('beforebegin', newElement);
  }
  return el;
});

var insertAfter = utils.curry(function (newElement, el) {
  if (is.string(newElement)) {
    el.insertAdjacentHTML('afterend', newElement);
  } else {
    el.insertAdjacentElement('afterend', newElement);
  }
  return el;
});

var wrap = utils.curry(function (wrapElement, el) {
  if (is.string(wrapElement)) {
    wrapElement = parseHTML(wrapElement);
  }
  // compose(append(wrapElement), clone, insertBefore(wrapElement))(el)
  insertBefore(wrapElement, el);
  remove(el);
  append(el, wrapElement);
  return wrapElement;
});









var parentWith = utils.curry(function (fn, el) {
  var parentElement = parent(el);
  if (parentElement === document) {
    return false;
  }
  if (fn(parentElement)) {
    return parentElement;
  }
  return parentWith(fn, parentElement);
});



var contains = utils.curry(function (el, parent) {
  return parent.contains(el);
});

var closest = utils.curry(function (selector, el) {
  if (el.matches(selector)) {
    return el;
  }
  return parentWith(function (el) {
    return el.matches(selector);
  }, el);
});

var nextElementWith = utils.curry(function (fn, el) {
  var nextElement = next(el);
  if (fn(nextElement)) {
    return nextElement;
  }
  return nextElementWith(fn, nextElement);
});

var outputIdentity = function outputIdentity(identity) {
  if (!identity) {
    return { type: 'self', value: '' };
  }
  if (typeof identity === 'string') {
    return { type: 'selector', value: identity };
  }

  return identity;
};

var tupleToStyleSelector = function tupleToStyleSelector(tuple, prefix) {
  if (typeof tuple === 'string') {
    return tuple;
  }
  return Object.entries(tuple).map(function (kv) {
    return '[' + prefix + kv.join('=') + ']';
  }).join('');
};

var dispatch = function dispatch(event) {
  var target = event.target,
      currentTarget = event.currentTarget;

  var eventStorage = EventStorage.getEventStorage(currentTarget);
  var eventName = event.type;

  var attrVerify$$1 = {
    self: function self(node) {
      return node === currentTarget;
    },
    class: function _class(node, value) {
      return node.matches('.' + value);
    },
    selector: function selector(node, value) {
      return node.matches(value);
    },
    id: function id(node, value) {
      return node.matches('#' + value);
    },
    tagName: function tagName(node, value) {
      return node.matches(value);
    },
    dom: function dom(node, value) {
      return node === value;
    },
    dataset: function dataset$$1(node, value) {
      return node.matches(tupleToStyleSelector(value, 'data-'));
    },
    attribute: function attribute(node, value) {
      return node.matches(tupleToStyleSelector(value));
    },
    func: function func(node, value) {
      return Boolean(value(node));
    }
  };

  var nodeTreeCheck = function nodeTreeCheck(node) {
    var result = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];

    if (!currentTarget.contains(node)) {
      return result;
    }

    var matchEventList = eventStorage.listeners[eventName].filter(function (_ref) {
      var identity = _ref.identity;
      var type = identity.type,
          value = identity.value;

      var identityMapper = attrVerify$$1[type];
      if (identityMapper && identityMapper(node, value)) {
        return true;
      }
      return false;
    });
    return nodeTreeCheck(parent(node), result.concat(matchEventList));
  };
  // nodeTreeCheck(target).map(e => console.log(e.handler.toString()))
  nodeTreeCheck(target).reduce(function (result, _ref2) {
    var handler = _ref2.handler;
    return result !== false && handler(event);
  }, true);
};

var EventStorage = function () {
  function EventStorage(element) {
    classCallCheck(this, EventStorage);

    this.element = element;
    this.listeners = {};
  }

  createClass(EventStorage, [{
    key: 'on',
    value: function on(_ref3) {
      var identity = _ref3.identity,
          handler = _ref3.handler,
          eventName = _ref3.eventName,
          namespace = _ref3.namespace;

      this.ensureHandler(handler);

      if (!this.hasListeners(eventName)) {
        this.createEventListener(eventName);
      }

      if (this.checkRepeats(eventName, handler)) {
        return;
      }

      this.listeners[eventName].push({ identity: identity, handler: handler, namespace: namespace });
    }
  }, {
    key: 'once',
    value: function once(_ref4) {
      var _this = this;

      var identity = _ref4.identity,
          handler = _ref4.handler,
          eventName = _ref4.eventName,
          namespace = _ref4.namespace;

      this.ensureHandler(handler);

      if (!this.hasListeners(eventName)) {
        this.createEventListener(eventName);
      }

      var callback = function callback(event) {
        _this.removeListener(eventName, callback);

        return handler(event);
      };

      this.listeners[eventName].push({ identity: identity, handler: callback, namespace: namespace });
    }
  }, {
    key: 'off',
    value: function off(_eventName, handler) {
      if (typeof handler === 'undefined') {
        return this.removeAllListeners(_eventName);
      }
      return this.removeListener(_eventName, handler);
    }
  }, {
    key: 'trigger',
    value: function trigger(eventName, data) {
      var event = new CustomEvent(eventName, {
        detail: data
      });
      this.element.dispatchEvent(event);
    }
  }, {
    key: 'clear',
    value: function clear() {
      var _this2 = this;

      Object.entries(this.listeners).map(function (_ref5) {
        var _ref6 = slicedToArray(_ref5, 2),
            key = _ref6[0];

        _this2.deleteEventListener(key);
      });

      this.listener = {};
    }
  }, {
    key: 'removeListener',
    value: function removeListener(_eventName, handler) {
      var _this3 = this;

      var _eventName$split = _eventName.split('.'),
          _eventName$split2 = slicedToArray(_eventName$split, 2),
          eventName = _eventName$split2[0],
          namespace = _eventName$split2[1];
      //   .example  || click  || click.example


      if (!eventName && namespace) {
        Object.entries(this.listeners).map(function (_ref7) {
          var _ref8 = slicedToArray(_ref7, 2),
              key = _ref8[0];

          _this3.listeners[key] = _this3.listeners[key].filter(function (eventTuple) {
            return eventTuple.handler !== handler || eventTuple.namespace !== namespace;
          });

          if (_this3.listeners[key].length === 0) {
            _this3.deleteEventListener(key);
          }
        });
      } else if (eventName && !namespace) {
        // console.log('eventName')
        this.listeners[eventName] = this.listeners[eventName].filter(function (eventTuple) {
          return eventTuple.handler !== handler;
        });

        if (this.listeners[eventName].length === 0) {
          this.deleteEventListener(eventName);
        }
      } else if (eventName && namespace) {
        this.listeners[eventName] = this.listeners[eventName].filter(function (eventTuple) {
          return eventTuple.handler !== handler || eventTuple.namespace !== namespace;
        });

        if (this.listeners[eventName].length === 0) {
          this.deleteEventListener(eventName);
        }
      }
    }
  }, {
    key: 'removeAllListeners',
    value: function removeAllListeners(_eventName) {
      var _this4 = this;

      var _eventName$split3 = _eventName.split('.'),
          _eventName$split4 = slicedToArray(_eventName$split3, 2),
          eventName = _eventName$split4[0],
          namespace = _eventName$split4[1];
      //   .example  || click  || click.example


      if (!eventName && namespace) {
        Object.entries(this.listeners).map(function (_ref9) {
          var _ref10 = slicedToArray(_ref9, 2),
              key = _ref10[0];

          _this4.listeners[key] = _this4.listeners[key].filter(function (eventTuple) {
            return eventTuple.namespace !== namespace;
          });

          if (_this4.listeners[key].length === 0) {
            _this4.deleteEventListener(key);
          }
        });
      } else if (eventName && !namespace) {
        this.deleteEventListener(eventName);
      } else if (eventName && namespace && this.listeners[eventName]) {
        this.listeners[eventName] = this.listeners[eventName].filter(function (eventTuple) {
          return eventTuple.namespace !== namespace;
        });

        if (this.listeners[eventName].length === 0) {
          this.deleteEventListener(eventName);
        }
      }

      return this;
    }
  }, {
    key: 'createEventListener',
    value: function createEventListener(eventName) {
      this.listeners[eventName] = [];
      this.element.addEventListener(eventName, dispatch, false);
    }
  }, {
    key: 'deleteEventListener',
    value: function deleteEventListener(eventName) {
      this.element.removeEventListener(eventName, dispatch);
      delete this.listeners[eventName];
    }
  }, {
    key: 'checkRepeats',
    value: function checkRepeats(eventName, handler) {
      return this.listeners[eventName].filter(function (value) {
        return value.handler === handler;
      }).length !== 0;
    }
  }, {
    key: 'hasListeners',
    value: function hasListeners(eventName) {
      if (!this.listeners[eventName] || Object.keys(this.listeners[eventName]).length === 0) {
        return false;
      }

      return true;
    }
  }, {
    key: 'ensureHandler',
    value: function ensureHandler(handler) {
      var type = typeof handler === 'undefined' ? 'undefined' : _typeof(handler);
      if (type === 'function') {
        return handler;
      }
      throw new TypeError('Listeners should be function or closure. Received type: ' + type);
    }
  }], [{
    key: 'of',
    value: function of(_ref11, element) {
      var _eventName = _ref11.type,
          identity = _ref11.identity,
          handler = _ref11.handler;

      if (!element.__eventStorage) {
        element.__eventStorage = new this(element);
      }

      var _eventName$split5 = _eventName.split('.'),
          _eventName$split6 = slicedToArray(_eventName$split5, 2),
          eventName = _eventName$split6[0],
          namespace = _eventName$split6[1];

      var eventStorage = this.getEventStorage(element);

      eventStorage.on({
        identity: outputIdentity(identity),
        handler: handler,
        eventName: eventName,
        namespace: namespace
      });
    }
  }, {
    key: 'once',
    value: function once(_ref12, element) {
      var _eventName = _ref12.type,
          identity = _ref12.identity,
          handler = _ref12.handler;

      if (!element.__eventStorage) {
        element.__eventStorage = new this(element);
      }

      var _eventName$split7 = _eventName.split('.'),
          _eventName$split8 = slicedToArray(_eventName$split7, 2),
          eventName = _eventName$split8[0],
          namespace = _eventName$split8[1];

      var eventStorage = this.getEventStorage(element);

      eventStorage.once({
        identity: outputIdentity(identity),
        handler: handler,
        eventName: eventName,
        namespace: namespace
      });
    }
  }, {
    key: 'delete',
    value: function _delete(options, element) {
      var eventStorage = this.getEventStorage(element);
      if (!eventStorage) {
        return;
      }

      var _options$type = options.type,
          _eventName = _options$type === undefined ? options : _options$type,
          handler = options.handler;

      eventStorage.off(_eventName, handler);
    }
  }, {
    key: 'getEventStorage',
    value: function getEventStorage(element) {
      return element.__eventStorage;
    }
  }]);
  return EventStorage;
}();

var trigger = utils.curry(function (options, el) {
  var _options$type = options.type,
      type = _options$type === undefined ? options : _options$type,
      data = options.data;

  var eventName = type;

  var eventStorage = EventStorage.getEventStorage(el);
  if (eventStorage && eventStorage.hasListeners(eventName)) {
    eventStorage.trigger(eventName, data);
  }

  return el;
});
/**
 * bindEvent ({
 *   type: 'example:CustomEvent',
 *   handler: event => {
 *     let { instance } = event.detail
 *   }
 * }, elemment)
 *
 * trigger({
 *   type: 'example:CustomEvent',
 *   data: {instance: this}
 * }, elemment)
 */

var bindEvent = utils.curry(function (options, element) {
  EventStorage.of(options, element);
  return element;
});
/**
 * bindEvent ({
 *   type: eventName,
 *   handler
 * }, el)
 * bindEvent ({
 *   type: eventName,
 *   identity: '.className',
 *   handler
 * }, el)
 * bindEvent ({
 *   type,
 *   identity: {
 *     type: '[selector |class | id | attr | dataset]',
 *     value
 *   },
 *   handler
 * }, el)
 * example:
 * <li><a href="#" data-test="example">test</a></li>
 * bindEvent ({
 *   type,
 *   identity: {
 *     type: 'dataset',
 *     value: {test: 'example'}
 *   },
 *   handler
 * }, el)
 */
var removeEvent = utils.curry(function (options, element) {
  EventStorage.delete(options, element);
  return element;
});
/**
 * removeEvent (this.eventName(), el)
 * removeEvent (eventName, el)
 * removeEvent ({
 *   type: [this.eventName() || eventName],
 *   handler
 * }, el)
 */
var bindEventOnce = utils.curry(function (options, element) {
  EventStorage.once(options, element);
  return element;
});

// import './polyfills'
var envParamters = {
  body: window.document.body,
  doc: window.document
};

if (!window.Pj) {
  window.Pj = _extends({}, envParamters, {
    emitter: new Emitter(),
    plugins: {},
    instances: {},
    get windowWidth() {
      return window.document.documentElement.clientWidth;
    },
    get windowHeight() {
      return window.document.documentElement.clientHeight;
    },
    get: function get$$1(name) {
      if (typeof this.plugins[name] !== 'undefined') {
        return this.plugins[name];
      }
      return null;
    }
  });
}

var Pj = window.Pj;

function globalResizeHandle() {
  Pj.emitter.emit('resize');
}

function globalScrollHanle() {
  Pj.emitter.emit('scroll');
}

function register(name) {
  var obj = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var info = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

  return function (plugin) {
    var _obj$defaults = obj.defaults,
        options = _obj$defaults === undefined ? {} : _obj$defaults,
        _obj$methods = obj.methods,
        methods = _obj$methods === undefined ? [] : _obj$methods,
        _obj$dependencies = obj.dependencies,
        dependencies = _obj$dependencies === undefined ? {} : _obj$dependencies,
        others = objectWithoutProperties(obj, ['defaults', 'methods', 'dependencies']);


    if (Pj.get(name)) {
      /* eslint no-console: "off" */
      console.warn('Plugin \'' + name + '\' already exists.');
    }
    Pj.instances[name] = [];

    Pj.plugins[name] = Object.assign(plugin, _extends({
      setDefaults: function setDefaults() {
        var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        plugin.defaults = utils.deepMerge(plugin.defaults, options);
      },

      defaults: plugin.defaults ? utils.deepMerge(plugin.defaults, options) : options,
      methods: plugin.methods ? utils.deepMerge(plugin.methods, methods) : methods,
      dependencies: plugin.dependencies ? utils.deepMerge(plugin.dependencies, dependencies) : dependencies
    }, others), info);

    if (dependencies.length > 0) {
      var dependency = void 0;
      for (var i = 0; i < dependencies.length; i++) {
        dependency = dependencies[i];

        if (is.undefined(window[dependency]) && is.undefined(Pj.plugins[dependency])) {
          /* eslint no-console: "off" */
          console.warn('Plugin \'' + name + '\' require \'' + dependency + '\'.');
        }
      }
    }

    if (plugin.prototype.resize && is.undefined(plugin.resize)) {
      plugin.resize = function () {
        var instances = Pj.instances[name];

        for (var _i = 0; _i < instances.length; _i++) {
          instances[_i].resize(Pj.windowWidth, Pj.windowHeight);
        }
      };
    }

    if (is.function(plugin.resize)) {
      Pj.emitter.on('resize', plugin.resize);
    }

    if (plugin.prototype instanceof GlobalComponent) {
      Pj[name] = plugin;
    } else {
      Pj[name] = function (selector, options) {
        for (var _len = arguments.length, args = Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
          args[_key - 2] = arguments[_key];
        }

        var elements = typeof selector === 'string' ? Array.from(document.querySelectorAll(selector)) : [selector];
        if (!elements) {
          throw new Error('element is not exists');
        }

        var APIS = [];
        var apiCallback = function apiCallback(method) {
          for (var _len2 = arguments.length, args = Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
            args[_key2 - 1] = arguments[_key2];
          }

          var res = [];
          APIS.map(function (api) {
            res.push(api.apply(undefined, [method].concat(args)));
          });
          if (res.length !== 1) {
            return res;
          }
          return res[0];
        };

        elements.forEach(function (element) {
          var instance = new plugin(element, options);
          var API = function API(method) {
            for (var _len3 = arguments.length, args = Array(_len3 > 1 ? _len3 - 1 : 0), _key3 = 1; _key3 < _len3; _key3++) {
              args[_key3 - 1] = arguments[_key3];
            }

            if (!methods.includes(method)) {
              throw new Error('not find method: ' + method);
            }

            if (/^get/.test(method) || /^is/.test(method) || method === 'val' && args.length === 0) {
              if (instance && typeof instance[method] === 'function') {
                return instance[method].apply(instance, args);
              }
              return element;
            }

            if (typeof instance[method] === 'function') {
              return instance[method].apply(instance, args);
            }
          };
          APIS.push(API);
        });
        return apiCallback;
      };
    }
    return plugin;
  };
}

function stateable() {
  return function (plugin) {
    plugin.prototype.initStates = function () {
      var states = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      this._states = states;
    };

    // Checks whether the plugin is in a specific state or not.
    plugin.prototype.is = function (state) {
      if (this._states[state] && this._states[state] > 0) {
        return true;
      }
      return false;
    };

    // Enters a state.
    plugin.prototype.enter = function (state) {
      if (this._states[state] === undefined) {
        this._states[state] = 0;
      }

      // this._states[state]++;
      this._states[state] = 1;
    };

    // Leaves a state.
    plugin.prototype.leave = function (state) {
      if (this._states[state] === undefined) {
        this._states[state] = 0;
      }

      // this._states[state]--;
      this._states[state] = 0;
    };
  };
}

function eventable() {
  var events = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

  return function (plugin) {
    plugin.events = events;

    plugin.setEvents = function () {
      var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      utils.deepMerge(plugin.events, options);
    };

    plugin.prototype.eventName = function (events) {
      if (typeof events !== 'string' || events === '') {
        return '.' + this.plugin;
      }
      events = events.split(' ');

      var length = events.length;
      for (var i = 0; i < length; i++) {
        events[i] = events[i] + '.' + this.plugin;
      }
      return events.join(' ');
    };

    plugin.prototype.eventNameWithId = function (events) {
      if (typeof events !== 'string' || events === '') {
        return '.' + this.plugin + '-' + this.instanceId;
      }

      events = events.split(' ');

      var length = events.length;
      for (var i = 0; i < length; i++) {
        events[i] = events[i] + '.' + this.plugin + '-' + this.instanceId;
      }
      return events.join(' ');
    };

    plugin.prototype.trigger = function (eventType) {
      for (var _len4 = arguments.length, params = Array(_len4 > 1 ? _len4 - 1 : 0), _key4 = 1; _key4 < _len4; _key4++) {
        params[_key4 - 1] = arguments[_key4];
      }

      if (eventType instanceof Event) {
        trigger(eventType, this.element);
        var type = utils.camelize(eventType.type);
        var onFunction = 'on' + type;

        if (typeof this.options[onFunction] === 'function') {
          this.options[onFunction].apply(this, params);
        }
      } else {
        trigger({
          type: this.plugin + ':' + eventType,
          data: { instance: this, data: params }
        }, this.element);
        eventType = utils.camelize(eventType);
        var _onFunction = 'on' + eventType;

        if (typeof this.options[_onFunction] === 'function') {
          this.options[_onFunction].apply(this, params);
        }
      }
    };

    plugin.prototype.selfEventName = function (eventType) {
      return this.plugin + ':' + eventType;
    };
  };
}

function themeable() {
  return function (plugin) {
    plugin.prototype.getThemeClass = function (themes, THEME) {
      if (is.undefined(themes) && this.options.theme) {
        return this.getThemeClass(this.options.theme);
      }
      if (is.string(themes)) {
        if (is.undefined(THEME)) {
          THEME = this.classes.THEME;
        }
        themes = themes.split(' ');

        if (THEME) {
          for (var i = 0; i < themes.length; i++) {
            themes[i] = THEME.replace('{theme}', themes[i]);
          }
        } else {
          for (var _i2 = 0; _i2 < themes.length; _i2++) {
            themes[_i2] = this.getClass(themes[_i2]);
          }
        }
        return themes.join(' ');
      }

      return '';
    };
  };
}

function styleable() {
  var classes = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

  return function (plugin) {
    plugin.classes = classes;
    plugin.setClasses = function () {
      var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      utils.deepMerge(plugin.classes, options);
    };

    plugin.prototype.getClass = function (classname, arg, value) {
      if (!is.undefined(arg)) {
        return this.getClass(classname.replace('{' + arg + '}', value));
      }
      return classname.replace('{namespace}', this.classes.NAMESPACE || '');
    };

    plugin.prototype.initClasses = function (defaults$$1, options) {
      var _this = this;

      if (is.undefined(options) && is.object(this.options.classes)) {
        options = this.options.classes;
      }

      function conventKeyToUpperCase(obj) {
        var upperObj = {};
        for (var name in obj) {
          if (Object.hasOwnProperty.call(obj, name)) {
            if (is.string(obj[name])) {
              upperObj[name.toUpperCase()] = obj[name];
            } else if (is.object(obj[name])) {
              upperObj[name.toUpperCase()] = conventKeyToUpperCase(obj[name]);
            }
          }
        }
        return upperObj;
      }

      this.classes = utils.deepMerge({}, defaults$$1, conventKeyToUpperCase(options || {}));

      if (!is.undefined(this.classes.NAMESPACE)) {
        var injectNamespace = function injectNamespace(obj) {
          for (var name in obj) {
            if (Object.hasOwnProperty.call(obj, name)) {
              if (is.string(obj[name])) {
                obj[name] = _this.getClass(obj[name]);
              } else if (is.object(obj[name])) {
                obj[name] = injectNamespace(obj[name]);
              }
            }
          }
          return obj;
        };

        this.classes = injectNamespace(this.classes);
      }
    };
  };
}

function translateable(translations) {
  return function (plugin) {
    window.deepMerge = utils.deepMerge;
    plugin.I18N = new I18N({
      locale: plugin.defaults.locale,
      fallbacks: plugin.defaults.localeFallbacks
    }, translations);
    Object.assign(plugin.prototype, {
      setupI18n: function setupI18n() {
        this.i18n = plugin.I18N.instance({
          locale: this.options.locale,
          fallbacks: this.options.localeFallbacks
        });
      },
      translate: function translate(key, args) {
        return this.i18n.translate(key, args);
      },
      setLocale: function setLocale(locale) {
        return this.i18n.setLocale(locale);
      },
      getLocale: function getLocale() {
        return this.i18n.getLocale();
      }
    });
  };
}

window.addEventListener('orientationchange', globalResizeHandle);
window.addEventListener('resize', utils.throttle(globalResizeHandle));
window.addEventListener('scroll', utils.throttle(globalScrollHanle));

exports.register = register;
exports.stateable = stateable;
exports.eventable = eventable;
exports.themeable = themeable;
exports.styleable = styleable;
exports.translateable = translateable;
exports['default'] = Pj;

Object.defineProperty(exports, '__esModule', { value: true });

})));

(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@pluginjs/pluginjs'), require('@pluginjs/is'), require('@pluginjs/utils')) :
	typeof define === 'function' && define.amd ? define(['exports', '@pluginjs/pluginjs', '@pluginjs/is', '@pluginjs/utils'], factory) :
	(factory((global['@pluginjs/color'] = {}),global['@pluginjs/pluginjs'],global['@pluginjs/is'],global['@pluginjs/utils']));
}(this, (function (exports,Pj,is,utils) { 'use strict';

Pj = Pj && Pj.hasOwnProperty('default') ? Pj['default'] : Pj;
is = is && is.hasOwnProperty('default') ? is['default'] : is;

var defaults = {
  format: false,
  shortenHex: false,
  hexUseName: false,
  reduceAlpha: false,
  alphaConvert: {
    // or false will disable convert
    RGB: 'RGBA',
    HSL: 'HSLA',
    HEX: 'RGBA',
    NAMESPACE: 'RGBA'
  },
  nameDegradation: 'HEX',
  invalidValue: '',
  zeroAlphaAsTransparent: true
};

var info = { version: '0.3.4' };

function expandHex(hex) {
  if (hex.indexOf('#') === 0) {
    hex = hex.substr(1);
  }
  if (!hex) {
    return null;
  }
  if (hex.length === 3) {
    hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
  }
  return hex.length === 6 ? '#' + hex : null;
}

function shrinkHex(hex) {
  if (hex.indexOf('#') === 0) {
    hex = hex.substr(1);
  }
  if (hex.length === 6 && hex[0] === hex[1] && hex[2] === hex[3] && hex[4] === hex[5]) {
    hex = hex[0] + hex[2] + hex[4];
  }
  return '#' + hex;
}

function parseIntFromHex(val) {
  return parseInt(val, 16);
}



function conventPercentageToRgb(n) {
  return parseInt(Math.round(n.slice(0, -1) * 2.55), 10);
}



function flip(o) {
  var flipped = {};
  for (var i in o) {
    if (o.hasOwnProperty(i)) {
      flipped[o[i]] = i;
    }
  }
  return flipped;
}

var NAMES = {
  aliceblue: 'f0f8ff',
  antiquewhite: 'faebd7',
  aqua: '0ff',
  aquamarine: '7fffd4',
  azure: 'f0ffff',
  beige: 'f5f5dc',
  bisque: 'ffe4c4',
  black: '000',
  blanchedalmond: 'ffebcd',
  blue: '00f',
  blueviolet: '8a2be2',
  brown: 'a52a2a',
  burlywood: 'deb887',
  burntsienna: 'ea7e5d',
  cadetblue: '5f9ea0',
  chartreuse: '7fff00',
  chocolate: 'd2691e',
  coral: 'ff7f50',
  cornflowerblue: '6495ed',
  cornsilk: 'fff8dc',
  crimson: 'dc143c',
  cyan: '0ff',
  darkblue: '00008b',
  darkcyan: '008b8b',
  darkgoldenrod: 'b8860b',
  darkgray: 'a9a9a9',
  darkgreen: '006400',
  darkgrey: 'a9a9a9',
  darkkhaki: 'bdb76b',
  darkmagenta: '8b008b',
  darkolivegreen: '556b2f',
  darkorange: 'ff8c00',
  darkorchid: '9932cc',
  darkred: '8b0000',
  darksalmon: 'e9967a',
  darkseagreen: '8fbc8f',
  darkslateblue: '483d8b',
  darkslategray: '2f4f4f',
  darkslategrey: '2f4f4f',
  darkturquoise: '00ced1',
  darkviolet: '9400d3',
  deeppink: 'ff1493',
  deepskyblue: '00bfff',
  dimgray: '696969',
  dimgrey: '696969',
  dodgerblue: '1e90ff',
  firebrick: 'b22222',
  floralwhite: 'fffaf0',
  forestgreen: '228b22',
  fuchsia: 'f0f',
  gainsboro: 'dcdcdc',
  ghostwhite: 'f8f8ff',
  gold: 'ffd700',
  goldenrod: 'daa520',
  gray: '808080',
  green: '008000',
  greenyellow: 'adff2f',
  grey: '808080',
  honeydew: 'f0fff0',
  hotpink: 'ff69b4',
  indianred: 'cd5c5c',
  indigo: '4b0082',
  ivory: 'fffff0',
  khaki: 'f0e68c',
  lavender: 'e6e6fa',
  lavenderblush: 'fff0f5',
  lawngreen: '7cfc00',
  lemonchiffon: 'fffacd',
  lightblue: 'add8e6',
  lightcoral: 'f08080',
  lightcyan: 'e0ffff',
  lightgoldenrodyellow: 'fafad2',
  lightgray: 'd3d3d3',
  lightgreen: '90ee90',
  lightgrey: 'd3d3d3',
  lightpink: 'ffb6c1',
  lightsalmon: 'ffa07a',
  lightseagreen: '20b2aa',
  lightskyblue: '87cefa',
  lightslategray: '789',
  lightslategrey: '789',
  lightsteelblue: 'b0c4de',
  lightyellow: 'ffffe0',
  lime: '0f0',
  limegreen: '32cd32',
  linen: 'faf0e6',
  magenta: 'f0f',
  maroon: '800000',
  mediumaquamarine: '66cdaa',
  mediumblue: '0000cd',
  mediumorchid: 'ba55d3',
  mediumpurple: '9370db',
  mediumseagreen: '3cb371',
  mediumslateblue: '7b68ee',
  mediumspringgreen: '00fa9a',
  mediumturquoise: '48d1cc',
  mediumvioletred: 'c71585',
  midnightblue: '191970',
  mintcream: 'f5fffa',
  mistyrose: 'ffe4e1',
  moccasin: 'ffe4b5',
  navajowhite: 'ffdead',
  navy: '000080',
  oldlace: 'fdf5e6',
  olive: '808000',
  olivedrab: '6b8e23',
  orange: 'ffa500',
  orangered: 'ff4500',
  orchid: 'da70d6',
  palegoldenrod: 'eee8aa',
  palegreen: '98fb98',
  paleturquoise: 'afeeee',
  palevioletred: 'db7093',
  papayawhip: 'ffefd5',
  peachpuff: 'ffdab9',
  peru: 'cd853f',
  pink: 'ffc0cb',
  plum: 'dda0dd',
  powderblue: 'b0e0e6',
  purple: '800080',
  red: 'f00',
  rosybrown: 'bc8f8f',
  royalblue: '4169e1',
  saddlebrown: '8b4513',
  salmon: 'fa8072',
  sandybrown: 'f4a460',
  seagreen: '2e8b57',
  seashell: 'fff5ee',
  sienna: 'a0522d',
  silver: 'c0c0c0',
  skyblue: '87ceeb',
  slateblue: '6a5acd',
  slategray: '708090',
  slategrey: '708090',
  snow: 'fffafa',
  springgreen: '00ff7f',
  steelblue: '4682b4',
  tan: 'd2b48c',
  teal: '008080',
  thistle: 'd8bfd8',
  tomato: 'ff6347',
  turquoise: '40e0d0',
  violet: 'ee82ee',
  wheat: 'f5deb3',
  white: 'fff',
  whitesmoke: 'f5f5f5',
  yellow: 'ff0',
  yellowgreen: '9acd32'
};

/* eslint no-bitwise: "off" */
var hexNames = flip(NAMES);

var Converter = {
  HSLtoRGB: function HSLtoRGB(hsl) {
    var h = hsl.h / 360;
    var s = hsl.s;
    var l = hsl.l;
    var m2 = void 0;
    if (l <= 0.5) {
      m2 = l * (s + 1);
    } else {
      m2 = l + s - l * s;
    }
    var m1 = l * 2 - m2;
    var rgb = {
      r: this.hueToRGB(m1, m2, h + 1 / 3),
      g: this.hueToRGB(m1, m2, h),
      b: this.hueToRGB(m1, m2, h - 1 / 3)
    };
    if (!is.undefined(hsl.a)) {
      rgb.a = hsl.a;
    }
    if (hsl.l === 0) {
      rgb.h = hsl.h;
    }
    if (hsl.l === 1) {
      rgb.h = hsl.h;
    }
    return rgb;
  },
  hueToRGB: function hueToRGB(m1, m2, h) {
    var v = void 0;
    if (h < 0) {
      h += 1;
    } else if (h > 1) {
      h -= 1;
    }
    if (h * 6 < 1) {
      v = m1 + (m2 - m1) * h * 6;
    } else if (h * 2 < 1) {
      v = m2;
    } else if (h * 3 < 2) {
      v = m1 + (m2 - m1) * (2 / 3 - h) * 6;
    } else {
      v = m1;
    }
    return Math.round(v * 255);
  },
  RGBtoHSL: function RGBtoHSL(rgb) {
    var r = rgb.r / 255;
    var g = rgb.g / 255;
    var b = rgb.b / 255;
    var min = Math.min(r, g, b);
    var max = Math.max(r, g, b);
    var diff = max - min;
    var add = max + min;
    var l = add * 0.5;
    var h = void 0;
    var s = void 0;

    if (min === max) {
      h = 0;
    } else if (r === max) {
      h = 60 * (g - b) / diff + 360;
    } else if (g === max) {
      h = 60 * (b - r) / diff + 120;
    } else {
      h = 60 * (r - g) / diff + 240;
    }
    if (diff === 0) {
      s = 0;
    } else if (l <= 0.5) {
      s = diff / add;
    } else {
      s = diff / (2 - add);
    }

    return {
      h: Math.round(h) % 360,
      s: s,
      l: l
    };
  },
  RGBtoHEX: function RGBtoHEX(rgb) {
    var hex = [rgb.r.toString(16), rgb.g.toString(16), rgb.b.toString(16)].map(function (val) {
      if (val.length === 1) {
        return '0' + val;
      }
      return val;
    });
    return '#' + hex.join('');
  },
  HSLtoHEX: function HSLtoHEX(hsl) {
    var rgb = this.HSLtoRGB(hsl);
    return this.RGBtoHEX(rgb);
  },
  HSVtoHEX: function HSVtoHEX(hsv) {
    var rgb = this.HSVtoRGB(hsv);
    return this.RGBtoHEX(rgb);
  },
  RGBtoHSV: function RGBtoHSV(rgb) {
    var r = rgb.r / 255;
    var g = rgb.g / 255;
    var b = rgb.b / 255;
    var max = Math.max(r, g, b);
    var min = Math.min(r, g, b);
    var h = void 0;
    var v = max;
    var diff = max - min;
    var s = max === 0 ? 0 : diff / max;
    if (max === min) {
      h = 0;
    } else {
      switch (max) {
        case r:
          {
            h = (g - b) / diff + (g < b ? 6 : 0);
            break;
          }
        case g:
          {
            h = (b - r) / diff + 2;
            break;
          }
        case b:
          {
            h = (r - g) / diff + 4;
            break;
          }
        default:
          {
            break;
          }
      }
      h /= 6;
    }

    return {
      h: Math.round(h * 360),
      s: s,
      v: v
    };
  },
  HSVtoRGB: function HSVtoRGB(hsv) {
    var r = void 0;
    var g = void 0;
    var b = void 0;
    var h = hsv.h % 360 / 60;
    var s = hsv.s;
    var v = hsv.v;
    var c = v * s;
    var x = c * (1 - Math.abs(h % 2 - 1));

    r = v - c;
    g = v - c;
    b = v - c;
    h = ~~h;

    r += [c, x, 0, 0, x, c][h];
    g += [x, c, c, x, 0, 0][h];
    b += [0, 0, x, c, c, x][h];

    var rgb = {
      r: Math.round(r * 255),
      g: Math.round(g * 255),
      b: Math.round(b * 255)
    };

    if (!is.undefined(hsv.a)) {
      rgb.a = hsv.a;
    }

    if (hsv.v === 0) {
      rgb.h = hsv.h;
    }

    if (hsv.v === 1 && hsv.s === 0) {
      rgb.h = hsv.h;
    }

    return rgb;
  },
  HEXtoRGB: function HEXtoRGB(hex) {
    if (hex.length === 4) {
      hex = expandHex(hex);
    }
    return {
      r: parseIntFromHex(hex.substr(1, 2)),
      g: parseIntFromHex(hex.substr(3, 2)),
      b: parseIntFromHex(hex.substr(5, 2))
    };
  },
  isNAME: function isNAME(string) {
    if (NAMES.hasOwnProperty(string)) {
      return true;
    }
    return false;
  },
  NAMEtoHEX: function NAMEtoHEX(name) {
    if (NAMES.hasOwnProperty(name)) {
      return '#' + NAMES[name];
    }
    return null;
  },
  NAMEtoRGB: function NAMEtoRGB(name) {
    var hex = this.NAMEtoHEX(name);

    if (hex) {
      return this.HEXtoRGB(hex);
    }
    return null;
  },
  hasNAME: function hasNAME(rgb) {
    var hex = this.RGBtoHEX(rgb);

    hex = shrinkHex(hex);

    if (hex.indexOf('#') === 0) {
      hex = hex.substr(1);
    }

    if (hexNames.hasOwnProperty(hex)) {
      return hexNames[hex];
    }
    return false;
  },
  RGBtoNAME: function RGBtoNAME(rgb) {
    var hasName = this.hasNAME(rgb);
    if (hasName) {
      return hasName;
    }

    return null;
  }
};

var CSS_INTEGER = '[-\\+]?\\d+%?';
var CSS_NUMBER = '[-\\+]?\\d*\\.\\d+%?';
var CSS_UNIT = '(?:' + CSS_NUMBER + ')|(?:' + CSS_INTEGER + ')';

var PERMISSIVE_MATCH3 = '[\\s|\\(]+(' + CSS_UNIT + ')[,|\\s]+(' + CSS_UNIT + ')[,|\\s]+(' + CSS_UNIT + ')\\s*\\)';
var PERMISSIVE_MATCH4 = '[\\s|\\(]+(' + CSS_UNIT + ')[,|\\s]+(' + CSS_UNIT + ')[,|\\s]+(' + CSS_UNIT + ')[,|\\s]+(' + CSS_UNIT + ')\\s*\\)';

var ColorStrings = {
  RGB: {
    match: new RegExp('^rgb' + PERMISSIVE_MATCH3 + '$', 'i'),
    parse: function parse(result) {
      return {
        r: is.percentage(result[1]) ? conventPercentageToRgb(result[1]) : parseInt(result[1], 10),
        g: is.percentage(result[2]) ? conventPercentageToRgb(result[2]) : parseInt(result[2], 10),
        b: is.percentage(result[3]) ? conventPercentageToRgb(result[3]) : parseInt(result[3], 10),
        a: 1
      };
    },
    to: function to(color) {
      return 'rgb(' + color.r + ', ' + color.g + ', ' + color.b + ')';
    }
  },
  RGBA: {
    match: new RegExp('^rgba' + PERMISSIVE_MATCH4 + '$', 'i'),
    parse: function parse(result) {
      return {
        r: is.percentage(result[1]) ? conventPercentageToRgb(result[1]) : parseInt(result[1], 10),
        g: is.percentage(result[2]) ? conventPercentageToRgb(result[2]) : parseInt(result[2], 10),
        b: is.percentage(result[3]) ? conventPercentageToRgb(result[3]) : parseInt(result[3], 10),
        a: is.percentage(result[4]) ? utils.convertPercentageToFloat(result[4]) : parseFloat(result[4], 10)
      };
    },
    to: function to(color) {
      return 'rgba(' + color.r + ', ' + color.g + ', ' + color.b + ', ' + color.a + ')';
    }
  },
  HSL: {
    match: new RegExp('^hsl' + PERMISSIVE_MATCH3 + '$', 'i'),
    parse: function parse(result) {
      var hsl = {
        h: (result[1] % 360 + 360) % 360,
        s: is.percentage(result[2]) ? utils.convertPercentageToFloat(result[2]) : parseFloat(result[2], 10),
        l: is.percentage(result[3]) ? utils.convertPercentageToFloat(result[3]) : parseFloat(result[3], 10),
        a: 1
      };

      return Converter.HSLtoRGB(hsl);
    },
    to: function to(color) {
      var hsl = Converter.RGBtoHSL(color);
      return 'hsl(' + parseInt(hsl.h, 10) + ', ' + Math.round(hsl.s * 100) + '%, ' + Math.round(hsl.l * 100) + '%)';
    }
  },
  HSLA: {
    match: new RegExp('^hsla' + PERMISSIVE_MATCH4 + '$', 'i'),
    parse: function parse(result) {
      var hsla = {
        h: (result[1] % 360 + 360) % 360,
        s: is.percentage(result[2]) ? utils.convertPercentageToFloat(result[2]) : parseFloat(result[2], 10),
        l: is.percentage(result[3]) ? utils.convertPercentageToFloat(result[3]) : parseFloat(result[3], 10),
        a: is.percentage(result[4]) ? utils.convertPercentageToFloat(result[4]) : parseFloat(result[4], 10)
      };

      return Converter.HSLtoRGB(hsla);
    },
    to: function to(color) {
      var hsl = Converter.RGBtoHSL(color);
      return 'hsla(' + parseInt(hsl.h, 10) + ', ' + Math.round(hsl.s * 100) + '%, ' + Math.round(hsl.l * 100) + '%, ' + color.a + ')';
    }
  },
  HEX: {
    match: /^#([a-f0-9]{6}|[a-f0-9]{3})$/i,
    parse: function parse(result) {
      var hex = result[0];
      var rgb = Converter.HEXtoRGB(hex);
      return {
        r: rgb.r,
        g: rgb.g,
        b: rgb.b,
        a: 1
      };
    },
    to: function to(color, instance) {
      var hex = Converter.RGBtoHEX(color);

      if (instance) {
        if (instance.options.hexUseName) {
          var hasName = Converter.hasNAME(color);
          if (hasName) {
            return hasName;
          }
        }
        if (instance.options.shortenHex) {
          hex = shrinkHex(hex);
        }
      }
      return '' + hex;
    }
  },
  TRANSPARENT: {
    match: /^transparent$/i,
    parse: function parse() {
      return {
        r: 0,
        g: 0,
        b: 0,
        a: 0
      };
    },
    to: function to() {
      return 'transparent';
    }
  },
  NAME: {
    match: /^\w+$/i,
    parse: function parse(result) {
      var rgb = Converter.NAMEtoRGB(result[0]);
      if (rgb) {
        return {
          r: rgb.r,
          g: rgb.g,
          b: rgb.b,
          a: 1
        };
      }

      return null;
    },
    to: function to(color, instance) {
      var name = Converter.RGBtoNAME(color);

      if (name) {
        return name;
      }

      return ColorStrings[instance.options.nameDegradation.toUpperCase()].to(color);
    }
  }
};

var asyncGenerator = function () {
  function AwaitValue(value) {
    this.value = value;
  }

  function AsyncGenerator(gen) {
    var front, back;

    function send(key, arg) {
      return new Promise(function (resolve, reject) {
        var request = {
          key: key,
          arg: arg,
          resolve: resolve,
          reject: reject,
          next: null
        };

        if (back) {
          back = back.next = request;
        } else {
          front = back = request;
          resume(key, arg);
        }
      });
    }

    function resume(key, arg) {
      try {
        var result = gen[key](arg);
        var value = result.value;

        if (value instanceof AwaitValue) {
          Promise.resolve(value.value).then(function (arg) {
            resume("next", arg);
          }, function (arg) {
            resume("throw", arg);
          });
        } else {
          settle(result.done ? "return" : "normal", result.value);
        }
      } catch (err) {
        settle("throw", err);
      }
    }

    function settle(type, value) {
      switch (type) {
        case "return":
          front.resolve({
            value: value,
            done: true
          });
          break;

        case "throw":
          front.reject(value);
          break;

        default:
          front.resolve({
            value: value,
            done: false
          });
          break;
      }

      front = front.next;

      if (front) {
        resume(front.key, front.arg);
      } else {
        back = null;
      }
    }

    this._invoke = send;

    if (typeof gen.return !== "function") {
      this.return = undefined;
    }
  }

  if (typeof Symbol === "function" && Symbol.asyncIterator) {
    AsyncGenerator.prototype[Symbol.asyncIterator] = function () {
      return this;
    };
  }

  AsyncGenerator.prototype.next = function (arg) {
    return this._invoke("next", arg);
  };

  AsyncGenerator.prototype.throw = function (arg) {
    return this._invoke("throw", arg);
  };

  AsyncGenerator.prototype.return = function (arg) {
    return this._invoke("return", arg);
  };

  return {
    wrap: function (fn) {
      return function () {
        return new AsyncGenerator(fn.apply(this, arguments));
      };
    },
    await: function (value) {
      return new AwaitValue(value);
    }
  };
}();





var classCallCheck = function (instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
};

var createClass = function () {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  return function (Constructor, protoProps, staticProps) {
    if (protoProps) defineProperties(Constructor.prototype, protoProps);
    if (staticProps) defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();

var Color = function () {
  function Color(string, options) {
    classCallCheck(this, Color);

    if (is.object(string) && is.undefined(options)) {
      options = string;
      string = undefined;
    }
    if (is.string(options)) {
      options = { format: options };
    }
    this.options = utils.deepMerge(defaults, options);
    this.value = {
      r: 0,
      g: 0,
      b: 0,
      h: 0,
      s: 0,
      v: 0,
      a: 1
    };
    this.privateFormat = false;
    this.privateMatchFormat = 'HEX';
    this.privateValid = true;

    this.init(string);
  }

  createClass(Color, [{
    key: 'init',
    value: function init(string) {
      this.format(this.options.format);
      this.fromString(string);
      return this;
    }
  }, {
    key: 'isValid',
    value: function isValid() {
      return this.privateValid;
    }
  }, {
    key: 'val',
    value: function val(value) {
      if (is.undefined(value)) {
        return this.toString();
      }
      this.fromString(value);
      return this;
    }
  }, {
    key: 'alpha',
    value: function alpha(value) {
      if (is.undefined(value) || isNaN(value)) {
        return this.value.a;
      }

      value = parseFloat(value);

      if (value > 1) {
        value = 1;
      } else if (value < 0) {
        value = 0;
      }
      this.value.a = value;
      return this;
    }
  }, {
    key: 'matchString',
    value: function matchString(string) {
      return Color.matchString(string);
    }
  }, {
    key: 'fromString',
    value: function fromString(string, updateFormat) {
      if (is.string(string)) {
        string = string.trim();
        var matched = null;
        var rgb = void 0;
        this.privateValid = false;
        for (var i in ColorStrings) {
          if ((matched = ColorStrings[i].match.exec(string)) !== null) {
            rgb = ColorStrings[i].parse(matched);

            if (rgb) {
              this.set(rgb);
              if (i === 'TRANSPARENT') {
                i = 'HEX';
              }
              this.privateMatchFormat = i;
              if (updateFormat === true) {
                this.format(i);
              }
              break;
            }
          }
        }
      } else if (is.object(string)) {
        this.set(string);
      }
      return this;
    }
  }, {
    key: 'format',
    value: function format(_format) {
      if (is.string(_format) && (_format = _format.toUpperCase()) && !is.undefined(ColorStrings[_format])) {
        if (_format !== 'TRANSPARENT') {
          this.privateFormat = _format;
        } else {
          this.privateFormat = 'HEX';
        }
      } else if (_format === false) {
        this.privateFormat = false;
      }
      if (this.privateFormat === false) {
        return this.privateMatchFormat;
      }
      return this.privateFormat;
    }
  }, {
    key: 'toRGBA',
    value: function toRGBA() {
      return ColorStrings.RGBA.to(this.value, this);
    }
  }, {
    key: 'toRGB',
    value: function toRGB() {
      return ColorStrings.RGB.to(this.value, this);
    }
  }, {
    key: 'toHSLA',
    value: function toHSLA() {
      return ColorStrings.HSLA.to(this.value, this);
    }
  }, {
    key: 'toHSL',
    value: function toHSL() {
      return ColorStrings.HSL.to(this.value, this);
    }
  }, {
    key: 'toHEX',
    value: function toHEX() {
      return ColorStrings.HEX.to(this.value, this);
    }
  }, {
    key: 'toNAME',
    value: function toNAME() {
      return ColorStrings.NAME.to(this.value, this);
    }
  }, {
    key: 'to',
    value: function to(format) {
      if (is.string(format) && (format = format.toUpperCase()) && !is.undefined(ColorStrings[format])) {
        return ColorStrings[format].to(this.value, this);
      }
      return this.toString();
    }
  }, {
    key: 'toString',
    value: function toString() {
      var value = this.value;
      if (!this.privateValid) {
        value = this.options.invalidValue;

        if (is.string(value)) {
          return value;
        }
      }

      if (value.a === 0 && this.options.zeroAlphaAsTransparent) {
        return ColorStrings.TRANSPARENT.to(value, this);
      }

      var format = void 0;
      if (this.privateFormat === false) {
        format = this.privateMatchFormat;
      } else {
        format = this.privateFormat;
      }

      if (this.options.reduceAlpha && value.a === 1) {
        switch (format) {
          case 'RGBA':
            format = 'RGB';
            break;
          case 'HSLA':
            format = 'HSL';
            break;
          default:
            break;
        }
      }

      if (value.a !== 1 && format !== 'RGBA' && format !== 'HSLA' && this.options.alphaConvert) {
        if (is.string(this.options.alphaConvert)) {
          format = this.options.alphaConvert;
        }
        if (!is.undefined(this.options.alphaConvert[format])) {
          format = this.options.alphaConvert[format];
        }
      }
      return ColorStrings[format].to(value, this);
    }
  }, {
    key: 'get',
    value: function get$$1() {
      return this.value;
    }
  }, {
    key: 'set',
    value: function set$$1(color) {
      this.privateValid = true;
      var fromRgb = 0;
      var fromHsv = 0;
      var hsv = void 0;
      var rgb = void 0;

      for (var i in color) {
        if ('hsv'.includes(i)) {
          fromHsv++;
          this.value[i] = color[i];
        } else if ('rgb'.includes(i)) {
          fromRgb++;
          this.value[i] = color[i];
        } else if (i === 'a') {
          this.value.a = color.a;
        }
      }
      if (fromRgb > fromHsv) {
        hsv = Converter.RGBtoHSV(this.value);
        if (this.value.r === 0 && this.value.g === 0 && this.value.b === 0) {
          // this.value.h = color.h;
        } else {
          this.value.h = hsv.h;
        }

        this.value.s = hsv.s;
        this.value.v = hsv.v;
      } else if (fromHsv > fromRgb) {
        rgb = Converter.HSVtoRGB(this.value);
        this.value.r = rgb.r;
        this.value.g = rgb.g;
        this.value.b = rgb.b;
      }
      return this;
    }
  }], [{
    key: 'matchString',
    value: function matchString(string) {
      if (is.string(string)) {
        string = string.trim();
        var matched = null;
        var rgb = void 0;
        for (var i in ColorStrings) {
          if ((matched = ColorStrings[i].match.exec(string)) !== null) {
            rgb = ColorStrings[i].parse(matched);

            if (rgb) {
              return true;
            }
          }
        }
      }
      return false;
    }
  }, {
    key: 'setDefaults',
    value: function setDefaults(options) {
      Object.assign(defaults, options);
    }
  }]);
  return Color;
}();

function color() {
  for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }

  return new (Function.prototype.bind.apply(Color, [null].concat(args)))();
}

color.Constructor = Color;

Object.assign(color, {
  matchString: Color.matchString,
  setDefaults: Color.setDefaults
}, Converter, info);
Pj.color = color;

exports['default'] = color;

Object.defineProperty(exports, '__esModule', { value: true });

})));

(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
	typeof define === 'function' && define.amd ? define(['exports'], factory) :
	(factory((global['@pluginjs/component'] = {})));
}(this, (function (exports) { 'use strict';

var asyncGenerator = function () {
  function AwaitValue(value) {
    this.value = value;
  }

  function AsyncGenerator(gen) {
    var front, back;

    function send(key, arg) {
      return new Promise(function (resolve, reject) {
        var request = {
          key: key,
          arg: arg,
          resolve: resolve,
          reject: reject,
          next: null
        };

        if (back) {
          back = back.next = request;
        } else {
          front = back = request;
          resume(key, arg);
        }
      });
    }

    function resume(key, arg) {
      try {
        var result = gen[key](arg);
        var value = result.value;

        if (value instanceof AwaitValue) {
          Promise.resolve(value.value).then(function (arg) {
            resume("next", arg);
          }, function (arg) {
            resume("throw", arg);
          });
        } else {
          settle(result.done ? "return" : "normal", result.value);
        }
      } catch (err) {
        settle("throw", err);
      }
    }

    function settle(type, value) {
      switch (type) {
        case "return":
          front.resolve({
            value: value,
            done: true
          });
          break;

        case "throw":
          front.reject(value);
          break;

        default:
          front.resolve({
            value: value,
            done: false
          });
          break;
      }

      front = front.next;

      if (front) {
        resume(front.key, front.arg);
      } else {
        back = null;
      }
    }

    this._invoke = send;

    if (typeof gen.return !== "function") {
      this.return = undefined;
    }
  }

  if (typeof Symbol === "function" && Symbol.asyncIterator) {
    AsyncGenerator.prototype[Symbol.asyncIterator] = function () {
      return this;
    };
  }

  AsyncGenerator.prototype.next = function (arg) {
    return this._invoke("next", arg);
  };

  AsyncGenerator.prototype.throw = function (arg) {
    return this._invoke("throw", arg);
  };

  AsyncGenerator.prototype.return = function (arg) {
    return this._invoke("return", arg);
  };

  return {
    wrap: function (fn) {
      return function () {
        return new AsyncGenerator(fn.apply(this, arguments));
      };
    },
    await: function (value) {
      return new AwaitValue(value);
    }
  };
}();





var classCallCheck = function (instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
};

var createClass = function () {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  return function (Constructor, protoProps, staticProps) {
    if (protoProps) defineProperties(Constructor.prototype, protoProps);
    if (staticProps) defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();



























var slicedToArray = function () {
  function sliceIterator(arr, i) {
    var _arr = [];
    var _n = true;
    var _d = false;
    var _e = undefined;

    try {
      for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
        _arr.push(_s.value);

        if (i && _arr.length === i) break;
      }
    } catch (err) {
      _d = true;
      _e = err;
    } finally {
      try {
        if (!_n && _i["return"]) _i["return"]();
      } finally {
        if (_d) throw _e;
      }
    }

    return _arr;
  }

  return function (arr, i) {
    if (Array.isArray(arr)) {
      return arr;
    } else if (Symbol.iterator in Object(arr)) {
      return sliceIterator(arr, i);
    } else {
      throw new TypeError("Invalid attempt to destructure non-iterable instance");
    }
  };
}();

var Plugin = function () {
  function Plugin(namespace, element) {
    classCallCheck(this, Plugin);

    this.plugin = namespace;
    this.element = element;
    if (window.Pj && window.Pj.instances[this.plugin]) {
      window.Pj.instances[this.plugin].push(this);
    }
  }

  createClass(Plugin, [{
    key: 'getDataOptions',
    value: function getDataOptions() {
      var _this = this;

      var data = this.element.dataset;
      var length = Object.keys(data).length;
      var newData = {};

      if (length > 0) {
        Object.entries(data).forEach(function (_ref) {
          var _ref2 = slicedToArray(_ref, 2),
              name = _ref2[0],
              content = _ref2[1];

          var cache = {};
          var items = name.split('-');
          // let items = name.split('-');

          var deep = items.length;

          if (deep > 1) {
            for (var j = 0; j < deep; j++) {
              var item = items[j].substring(0, 1).toLowerCase() + items[j].substring(1);

              if (j === 0) {
                cache[item] = {};
              } else if (j === deep - 1) {
                
              } else {
                
              }
            }
          } else if (items[0] === 'as' + _this.plugin.substring(0, 1).toUpperCase() + _this.plugin.substring(1)) {
            cache = content;
          } else {
            cache[name] = content;
          }

          Object.assign(newData, cache);
        });
      }

      return newData;
    }
  }, {
    key: 'destroy',
    value: function destroy() {
      var _this2 = this;

      this.plugin = null;
      this.element = null;
      if (window.Pj && window.Pj.instances[this.plugin]) {
        window.Pj.instances[this.plugin] = window.Pj.instances[this.plugin].filter(function (plugin) {
          return plugin.element === _this2.element;
        });
      }
    }
  }], [{
    key: 'of',
    value: function of() {
      for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      return new (Function.prototype.bind.apply(this, [null].concat(args)))();
    }
  }]);
  return Plugin;
}();

exports['default'] = Plugin;

Object.defineProperty(exports, '__esModule', { value: true });

})));

(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
	typeof define === 'function' && define.amd ? define(['exports'], factory) :
	(factory((global['@pluginjs/easing'] = {})));
}(this, (function (exports) { 'use strict';

var asyncGenerator = function () {
  function AwaitValue(value) {
    this.value = value;
  }

  function AsyncGenerator(gen) {
    var front, back;

    function send(key, arg) {
      return new Promise(function (resolve, reject) {
        var request = {
          key: key,
          arg: arg,
          resolve: resolve,
          reject: reject,
          next: null
        };

        if (back) {
          back = back.next = request;
        } else {
          front = back = request;
          resume(key, arg);
        }
      });
    }

    function resume(key, arg) {
      try {
        var result = gen[key](arg);
        var value = result.value;

        if (value instanceof AwaitValue) {
          Promise.resolve(value.value).then(function (arg) {
            resume("next", arg);
          }, function (arg) {
            resume("throw", arg);
          });
        } else {
          settle(result.done ? "return" : "normal", result.value);
        }
      } catch (err) {
        settle("throw", err);
      }
    }

    function settle(type, value) {
      switch (type) {
        case "return":
          front.resolve({
            value: value,
            done: true
          });
          break;

        case "throw":
          front.reject(value);
          break;

        default:
          front.resolve({
            value: value,
            done: false
          });
          break;
      }

      front = front.next;

      if (front) {
        resume(front.key, front.arg);
      } else {
        back = null;
      }
    }

    this._invoke = send;

    if (typeof gen.return !== "function") {
      this.return = undefined;
    }
  }

  if (typeof Symbol === "function" && Symbol.asyncIterator) {
    AsyncGenerator.prototype[Symbol.asyncIterator] = function () {
      return this;
    };
  }

  AsyncGenerator.prototype.next = function (arg) {
    return this._invoke("next", arg);
  };

  AsyncGenerator.prototype.throw = function (arg) {
    return this._invoke("throw", arg);
  };

  AsyncGenerator.prototype.return = function (arg) {
    return this._invoke("return", arg);
  };

  return {
    wrap: function (fn) {
      return function () {
        return new AsyncGenerator(fn.apply(this, arguments));
      };
    },
    await: function (value) {
      return new AwaitValue(value);
    }
  };
}();

















































var toConsumableArray = function (arr) {
  if (Array.isArray(arr)) {
    for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) arr2[i] = arr[i];

    return arr2;
  } else {
    return Array.from(arr);
  }
};

/* Credit to http://github.com/gre/bezier-easing MIT */
var _bezier = function () {
  var NEWTON_ITERATIONS = 6;
  var NEWTON_MIN_SLOPE = 0.001;
  var SUBDIVISION_PRECISION = 0.0000001;
  var SUBDIVISION_MAX_ITERATIONS = 12;

  var kSplineTableSize = 11;
  var kSampleStepSize = 1.0 / (kSplineTableSize - 1.0);

  var float32ArraySupported = typeof Float32Array === 'function';

  function A(aA1, aA2) {
    return 1.0 - 3.0 * aA2 + 3.0 * aA1;
  }
  function B(aA1, aA2) {
    return 3.0 * aA2 - 6.0 * aA1;
  }
  function C(aA1) {
    return 3.0 * aA1;
  }

  // Returns x(t) given t, x1, and x2, or y(t) given t, y1, and y2.
  function calcBezier(aT, aA1, aA2) {
    return ((A(aA1, aA2) * aT + B(aA1, aA2)) * aT + C(aA1)) * aT;
  }

  // Returns dx/dt given t, x1, and x2, or dy/dt given t, y1, and y2.
  function getSlope(aT, aA1, aA2) {
    return 3.0 * A(aA1, aA2) * aT * aT + 2.0 * B(aA1, aA2) * aT + C(aA1);
  }

  function binarySubdivide(aX, aA, aB, mX1, mX2) {
    var currentX = void 0;
    var currentT = void 0;
    var i = 0;
    do {
      currentT = aA + (aB - aA) / 2.0;
      currentX = calcBezier(currentT, mX1, mX2) - aX;
      if (currentX > 0.0) {
        aB = currentT;
      } else {
        aA = currentT;
      }
    } while (Math.abs(currentX) > SUBDIVISION_PRECISION && ++i < SUBDIVISION_MAX_ITERATIONS);
    return currentT;
  }

  function newtonRaphsonIterate(aX, aGuessT, mX1, mX2) {
    for (var i = 0; i < NEWTON_ITERATIONS; ++i) {
      var currentSlope = getSlope(aGuessT, mX1, mX2);
      if (currentSlope === 0.0) {
        return aGuessT;
      }
      var currentX = calcBezier(aGuessT, mX1, mX2) - aX;
      aGuessT -= currentX / currentSlope;
    }
    return aGuessT;
  }

  return function bezier(mX1, mY1, mX2, mY2, css) {
    if (!(mX1 >= 0 && mX1 <= 1 && mX2 >= 0 && mX2 <= 1)) {
      throw new Error('bezier x values must be in [0, 1] range');
    }

    // Precompute samples table
    var sampleValues = float32ArraySupported ? new Float32Array(kSplineTableSize) : new Array(kSplineTableSize);
    if (mX1 !== mY1 || mX2 !== mY2) {
      for (var i = 0; i < kSplineTableSize; ++i) {
        sampleValues[i] = calcBezier(i * kSampleStepSize, mX1, mX2);
      }
    }

    function getTForX(aX) {
      var intervalStart = 0.0;
      var currentSample = 1;
      var lastSample = kSplineTableSize - 1;

      for (; currentSample !== lastSample && sampleValues[currentSample] <= aX; ++currentSample) {
        intervalStart += kSampleStepSize;
      }
      --currentSample;

      // Interpolate to provide an initial guess for t
      var dist = (aX - sampleValues[currentSample]) / (sampleValues[currentSample + 1] - sampleValues[currentSample]);
      var guessForT = intervalStart + dist * kSampleStepSize;

      var initialSlope = getSlope(guessForT, mX1, mX2);
      if (initialSlope >= NEWTON_MIN_SLOPE) {
        return newtonRaphsonIterate(aX, guessForT, mX1, mX2);
      } else if (initialSlope === 0.0) {
        return guessForT;
      }
      return binarySubdivide(aX, intervalStart, intervalStart + kSampleStepSize, mX1, mX2);
    }

    function BezierEasing(x) {
      // linear
      if (mX1 === mY1 && mX2 === mY2) {
        return x;
      }
      // Because JavaScript number are imprecise, we should guarantee the extremes are right.
      if (x === 0) {
        return 0;
      }
      if (x === 1) {
        return 1;
      }
      return calcBezier(getTForX(x), mY1, mY2);
    }

    BezierEasing.css = function () {
      if (css) {
        return css;
      }
      if (mX1 === mY1 && mX2 === mY2) {
        return 'linear';
      }
      return 'cubic-bezier(' + mX1 + ', ' + mY1 + ', ' + mX2 + ', ' + mY2 + ')';
    };

    return BezierEasing;
  };
}();

/* Credit to http://easings.net/ */
var easings = {
  ease: [0.25, 0.1, 0.25, 1.0, 'ease'],
  linear: [0.0, 0.0, 1.0, 1.0, 'linear'],
  easeIn: [0.42, 0.0, 1.0, 1.0, 'ease-in'],
  easeOut: [0.0, 0.0, 0.58, 1.0, 'ease-out'],
  easeInOut: [0.42, 0.0, 0.58, 1.0, 'ease-in-out'],
  easeInSine: [0.47, 0, 0.745, 0.715],
  easeOutSine: [0.39, 0.575, 0.565, 1],
  easeInOutSine: [0.445, 0.05, 0.55, 0.95],
  easeInQuad: [0.55, 0.085, 0.68, 0.53],
  easeOutQuad: [0.25, 0.46, 0.45, 0.94],
  easeInOutQuad: [0.455, 0.03, 0.515, 0.955],
  easeInCubic: [0.55, 0.055, 0.675, 0.19],
  easeOutCubic: [0.215, 0.61, 0.355, 1],
  easeInOutCubic: [0.645, 0.045, 0.355, 1],
  easeInQuart: [0.895, 0.03, 0.685, 0.22],
  easeOutQuart: [0.165, 0.84, 0.44, 1],
  easeInOutQuart: [0.77, 0, 0.175, 1],
  easeInQuint: [0.755, 0.05, 0.855, 0.06],
  easeOutQuint: [0.23, 1, 0.32, 1],
  easeInOutQuint: [0.86, 0, 0.07, 1],
  easeInExpo: [0.95, 0.05, 0.795, 0.035],
  easeOutExpo: [0.19, 1, 0.22, 1],
  easeInOutExpo: [1, 0, 0, 1],
  easeInCirc: [0.6, 0.04, 0.98, 0.335],
  easeOutCirc: [0.075, 0.82, 0.165, 1],
  easeInOutCirc: [0.785, 0.135, 0.15, 0.86],
  easeInBack: [0.6, -0.28, 0.735, 0.045],
  easeOutBack: [0.175, 0.885, 0.32, 1.275],
  easeInOutBack: [0.68, -0.55, 0.265, 1.55]
};

var main = {
  get: function get$$1(name) {
    if (name in easings) {
      return _bezier.apply(undefined, toConsumableArray(easings[name]));
    }
    return undefined;
  },
  bezier: function bezier(mX1, mY1, mX2, mY2) {
    return _bezier(mX1, mY1, mX2, mY2);
  },
  register: function register(name, mX1, mY1, mX2, mY2) {
    if (!(mX1 >= 0 && mX1 <= 1 && mX2 >= 0 && mX2 <= 1)) {
      throw new Error('bezier x values must be in [0, 1] range');
    }
    easings[name] = [mX1, mY1, mX2, mY2];
  }
};

exports['default'] = main;

Object.defineProperty(exports, '__esModule', { value: true });

})));

(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@pluginjs/pluginjs'), require('@pluginjs/emitter')) :
	typeof define === 'function' && define.amd ? define(['exports', '@pluginjs/pluginjs', '@pluginjs/emitter'], factory) :
	(factory((global['@pluginjs/fullscreen'] = {}),global['@pluginjs/pluginjs'],global['@pluginjs/emitter']));
}(this, (function (exports,Pj,Emitter) { 'use strict';

Pj = Pj && Pj.hasOwnProperty('default') ? Pj['default'] : Pj;
Emitter = Emitter && Emitter.hasOwnProperty('default') ? Emitter['default'] : Emitter;

var asyncGenerator = function () {
  function AwaitValue(value) {
    this.value = value;
  }

  function AsyncGenerator(gen) {
    var front, back;

    function send(key, arg) {
      return new Promise(function (resolve, reject) {
        var request = {
          key: key,
          arg: arg,
          resolve: resolve,
          reject: reject,
          next: null
        };

        if (back) {
          back = back.next = request;
        } else {
          front = back = request;
          resume(key, arg);
        }
      });
    }

    function resume(key, arg) {
      try {
        var result = gen[key](arg);
        var value = result.value;

        if (value instanceof AwaitValue) {
          Promise.resolve(value.value).then(function (arg) {
            resume("next", arg);
          }, function (arg) {
            resume("throw", arg);
          });
        } else {
          settle(result.done ? "return" : "normal", result.value);
        }
      } catch (err) {
        settle("throw", err);
      }
    }

    function settle(type, value) {
      switch (type) {
        case "return":
          front.resolve({
            value: value,
            done: true
          });
          break;

        case "throw":
          front.reject(value);
          break;

        default:
          front.resolve({
            value: value,
            done: false
          });
          break;
      }

      front = front.next;

      if (front) {
        resume(front.key, front.arg);
      } else {
        back = null;
      }
    }

    this._invoke = send;

    if (typeof gen.return !== "function") {
      this.return = undefined;
    }
  }

  if (typeof Symbol === "function" && Symbol.asyncIterator) {
    AsyncGenerator.prototype[Symbol.asyncIterator] = function () {
      return this;
    };
  }

  AsyncGenerator.prototype.next = function (arg) {
    return this._invoke("next", arg);
  };

  AsyncGenerator.prototype.throw = function (arg) {
    return this._invoke("throw", arg);
  };

  AsyncGenerator.prototype.return = function (arg) {
    return this._invoke("return", arg);
  };

  return {
    wrap: function (fn) {
      return function () {
        return new AsyncGenerator(fn.apply(this, arguments));
      };
    },
    await: function (value) {
      return new AwaitValue(value);
    }
  };
}();





var classCallCheck = function (instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
};

var createClass = function () {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  return function (Constructor, protoProps, staticProps) {
    if (protoProps) defineProperties(Constructor.prototype, protoProps);
    if (staticProps) defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();









var inherits = function (subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      enumerable: false,
      writable: true,
      configurable: true
    }
  });
  if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
};











var possibleConstructorReturn = function (self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return call && (typeof call === "object" || typeof call === "function") ? call : self;
};

/* Credit to https://github.com/sindresorhus/screenfull.js MIT */
var Fullscreen = function () {
  var fn = function () {
    var val = void 0;
    var valLength = void 0;

    var fnMap = [['requestFullscreen', 'exitFullscreen', 'fullscreenElement', 'fullscreenEnabled', 'fullscreenchange', 'fullscreenerror'],
    // new WebKit
    ['webkitRequestFullscreen', 'webkitExitFullscreen', 'webkitFullscreenElement', 'webkitFullscreenEnabled', 'webkitfullscreenchange', 'webkitfullscreenerror'],
    // old WebKit (Safari 5.1)
    ['webkitRequestFullScreen', 'webkitCancelFullScreen', 'webkitCurrentFullScreenElement', 'webkitCancelFullScreen', 'webkitfullscreenchange', 'webkitfullscreenerror'], ['mozRequestFullScreen', 'mozCancelFullScreen', 'mozFullScreenElement', 'mozFullScreenEnabled', 'mozfullscreenchange', 'mozfullscreenerror'], ['msRequestFullscreen', 'msExitFullscreen', 'msFullscreenElement', 'msFullscreenEnabled', 'MSFullscreenChange', 'MSFullscreenError']];

    var l = fnMap.length;
    var ret = {};

    for (var i = 0; i < l; i++) {
      val = fnMap[i];
      if (val && val[1] in document) {
        for (i = 0, valLength = val.length; i < valLength; i++) {
          ret[fnMap[0][i]] = val[i];
        }
        return ret;
      }
    }

    return false;
  }();

  var instances = [];
  var currentElement = void 0;

  function onfullscreenchange(e) {
    var currents = instances.filter(function (instance) {
      return currentElement === instance.element || e.target === instance.element;
    });

    currents.forEach(function (current) {
      if (!current.isFullscreen()) {
        current.emit('exit'); // exit;
      } else {
        currentElement = current.element;
        current.emit('request'); // request
      }
    });
  }

  function onfullscreenerror(e) {
    var currents = instances.filter(function (instance) {
      return e.target === instance.element;
    });

    currents.forEach(function (current) {
      return current.emit('error');
    });
  }

  var Fullscreen = function (_Emitter) {
    inherits(Fullscreen, _Emitter);

    function Fullscreen(element) {
      classCallCheck(this, Fullscreen);

      var _this = possibleConstructorReturn(this, (Fullscreen.__proto__ || Object.getPrototypeOf(Fullscreen)).call(this));

      _this.element = element || document.documentElement;

      if (fn === false) {
        _this.emit('error', new Error('fullscreen is not supported'));
      }

      if (instances.length === 0) {
        Fullscreen.bind();
      }

      instances.push(_this);
      return _this;
    }

    createClass(Fullscreen, [{
      key: 'destroy',
      value: function destroy() {
        var _this2 = this;

        this.exit();

        instances = instances.filter(function (instance) {
          return instance !== _this2;
        });

        if (instances.length === 0) {
          Fullscreen.unbind();
        }
      }
    }, {
      key: 'request',
      value: function request() {
        if (!this.isFullscreen()) {
          if (this.element[fn.requestFullscreen]) {
            var _element;

            (_element = this.element)[fn.requestFullscreen].apply(_element, arguments);
          }
          // else {
          //   document.documentElement[fn.requestFullscreen].apply(this.element, arguments);
          // }
        }
      }
    }, {
      key: 'exit',
      value: function exit() {
        if (this.isFullscreen()) {
          document[fn.exitFullscreen]();
        }
      }
    }, {
      key: 'toggle',
      value: function toggle() {
        if (this.isFullscreen()) {
          this.exit();
        } else {
          this.request();
        }
      }
    }, {
      key: 'isFullscreen',
      value: function isFullscreen() {
        if (Fullscreen.isFullscreen()) {
          return this.element === Fullscreen.element();
        }

        return false;
      }

      /* whether or not full-screen mode is available. */

    }], [{
      key: 'enabled',
      value: function enabled() {
        return Boolean(document[fn.fullscreenEnabled]);
      }
    }, {
      key: 'exit',
      value: function exit() {
        var _document;

        (_document = document)[fn.exitFullscreen].apply(_document, arguments);
      }
    }, {
      key: 'element',
      value: function element() {
        return document[fn.fullscreenElement];
      }
    }, {
      key: 'isFullscreen',
      value: function isFullscreen() {
        return Boolean(document[fn.fullscreenElement]);
      }
    }, {
      key: 'bind',
      value: function bind() {
        document.addEventListener(fn.fullscreenchange, onfullscreenchange);
        document.addEventListener(fn.fullscreenerror, onfullscreenerror);
      }
    }, {
      key: 'unbind',
      value: function unbind() {
        document.removeEventListener(fn.fullscreenchange, onfullscreenchange);
        document.removeEventListener(fn.fullscreenerror, onfullscreenerror);
      }
    }]);
    return Fullscreen;
  }(Emitter);

  Fullscreen.fn = fn;

  return Fullscreen;
}();

Pj.Fullscreen = Fullscreen;

exports['default'] = Fullscreen;

Object.defineProperty(exports, '__esModule', { value: true });

})));

(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('jquery'), require('@pluginjs/pluginjs')) :
	typeof define === 'function' && define.amd ? define(['exports', 'jquery', '@pluginjs/pluginjs'], factory) :
	(factory((global['@pluginjs/gradient'] = {}),global.jQuery,global['@pluginjs/pluginjs']));
}(this, (function (exports,$,Pj) { 'use strict';

$ = $ && $.hasOwnProperty('default') ? $['default'] : $;
Pj = Pj && Pj.hasOwnProperty('default') ? Pj['default'] : Pj;

var defaults = {
  prefixes: ['-webkit-', '-moz-', '-ms-', '-o-'],
  forceStandard: true,
  angleUseKeyword: true,
  emptyString: '',
  degradationFormat: false,
  cleanPosition: true,
  color: {
    format: false, // rgb, rgba, hsl, hsla, hex
    hexUseName: false,
    reduceAlpha: true,
    shortenHex: true,
    zeroAlphaAsTransparent: false,
    invalidValue: {
      r: 0,
      g: 0,
      b: 0,
      a: 1
    }
  }
};

var info = { version: '0.3.2' };

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) {
  return typeof obj;
} : function (obj) {
  return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
};





var asyncGenerator = function () {
  function AwaitValue(value) {
    this.value = value;
  }

  function AsyncGenerator(gen) {
    var front, back;

    function send(key, arg) {
      return new Promise(function (resolve, reject) {
        var request = {
          key: key,
          arg: arg,
          resolve: resolve,
          reject: reject,
          next: null
        };

        if (back) {
          back = back.next = request;
        } else {
          front = back = request;
          resume(key, arg);
        }
      });
    }

    function resume(key, arg) {
      try {
        var result = gen[key](arg);
        var value = result.value;

        if (value instanceof AwaitValue) {
          Promise.resolve(value.value).then(function (arg) {
            resume("next", arg);
          }, function (arg) {
            resume("throw", arg);
          });
        } else {
          settle(result.done ? "return" : "normal", result.value);
        }
      } catch (err) {
        settle("throw", err);
      }
    }

    function settle(type, value) {
      switch (type) {
        case "return":
          front.resolve({
            value: value,
            done: true
          });
          break;

        case "throw":
          front.reject(value);
          break;

        default:
          front.resolve({
            value: value,
            done: false
          });
          break;
      }

      front = front.next;

      if (front) {
        resume(front.key, front.arg);
      } else {
        back = null;
      }
    }

    this._invoke = send;

    if (typeof gen.return !== "function") {
      this.return = undefined;
    }
  }

  if (typeof Symbol === "function" && Symbol.asyncIterator) {
    AsyncGenerator.prototype[Symbol.asyncIterator] = function () {
      return this;
    };
  }

  AsyncGenerator.prototype.next = function (arg) {
    return this._invoke("next", arg);
  };

  AsyncGenerator.prototype.throw = function (arg) {
    return this._invoke("throw", arg);
  };

  AsyncGenerator.prototype.return = function (arg) {
    return this._invoke("return", arg);
  };

  return {
    wrap: function (fn) {
      return function () {
        return new AsyncGenerator(fn.apply(this, arguments));
      };
    },
    await: function (value) {
      return new AwaitValue(value);
    }
  };
}();





var classCallCheck = function (instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
};

var createClass = function () {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  return function (Constructor, protoProps, staticProps) {
    if (protoProps) defineProperties(Constructor.prototype, protoProps);
    if (staticProps) defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();

/*eslint-disable */
/* Credit to http://is.js.org MIT */
var toString = Object.prototype.toString;
var is = {
  // Type checks
  /* -------------------------------------------------------------------------- */
  // is a given value Arguments?
  arguments: function _arguments(value) {
    // fallback check is for IE
    return toString.call(value) === '[object Arguments]' || value != null && (typeof value === 'undefined' ? 'undefined' : _typeof(value)) === 'object' && 'callee' in value;
  },

  // is a given value Array?
  array: function array(val) {
    if (Array.isArray) {
      return Array.isArray(val);
    }
    return toString.call(val) === '[object Array]';
  },

  // is a given value Boolean?
  boolean: function boolean(val) {
    return val === true || val === false || toString.call(val) === '[object Boolean]';
  },

  // is a given value Char?
  char: function char(val) {
    return this.string(val) && val.length === 1;
  },

  // is a given value Date Object?
  date: function date(value) {
    return toString.call(value) === '[object Date]';
  },

  // is a given object a DOM node?
  domNode: function domNode(object) {
    return this.object(object) && object.nodeType > 0;
  },

  // is a given value Error object?
  error: function error(val) {
    return toString.call(val) === '[object Error]';
  },

  // is a given value function?
  function: function _function(val) {
    // fallback check is for IE
    return toString.call(val) === '[object Function]' || typeof val === 'function';
  },

  // is given value a pure JSON object?
  json: function json(value) {
    return toString.call(value) === '[object Object]';
  },

  // is a given value NaN?
  nan: function nan(val) {
    // NaN is number :) Also it is the only value which does not equal itself
    return val !== val;
  },

  // is a given value null?
  null: function _null(val) {
    return val === null;
  },

  // is a given value number?
  number: function number(val) {
    return !this.nan(val) && toString.call(val) === '[object Number]';
  },

  // is a given value object?
  object: function object(val) {
    return Object(val) === val;
  },

  // is a given value empty object?
  emptyObject: function emptyObject(val) {
    return this.object(val) && Object.getOwnPropertyNames(val).length == 0;
  },

  // is a given value RegExp?
  regexp: function regexp(val) {
    return toString.call(val) === '[object RegExp]';
  },

  // is a given value String?
  string: function string(val) {
    return typeof val === 'string' || toString.call(val) === '[object String]';
  },

  // is a given value undefined?
  undefined: function undefined(val) {
    return val === void 0;
  },

  // Arithmetic checks
  /* -------------------------------------------------------------------------- */
  // is a given value numeric?
  numeric: function numeric(n) {
    return (this.number(n) || this.string(n)) && !this.nan(n - parseFloat(n));
  },

  // is a given number percentage?
  percentage: function percentage(n) {
    return typeof n === 'string' && n.indexOf('%') !== -1;
  },

  // is a given number decimal?
  decimal: function decimal(n) {
    return this.number(n) && n % 1 !== 0;
  },

  // is a given number finite?
  finite: function finite(n) {
    if (isFinite) {
      return isFinite(n);
    }
    return !this.infinite(n) && !this.nan(n);
  },

  // is a given number infinite?
  infinite: function infinite(n) {
    return n === Infinity || n === -Infinity;
  },

  integer: function integer(n) {
    return this.number(n) && n % 1 === 0;
  },

  // is a given number negative?
  negative: function negative(n) {
    return this.number(n) && n < 0;
  },

  // is a given number positive?
  positive: function positive(n) {
    return this.number(n) && n > 0;
  }
};

function getPrefix() {
  var ua = window.navigator.userAgent;
  var prefix = '';
  if (/MSIE/g.test(ua)) {
    prefix = '-ms-';
  } else if (/Firefox/g.test(ua)) {
    prefix = '-moz-';
  } else if (/(WebKit)/i.test(ua)) {
    prefix = '-webkit-';
  } else if (/Opera/g.test(ua)) {
    prefix = '-o-';
  }
  return prefix;
}

function flip(o) {
  var flipped = {};
  for (var i in o) {
    if (o.hasOwnProperty(i)) {
      flipped[o[i]] = i;
    }
  }
  return flipped;
}

function reverseDirection(direction) {
  var mapping = {
    top: 'bottom',
    right: 'left',
    bottom: 'top',
    left: 'right',
    'right top': 'left bottom',
    'top right': 'bottom left',
    'bottom right': 'top left',
    'right bottom': 'left top',
    'left bottom': 'right top',
    'bottom left': 'top right',
    'top left': 'bottom right',
    'left top': 'right bottom'
  };
  return mapping.hasOwnProperty(direction) ? mapping[direction] : direction;
}

function isDirection(n) {
  var reg = /^(top|left|right|bottom)$/i;
  return reg.test(n);
}

var keywordAngleMap = {
  'to top': 0,
  'to right': 90,
  'to bottom': 180,
  'to left': 270,
  'to right top': 45,
  'to top right': 45,
  'to bottom right': 135,
  'to right bottom': 135,
  'to left bottom': 225,
  'to bottom left': 225,
  'to top left': 315,
  'to left top': 315
};

var angleKeywordMap = flip(keywordAngleMap);

var RegExpStrings = function () {
  var color = /(?:rgba|rgb|hsla|hsl)\s*\([\s\d.,%]+\)|#[a-z0-9]{3,6}|[a-z]+/i;
  var position = /\d{1,3}%/i;
  var angle = /(?:to ){0,1}(?:(?:top|left|right|bottom)\s*){1,2}|\d+deg/i;
  var stop = new RegExp('(' + color.source + ')\\s*(' + position.source + '){0,1}', 'i');
  var stops = new RegExp(stop.source, 'gi');
  var parameters = new RegExp('(?:(' + angle.source + ')){0,1}\\s*,{0,1}\\s*(.*?)\\s*', 'i');
  var full = new RegExp('^(-webkit-|-moz-|-ms-|-o-){0,1}(linear|radial|repeating-linear)-gradient\\s*\\(\\s*(' + parameters.source + ')\\s*\\)$', 'i');

  return {
    FULL: full,
    ANGLE: angle,
    COLOR: color,
    POSITION: position,
    STOP: stop,
    STOPS: stops,
    PARAMETERS: new RegExp('^' + parameters.source + '$', 'i')
  };
}();

var GradientString = {
  matchString: function matchString(string) {
    var matched = this.parseString(string);
    if (matched && matched.value && matched.value.stops && matched.value.stops.length > 1) {
      return true;
    }
    return false;
  },
  parseString: function parseString(string) {
    string = $.trim(string);
    var matched = void 0;
    if ((matched = RegExpStrings.FULL.exec(string)) !== null) {
      var value = this.parseParameters(matched[3]);

      return {
        prefix: is.undefined(matched[1]) ? null : matched[1],
        type: matched[2],
        value: value
      };
    }
    return false;
  },
  parseParameters: function parseParameters(string) {
    var matched = void 0;
    if ((matched = RegExpStrings.PARAMETERS.exec(string)) !== null) {
      var stops = this.parseStops(matched[2]);
      return {
        angle: is.undefined(matched[1]) ? 0 : matched[1],
        stops: stops
      };
    }
    return false;
  },
  parseStops: function parseStops(string) {
    var _this = this;

    var matched = void 0;
    var result = [];
    if ((matched = string.match(RegExpStrings.STOPS)) !== null) {
      $.each(matched, function (i, item) {
        var stop = _this.parseStop(item);
        if (stop) {
          result.push(stop);
        }
      });
      return result;
    }
    return false;
  },
  formatStops: function formatStops(stops, cleanPosition) {
    var stop = void 0;
    var output = [];
    var positions = [];
    var colors = [];
    var position = void 0;

    for (var i = 0; i < stops.length; i++) {
      stop = stops[i];
      if (is.undefined(stop.position) || stop.position === null) {
        if (i === 0) {
          position = 0;
        } else if (i === stops.length - 1) {
          position = 1;
        } else {
          position = undefined;
        }
      } else {
        position = stop.position;
      }
      positions.push(position);
      colors.push(stop.color.toString());
    }

    positions = function (data) {
      var start = null;
      var average = void 0;
      for (var _i = 0; _i < data.length; _i++) {
        if (isNaN(data[_i])) {
          if (start === null) {
            start = _i;
            continue;
          }
        } else if (start) {
          average = (data[_i] - data[start - 1]) / (_i - start + 1);
          for (var j = start; j < _i; j++) {
            data[j] = data[start - 1] + (j - start + 1) * average;
          }
          start = null;
        }
      }

      return data;
    }(positions);

    for (var x = 0; x < stops.length; x++) {
      if (cleanPosition && (x === 0 && positions[x] === 0 || x === stops.length - 1 && positions[x] === 1)) {
        position = '';
      } else {
        position = ' ' + this.formatPosition(positions[x]);
      }

      output.push(colors[x] + position);
    }
    return output.join(', ');
  },
  parseStop: function parseStop(string) {
    var matched = void 0;
    if ((matched = RegExpStrings.STOP.exec(string)) !== null) {
      var position = this.parsePosition(matched[2]);

      return {
        color: matched[1],
        position: position
      };
    }
    return false;
  },
  parsePosition: function parsePosition(string) {
    if (is.string(string) && string.substr(-1) === '%') {
      string = parseFloat(string.slice(0, -1) / 100);
    }

    if (!is.undefined(string) && string !== null) {
      return parseFloat(string, 10);
    }
    return null;
  },
  formatPosition: function formatPosition(value) {
    return parseInt(value * 100, 10) + '%';
  },
  parseAngle: function parseAngle(string, notStandard) {
    if (is.string(string) && string.includes('deg')) {
      string = string.replace('deg', '');
    }
    if (!isNaN(string)) {
      if (notStandard) {
        string = this.fixOldAngle(string);
      }
    }
    if (is.string(string)) {
      var directions = string.split(' ');

      var filtered = [];
      for (var i in directions) {
        if (isDirection(directions[i])) {
          filtered.push(directions[i].toLowerCase());
        }
      }
      var keyword = filtered.join(' ');

      if (!string.includes('to ')) {
        keyword = reverseDirection(keyword);
      }
      keyword = 'to ' + keyword;
      if (keywordAngleMap.hasOwnProperty(keyword)) {
        string = keywordAngleMap[keyword];
      }
    }
    var value = parseFloat(string, 10);

    if (value > 360) {
      value %= 360;
    } else if (value < 0) {
      value %= -360;

      if (value !== 0) {
        value += 360;
      }
    }
    return value;
  },
  fixOldAngle: function fixOldAngle(value) {
    value = parseFloat(value);
    value = Math.abs(450 - value) % 360;
    value = parseFloat(value.toFixed(3));
    return value;
  },
  formatAngle: function formatAngle(value, notStandard, useKeyword) {
    value = parseInt(value, 10);
    if (useKeyword && angleKeywordMap.hasOwnProperty(value)) {
      value = angleKeywordMap[value];
      if (notStandard) {
        value = reverseDirection(value.substr(3));
      }
    } else {
      if (notStandard) {
        value = this.fixOldAngle(value);
      }
      value = value + 'deg';
    }

    return value;
  }
};

var ColorStop = function () {
  function ColorStop(color, position, gradient) {
    classCallCheck(this, ColorStop);

    this.color = Pj.color(color, gradient.options.color);
    this.position = GradientString.parsePosition(position);
    this.id = ++gradient.privateStopIdCount;
    this.gradient = gradient;
  }

  createClass(ColorStop, [{
    key: 'setPosition',
    value: function setPosition(string) {
      var position = GradientString.parsePosition(string);
      if (this.position !== position) {
        this.position = position;
        this.gradient.reorder();
      }
    }
  }, {
    key: 'setColor',
    value: function setColor(string) {
      this.color.fromString(string);
    }
  }, {
    key: 'remove',
    value: function remove() {
      this.gradient.removeById(this.id);
    }
  }]);
  return ColorStop;
}();

var GradientTypes = { LINEAR: {
    parse: function parse(result) {
      return {
        r: result[1].substr(-1) === '%' ? parseInt(result[1].slice(0, -1) * 2.55, 10) : parseInt(result[1], 10),
        g: result[2].substr(-1) === '%' ? parseInt(result[2].slice(0, -1) * 2.55, 10) : parseInt(result[2], 10),
        b: result[3].substr(-1) === '%' ? parseInt(result[3].slice(0, -1) * 2.55, 10) : parseInt(result[3], 10),
        a: 1
      };
    },
    to: function to(gradient, instance, prefix) {
      if (gradient.stops.length === 0) {
        return instance.options.emptyString;
      }
      if (gradient.stops.length === 1) {
        return gradient.stops[0].color.to(instance.options.degradationFormat);
      }

      var standard = instance.options.forceStandard;
      var privatePrefix = instance.privatePrefix;

      if (!privatePrefix) {
        standard = true;
      }
      if (prefix && $.inArray(prefix, instance.options.prefixes) !== -1) {
        standard = false;
        privatePrefix = prefix;
      }

      var angle = GradientString.formatAngle(gradient.angle, !standard, instance.options.angleUseKeyword);
      var stops = GradientString.formatStops(gradient.stops, instance.options.cleanPosition);

      var output = 'linear-gradient(' + angle + ', ' + stops + ')';
      if (standard) {
        return output;
      }
      return privatePrefix + output;
    }
  } };

var Gradient = function () {
  function Gradient(string, options) {
    classCallCheck(this, Gradient);

    if (is.object(string) && is.undefined(options)) {
      options = string;
      string = undefined;
    }
    this.value = {
      angle: 0,
      stops: []
    };
    this.options = $.extend(true, {}, defaults, options);

    this.privateType = 'LINEAR';
    this.privatePrefix = null;
    this.length = this.value.stops.length;
    this.current = 0;
    this.privateStopIdCount = 0;

    this.init(string);
  }

  createClass(Gradient, [{
    key: 'init',
    value: function init(string) {
      if (string) {
        this.fromString(string);
      }
    }
  }, {
    key: 'val',
    value: function val(value) {
      if (is.undefined(value)) {
        return this.toString();
      }
      this.fromString(value);
      return this;
    }
  }, {
    key: 'angle',
    value: function angle(value) {
      if (is.undefined(value)) {
        return this.value.angle;
      }
      this.value.angle = GradientString.parseAngle(value);
      return this;
    }
  }, {
    key: 'append',
    value: function append(color, position) {
      return this.insert(color, position, this.length);
    }
  }, {
    key: 'reorder',
    value: function reorder() {
      if (this.length < 2) {
        return;
      }

      this.value.stops = this.value.stops.sort(function (a, b) {
        return a.position - b.position;
      });
    }
  }, {
    key: 'insert',
    value: function insert(color, position, index) {
      if (is.undefined(index)) {
        index = this.current;
      }

      var stop = new ColorStop(color, position, this);

      this.value.stops.splice(index, 0, stop);

      this.length = this.length + 1;
      this.current = index;
      return stop;
    }
  }, {
    key: 'getById',
    value: function getById(id) {
      if (this.length > 0) {
        for (var i in this.value.stops) {
          if (id === this.value.stops[i].id) {
            return this.value.stops[i];
          }
        }
      }
      return false;
    }
  }, {
    key: 'removeById',
    value: function removeById(id) {
      var index = this.getIndexById(id);
      if (index) {
        this.remove(index);
      }
    }
  }, {
    key: 'getIndexById',
    value: function getIndexById(id) {
      var index = 0;
      for (var i in this.value.stops) {
        if (id === this.value.stops[i].id) {
          return index;
        }
        index++;
      }
      return false;
    }
  }, {
    key: 'getCurrent',
    value: function getCurrent() {
      return this.value.stops[this.current];
    }
  }, {
    key: 'setCurrentById',
    value: function setCurrentById(id) {
      var index = 0;
      for (var i in this.value.stops) {
        if (this.value.stops[i].id !== id) {
          index++;
        } else {
          this.current = index;
        }
      }
    }
  }, {
    key: 'get',
    value: function get$$1(index) {
      if (is.undefined(index)) {
        index = this.current;
      }
      if (index >= 0 && index < this.length) {
        this.current = index;
        return this.value.stops[index];
      }
      return false;
    }
  }, {
    key: 'remove',
    value: function remove(index) {
      if (is.undefined(index)) {
        index = this.current;
      }
      if (index >= 0 && index < this.length) {
        this.value.stops.splice(index, 1);
        this.length = this.length - 1;
        this.current = index - 1;
      }
    }
  }, {
    key: 'empty',
    value: function empty() {
      this.value.stops = [];
      this.length = 0;
      this.current = 0;
    }
  }, {
    key: 'reset',
    value: function reset() {
      this.value.privateAngle = 0;
      this.empty();
      this.privatePrefix = null;
      this.privateType = 'LINEAR';
    }
  }, {
    key: 'type',
    value: function type(_type) {
      if (is.string(_type) && (_type = _type.toUpperCase()) && !is.undefined(GradientTypes[_type])) {
        this.privateType = _type;
        return this;
      }
      return this.privateType;
    }
  }, {
    key: 'fromString',
    value: function fromString(string) {
      var _this = this;

      this.reset();

      var result = GradientString.parseString(string);
      if (result) {
        this.privatePrefix = result.prefix;
        this.type(result.type);
        if (result.value) {
          this.value.angle = GradientString.parseAngle(result.value.angle, this.privatePrefix !== null);

          $.each(result.value.stops, function (i, stop) {
            _this.append(stop.color, stop.position);
          });
        }
      }
    }
  }, {
    key: 'toString',
    value: function toString(prefix) {
      if (prefix === true) {
        prefix = getPrefix();
      }
      return GradientTypes[this.type()].to(this.value, this, prefix);
    }
  }, {
    key: 'matchString',
    value: function matchString(string) {
      return GradientString.matchString(string);
    }
  }, {
    key: 'toStringWithAngle',
    value: function toStringWithAngle(angle, prefix) {
      var value = $.extend(true, {}, this.value);
      value.angle = GradientString.parseAngle(angle);

      if (prefix === true) {
        prefix = getPrefix();
      }

      return GradientTypes[this.type()].to(value, this, prefix);
    }
  }, {
    key: 'getPrefixedStrings',
    value: function getPrefixedStrings() {
      var strings = [];
      for (var i = 0; i < this.options.prefixes.length; i++) {
        strings.push(this.toString(this.options.prefixes[i]));
      }
      return strings;
    }
  }], [{
    key: 'setDefaults',
    value: function setDefaults(options) {
      $.extend(true, defaults, $.isPlainObject(options) && options);
    }
  }]);
  return Gradient;
}();

Pj.gradient = function () {
  for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }

  return new (Function.prototype.bind.apply(Gradient, [null].concat(args)))();
};

Pj.gradient.Constructor = Gradient;

$.extend(Pj.gradient, { setDefaults: Gradient.setDefaults }, GradientString, info);

var main = Pj.gradient;

exports['default'] = main;

Object.defineProperty(exports, '__esModule', { value: true });

})));

(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
	typeof define === 'function' && define.amd ? define(['exports'], factory) :
	(factory((global['@pluginjs/keyboard'] = {})));
}(this, (function (exports) { 'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) {
  return typeof obj;
} : function (obj) {
  return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
};





var asyncGenerator = function () {
  function AwaitValue(value) {
    this.value = value;
  }

  function AsyncGenerator(gen) {
    var front, back;

    function send(key, arg) {
      return new Promise(function (resolve, reject) {
        var request = {
          key: key,
          arg: arg,
          resolve: resolve,
          reject: reject,
          next: null
        };

        if (back) {
          back = back.next = request;
        } else {
          front = back = request;
          resume(key, arg);
        }
      });
    }

    function resume(key, arg) {
      try {
        var result = gen[key](arg);
        var value = result.value;

        if (value instanceof AwaitValue) {
          Promise.resolve(value.value).then(function (arg) {
            resume("next", arg);
          }, function (arg) {
            resume("throw", arg);
          });
        } else {
          settle(result.done ? "return" : "normal", result.value);
        }
      } catch (err) {
        settle("throw", err);
      }
    }

    function settle(type, value) {
      switch (type) {
        case "return":
          front.resolve({
            value: value,
            done: true
          });
          break;

        case "throw":
          front.reject(value);
          break;

        default:
          front.resolve({
            value: value,
            done: false
          });
          break;
      }

      front = front.next;

      if (front) {
        resume(front.key, front.arg);
      } else {
        back = null;
      }
    }

    this._invoke = send;

    if (typeof gen.return !== "function") {
      this.return = undefined;
    }
  }

  if (typeof Symbol === "function" && Symbol.asyncIterator) {
    AsyncGenerator.prototype[Symbol.asyncIterator] = function () {
      return this;
    };
  }

  AsyncGenerator.prototype.next = function (arg) {
    return this._invoke("next", arg);
  };

  AsyncGenerator.prototype.throw = function (arg) {
    return this._invoke("throw", arg);
  };

  AsyncGenerator.prototype.return = function (arg) {
    return this._invoke("return", arg);
  };

  return {
    wrap: function (fn) {
      return function () {
        return new AsyncGenerator(fn.apply(this, arguments));
      };
    },
    await: function (value) {
      return new AwaitValue(value);
    }
  };
}();





var classCallCheck = function (instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
};

var createClass = function () {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  return function (Constructor, protoProps, staticProps) {
    if (protoProps) defineProperties(Constructor.prototype, protoProps);
    if (staticProps) defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();



























var slicedToArray = function () {
  function sliceIterator(arr, i) {
    var _arr = [];
    var _n = true;
    var _d = false;
    var _e = undefined;

    try {
      for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
        _arr.push(_s.value);

        if (i && _arr.length === i) break;
      }
    } catch (err) {
      _d = true;
      _e = err;
    } finally {
      try {
        if (!_n && _i["return"]) _i["return"]();
      } finally {
        if (_d) throw _e;
      }
    }

    return _arr;
  }

  return function (arr, i) {
    if (Array.isArray(arr)) {
      return arr;
    } else if (Symbol.iterator in Object(arr)) {
      return sliceIterator(arr, i);
    } else {
      throw new TypeError("Invalid attempt to destructure non-iterable instance");
    }
  };
}();

var Emitter = function () {
  function Emitter() {
    classCallCheck(this, Emitter);

    this.listeners = {};
    this.sortedListeners = {};
  }

  createClass(Emitter, [{
    key: 'emit',
    value: function emit(event) {
      var listeners = this.getListeners(event);

      for (var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }

      for (var i = 0; i < listeners.length; i++) {
        var context = null;

        if (listeners[i].context !== null) {
          context = listeners[i].context;
        } else {
          context = { type: event };
        }

        var result = listeners[i].listener.apply(context, args);

        if (result === false) {
          return false;
        }
      }

      return true;
    }
  }, {
    key: 'on',
    value: function on(event, listener, context, priority) {
      return this.addListener(event, listener, context, priority);
    }
  }, {
    key: 'once',
    value: function once(event, listener, context, priority) {
      return this.addOneTimeListener(event, listener, context, priority);
    }
  }, {
    key: 'off',
    value: function off(event, listener) {
      if (typeof listener === 'undefined') {
        return this.removeAllListeners(event);
      }

      return this.removeListener(event, listener);
    }

    /* Lower numbers correspond with earlier execution,
    /* and functions with the same priority are executed
    /* in the order in which they were added to the action. */

  }, {
    key: 'addListener',
    value: function addListener(event, listener) {
      var context = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;
      var priority = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 10;

      this.ensureListener(listener);

      if (!this.listeners[event]) {
        this.listeners[event] = {};
      }
      if (!this.listeners[event][priority]) {
        this.listeners[event][priority] = [];
      }

      this.listeners[event][priority].push({
        context: context,
        listener: listener
      });
      this.clearSortedListeners(event);

      return this;
    }
  }, {
    key: 'addOneTimeListener',
    value: function addOneTimeListener(event, listener, context) {
      var priority = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 10;

      var that = this;
      function wrapper() {
        that.removeListener(event, wrapper);

        return listener.apply(undefined, arguments);
      }

      this.addListener(event, wrapper, context, priority);

      return this;
    }
  }, {
    key: 'removeListener',
    value: function removeListener(event, listener) {
      this.clearSortedListeners(event);
      var listeners = this.hasListeners(event) ? this.listeners[event] : [];

      for (var priority in listeners) {
        if (Object.prototype.hasOwnProperty.call(listeners, priority)) {
          listeners[priority] = listeners[priority].filter(function (value) {
            return value.listener !== listener;
          });

          if (listeners[priority].length === 0) {
            delete listeners[priority];
          }
        }
      }

      this.listeners[event] = listeners;

      return this;
    }
  }, {
    key: 'removeAllListeners',
    value: function removeAllListeners(event) {
      this.clearSortedListeners(event);

      if (this.hasListeners(event)) {
        delete this.listeners[event];
      }

      return this;
    }
  }, {
    key: 'ensureListener',
    value: function ensureListener(listener) {
      var type = typeof listener === 'undefined' ? 'undefined' : _typeof(listener);
      if (type === 'function') {
        return listener;
      }
      throw new TypeError('Listeners should be function or closure. Received type: ' + type);
    }
  }, {
    key: 'hasListeners',
    value: function hasListeners(event) {
      if (!this.listeners[event] || Object.keys(this.listeners[event]).length === 0) {
        return false;
      }

      return true;
    }
  }, {
    key: 'getListeners',
    value: function getListeners(event) {
      if (!this.sortedListeners.hasOwnProperty(event)) {
        this.sortedListeners[event] = this.getSortedListeners(event);
      }

      return this.sortedListeners[event];
    }
  }, {
    key: 'getSortedListeners',
    value: function getSortedListeners(event) {
      if (!this.hasListeners(event)) {
        return [];
      }

      var listeners = this.listeners[event];

      var priorities = Object.keys(listeners);
      priorities.sort(function (a, b) {
        return a - b;
      });

      var sortedlisteners = [];
      for (var i = 0; i < priorities.length; i++) {
        sortedlisteners = sortedlisteners.concat(listeners[priorities[i]]);
      }

      return sortedlisteners;
    }
  }, {
    key: 'clearSortedListeners',
    value: function clearSortedListeners(event) {
      delete this.sortedListeners[event];
    }
  }]);
  return Emitter;
}();

var asyncGenerator$1 = function () {
  function AwaitValue(value) {
    this.value = value;
  }

  function AsyncGenerator(gen) {
    var front, back;

    function send(key, arg) {
      return new Promise(function (resolve, reject) {
        var request = {
          key: key,
          arg: arg,
          resolve: resolve,
          reject: reject,
          next: null
        };

        if (back) {
          back = back.next = request;
        } else {
          front = back = request;
          resume(key, arg);
        }
      });
    }

    function resume(key, arg) {
      try {
        var result = gen[key](arg);
        var value = result.value;

        if (value instanceof AwaitValue) {
          Promise.resolve(value.value).then(function (arg) {
            resume("next", arg);
          }, function (arg) {
            resume("throw", arg);
          });
        } else {
          settle(result.done ? "return" : "normal", result.value);
        }
      } catch (err) {
        settle("throw", err);
      }
    }

    function settle(type, value) {
      switch (type) {
        case "return":
          front.resolve({
            value: value,
            done: true
          });
          break;

        case "throw":
          front.reject(value);
          break;

        default:
          front.resolve({
            value: value,
            done: false
          });
          break;
      }

      front = front.next;

      if (front) {
        resume(front.key, front.arg);
      } else {
        back = null;
      }
    }

    this._invoke = send;

    if (typeof gen.return !== "function") {
      this.return = undefined;
    }
  }

  if (typeof Symbol === "function" && Symbol.asyncIterator) {
    AsyncGenerator.prototype[Symbol.asyncIterator] = function () {
      return this;
    };
  }

  AsyncGenerator.prototype.next = function (arg) {
    return this._invoke("next", arg);
  };

  AsyncGenerator.prototype.throw = function (arg) {
    return this._invoke("throw", arg);
  };

  AsyncGenerator.prototype.return = function (arg) {
    return this._invoke("return", arg);
  };

  return {
    wrap: function wrap(fn) {
      return function () {
        return new AsyncGenerator(fn.apply(this, arguments));
      };
    },
    await: function _await(value) {
      return new AwaitValue(value);
    }
  };
}();

/*eslint-disable */
/* Credit to http://is.js.org MIT */
var toString = Object.prototype.toString;
var is = {
  // Type checks
  /* -------------------------------------------------------------------------- */
  // is a given value Arguments?
  arguments: function _arguments(value) {
    // fallback check is for IE
    return toString.call(value) === '[object Arguments]' || value != null && (typeof value === 'undefined' ? 'undefined' : _typeof(value)) === 'object' && 'callee' in value;
  },

  // is a given value Array?
  array: function array(val) {
    if (Array.isArray) {
      return Array.isArray(val);
    }
    return toString.call(val) === '[object Array]';
  },

  // is a given value Boolean?
  boolean: function boolean(val) {
    return val === true || val === false || toString.call(val) === '[object Boolean]';
  },

  // is a given value Char?
  char: function char(val) {
    return this.string(val) && val.length === 1;
  },

  // is a given value Date Object?
  date: function date(value) {
    return toString.call(value) === '[object Date]';
  },

  // is a given object a DOM node?
  domNode: function domNode(object) {
    return this.object(object) && object.nodeType > 0;
  },

  // is a given value Error object?
  error: function error(val) {
    return toString.call(val) === '[object Error]';
  },

  // is a given value function?
  function: function _function(val) {
    // fallback check is for IE
    return toString.call(val) === '[object Function]' || typeof val === 'function';
  },

  // is given value a pure JSON object?
  json: function json(value) {
    return toString.call(value) === '[object Object]';
  },

  // is a given value NaN?
  nan: function nan(val) {
    // NaN is number :) Also it is the only value which does not equal itself
    return val !== val;
  },

  // is a given value null?
  null: function _null(val) {
    return val === null;
  },

  // is a given value number?
  number: function number(val) {
    return !this.nan(val) && toString.call(val) === '[object Number]';
  },

  // is a given value object?
  object: function object(val) {
    return Object(val) === val;
  },

  // is a given value empty object?
  emptyObject: function emptyObject(val) {
    return this.object(val) && Object.getOwnPropertyNames(val).length == 0;
  },

  // is a given value RegExp?
  regexp: function regexp(val) {
    return toString.call(val) === '[object RegExp]';
  },

  // is a given value String?
  string: function string(val) {
    return typeof val === 'string' || toString.call(val) === '[object String]';
  },

  // is a given value undefined?
  undefined: function undefined(val) {
    return val === void 0;
  },

  // Arithmetic checks
  /* -------------------------------------------------------------------------- */
  // is a given value numeric?
  numeric: function numeric(n) {
    return (this.number(n) || this.string(n)) && !this.nan(n - parseFloat(n));
  },

  // is a given number percentage?
  percentage: function percentage(n) {
    return typeof n === 'string' && n.indexOf('%') !== -1;
  },

  // is a given number decimal?
  decimal: function decimal(n) {
    return this.number(n) && n % 1 !== 0;
  },

  // is a given number finite?
  finite: function finite(n) {
    if (isFinite) {
      return isFinite(n);
    }
    return !this.infinite(n) && !this.nan(n);
  },

  // is a given number infinite?
  infinite: function infinite(n) {
    return n === Infinity || n === -Infinity;
  },

  integer: function integer(n) {
    return this.number(n) && n % 1 === 0;
  },

  // is a given number negative?
  negative: function negative(n) {
    return this.number(n) && n < 0;
  },

  // is a given number positive?
  positive: function positive(n) {
    return this.number(n) && n > 0;
  }
};

var Each = function Each(obj, callback) {
  var length = void 0,
      i = 0;

  if (is.array(obj)) {
    length = obj.length;
    for (; i < length; i++) {
      callback(obj[i], i);
    }
  } else {
    Object.entries(obj).map(function (_ref2) {
      var _ref3 = slicedToArray(_ref2, 2),
          k = _ref3[0],
          v = _ref3[1];

      return callback(k, v);
    });
  }

  return obj;
};




// 解析 HTML/SVG/XML 字符串

/* eslint object-property-newline: 'off' */
var MAP_BY_CODE = {
  8: 'backspace',
  9: 'tab',
  13: 'enter',
  16: 'shift',
  17: 'ctrl',
  18: 'alt',
  20: 'caps_lock',
  27: 'esc',
  32: 'space',
  33: 'page_up',
  34: 'page_down',
  35: 'end',
  36: 'home',
  37: 'left',
  38: 'up',
  39: 'right',
  40: 'down',
  45: 'insert',
  46: 'delete',
  48: '0',
  49: '1',
  50: '2',
  51: '3',
  52: '4',
  53: '5',
  54: '6',
  55: '7',
  56: '8',
  57: '9',
  65: 'a',
  66: 'b',
  67: 'c',
  68: 'd',
  69: 'e',
  70: 'f',
  71: 'g',
  72: 'h',
  73: 'i',
  74: 'j',
  75: 'k',
  76: 'l',
  77: 'm',
  78: 'n',
  79: 'o',
  80: 'p',
  81: 'q',
  82: 'r',
  83: 's',
  84: 't',
  85: 'u',
  86: 'v',
  87: 'w',
  88: 'x',
  89: 'y',
  90: 'z',
  91: 'command',
  112: 'f1',
  113: 'f2',
  114: 'f3',
  115: 'f4',
  116: 'f5',
  117: 'f6',
  118: 'f7',
  119: 'f8',
  120: 'f9',
  121: 'f10',
  122: 'f11',
  123: 'f12',
  144: 'num_lock'
};

var MAP_BY_NAME = {};

for (var key in MAP_BY_CODE) {
  if (Object.prototype.hasOwnProperty.call(MAP_BY_CODE, key)) {
    MAP_BY_NAME[MAP_BY_CODE[key]] = Number(key);
  }
}

var MODIFIERS = {
  16: 'shift',
  17: 'ctrl',
  18: 'alt',
  91: 'command'
};

var Keyboard = function () {
  function Keyboard(element) {
    classCallCheck(this, Keyboard);

    this.element = element || window.document;
    this.emitter = new Emitter();

    this.initialize();
    this.registerEvent();
  }

  createClass(Keyboard, [{
    key: 'initialize',
    value: function initialize() {
      var _this = this;

      this.status = {};
      Each(MODIFIERS, function (keyCode, keyName) {
        _this.status[keyName] = false;

        _this.emitter.on(keyCode + 'down', function () {
          if (_this.status[keyName]) {
            return;
          }
          _this.status[keyName] = true;
        });
        _this.emitter.on(keyCode + 'up', function () {
          if (!_this.status[keyName]) {
            return;
          }
          _this.status[keyName] = false;
        });
      });
    }
  }, {
    key: 'registerEvent',
    value: function registerEvent() {
      var _this2 = this;

      var handler = function handler(e) {
        return _this2.handler(e);
      };
      this.element.addEventListener('keydown', handler);
      this.element.addEventListener('keyup', handler);
      // bindEvent({ type: 'keyup', handler }, this.element)
      // bindEvent({ type: 'keydown', handler }, this.element)
    }
  }, {
    key: 'handler',
    value: function handler(e) {
      /* eslint consistent-return: "off" */
      var keyCode = e.keyCode;
      var action = e.type === 'keydown' ? 'down' : 'up';
      var prefix = '';

      if (keyCode === 93 || keyCode === 224) {
        keyCode = 91;
      }

      // if (!this.filter(e)) return;

      if (keyCode in MODIFIERS) {
        var result = this.emitter.emit(keyCode + action);
        if (result === false) {
          return false;
        }
      }

      Each(this.status, function (keyName, status) {
        if (status) {
          prefix += keyName;
        }
      });

      var eventName = prefix + keyCode + action;

      if (!(eventName in this.emitter.listeners)) {
        return;
      }

      return this.emitter.emit(eventName);
    }
  }, {
    key: 'on',
    value: function on(action, key, func) {
      return this.dispatch(true, action, key, func);
    }
  }, {
    key: 'off',
    value: function off(action, key, func) {
      return this.dispatch(false, action, key, func);
    }
  }, {
    key: 'dispatch',
    value: function dispatch(toggle, action, key, func) {
      var _this3 = this;

      var keys = this.parseKeys(this.processKey(key));
      keys.forEach(function (key) {
        var modifiers = key.modifiers;
        var keyCode = key.keyCode;
        var prefix = '';

        if (modifiers !== null) {
          for (var i = 0; i < modifiers.length; i++) {
            prefix += MODIFIERS[modifiers[i]];
          }
        }

        if (toggle) {
          _this3.emitter.on(prefix + keyCode + action, func);
        } else {
          _this3.emitter.off(prefix + keyCode + action, func);
        }
      });

      return this;
    }
  }, {
    key: 'parseKeys',
    value: function parseKeys(keys) {
      var _this4 = this;

      var newKeys = [];
      keys.map(function (key) {
        var newKey = {};
        var modifiers = null;

        key = key.split('+');
        var length = key.length;

        if (length > 1) {
          modifiers = _this4.processModifiers(key);
          key = [key[length - 1]];
        }

        key = _this4.getKeyCode(key[0]);

        newKey.modifiers = modifiers;
        newKey.keyCode = key;
        newKeys.push(newKey);
        return key;
      });

      return newKeys;
    }
  }, {
    key: 'processKey',
    value: function processKey(key) {
      key = key.toLowerCase().replace(/\s/g, '');
      var keys = key.split(',');
      if (keys[keys.length - 1] === '') {
        keys[keys.length - 2] += ',';
      }
      return keys;
    }
  }, {
    key: 'processModifiers',
    value: function processModifiers(key) {
      var modifiers = key.slice(0, key.length - 1);

      for (var i = 0; i < modifiers.length; i++) {
        modifiers[i] = MAP_BY_NAME[modifiers[i]];
      }

      modifiers.sort();

      return modifiers;
    }
  }, {
    key: 'distribute',
    value: function distribute(action, key, func) {
      return func === null || func === undefined ? this.off(action, key, func) : this.on(action, key, func);
    }
  }, {
    key: 'getKeyName',
    value: function getKeyName(keyCode) {
      return MAP_BY_CODE[keyCode];
    }
  }, {
    key: 'getKeyCode',
    value: function getKeyCode(keyName) {
      return MAP_BY_NAME[keyName];
    }
  }, {
    key: 'up',
    value: function up(key, func) {
      return this.distribute('up', key, func);
    }
  }, {
    key: 'down',
    value: function down(key, func) {
      return this.distribute('down', key, func);
    }
  }]);
  return Keyboard;
}();

var keyboard = {
  init: function init(element) {
    return new Keyboard(element);
  }
};

exports['default'] = keyboard;

Object.defineProperty(exports, '__esModule', { value: true });

})));

(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
	typeof define === 'function' && define.amd ? define(['exports'], factory) :
	(factory((global['@pluginjs/keyframes'] = {})));
}(this, (function (exports) { 'use strict';

/* eslint object-property-newline: 'off' */
var Keyframes = {
  bounce: [{
    transform: 'translate3d(0,0,0)',
    offset: 0
  }, {
    transform: 'translate3d(0,0,0)',
    offset: 0.2
  }, {
    transform: 'translate3d(0,-30px,0)',
    offset: 0.4
  }, {
    transform: 'translate3d(0,-30px,0)',
    offset: 0.43
  }, {
    transform: 'translate3d(0,0,0)',
    offset: 0.53
  }, {
    transform: 'translate3d(0,-15px,0)',
    offset: 0.7
  }, {
    transform: 'translate3d(0,0,0)',
    offset: 0.8
  }, {
    transform: 'translate3d(0,-15px,0)',
    offset: 0.9
  }, {
    transform: 'translate3d(0,0,0)',
    offset: 1
  }],
  bounceIn: [{
    transform: 'scale3d(.3, .3, .3)',
    opacity: '0',
    offset: 0
  }, {
    transform: 'scale3d(1.1, 1.1, 1.1)',
    offset: 0.2
  }, {
    transform: 'scale3d(.9, .9, .9)',
    offset: 0.4
  }, {
    transform: 'scale3d(1.03, 1.03, 1.03)',
    opacity: '1',
    offset: 0.6
  }, {
    transform: 'scale3d(.97, .97, .97)',
    offset: 0.8
  }, {
    transform: 'scale3d(1, 1, 1)',
    opacity: '1',
    offset: 1
  }],
  bounceOut: [{
    transform: 'none',
    opacity: '1',
    offset: 0
  }, {
    transform: 'scale3d(.9, .9, .9)',
    opacity: '1',
    offset: 0.2
  }, {
    transform: 'scale3d(1.1, 1.1, 1.1)',
    opacity: '1',
    offset: 0.5
  }, {
    transform: 'scale3d(1.1, 1.1, 1.1)',
    opacity: '1',
    offset: 0.55
  }, {
    transform: 'scale3d(.3, .3, .3)',
    opacity: '0',
    offset: 1
  }],
  bounceInDown: [{
    transform: 'translate3d(0, -3000px, 0)',
    opacity: '0',
    offset: 0
  }, {
    transform: 'translate3d(0, 25px, 0)',
    opacity: '1',
    offset: 0.6
  }, {
    transform: 'translate3d(0, -100px, 0)',
    offset: 0.75
  }, {
    transform: 'translate3d(0, 5px, 0)',
    offset: 0.9
  }, {
    transform: 'none',
    opacity: '1',
    offset: 1
  }],
  bounceOutDown: [{
    transform: 'none',
    opacity: '1',
    offset: 0
  }, {
    transform: 'translate3d(0, 50px, 0)',
    opacity: '1',
    offset: 0.2
  }, {
    transform: 'translate3d(0, -20px, 0)',
    opacity: '1',
    offset: 0.4
  }, {
    transform: 'translate3d(0, -20px, 0)',
    opacity: '1',
    offset: 0.45
  }, {
    transform: 'translate3d(0, 2000px, 0)',
    opacity: '0',
    offset: 1
  }],
  bounceInUp: [{
    transform: 'translate3d(0, 3000px, 0)',
    opacity: '0',
    offset: 0
  }, {
    transform: 'translate3d(0, -25px, 0)',
    opacity: '1',
    offset: 0.6
  }, {
    transform: 'translate3d(0, 100px, 0)',
    offset: 0.75
  }, {
    transform: 'translate3d(0, -5px, 0)',
    offset: 0.9
  }, {
    transform: 'translate3d(0, 0, 0)',
    opacity: '1',
    offset: 1
  }],
  bounceOutUp: [{
    transform: 'none',
    opacity: '1',
    offset: 0
  }, {
    transform: 'translate3d(0, 50px, 0)',
    opacity: '1',
    offset: 0.2
  }, {
    transform: 'translate3d(0, 20px, 0)',
    opacity: '1',
    offset: 0.4
  }, {
    transform: 'translate3d(0, 20px, 0)',
    opacity: '1',
    offset: 0.45
  }, {
    transform: 'translate3d(0, -2000px, 0)',
    opacity: '0',
    offset: 1
  }],
  bounceInLeft: [{
    transform: 'translate3d(-3000px, 0, 0)',
    opacity: '0',
    offset: 0
  }, {
    transform: 'translate3d(25px, 0, 0)',
    opacity: '1',
    offset: 0.6
  }, {
    transform: 'translate3d(-100px, 0, 0)',
    offset: 0.75
  }, {
    transform: 'translate3d(5px, 0, 0)',
    offset: 0.9
  }, {
    transform: 'none',
    opacity: '1',
    offset: 1
  }],
  bounceOutLeft: [{
    transform: 'none',
    opacity: '1',
    offset: 0
  }, {
    transform: 'translate3d(100px, 0, 0)',
    opacity: '1',
    offset: 0.2
  }, {
    transform: 'translate3d(-20px, 0, 0)',
    opacity: '1',
    offset: 0.4
  }, {
    transform: 'translate3d(-20px, 0, 0)',
    opacity: '1',
    offset: 0.45
  }, {
    transform: 'translate3d(-2000px, 0, 0)',
    opacity: '0',
    offset: 1
  }],
  bounceInRight: [{
    transform: 'translate3d(3000px, 0, 0)',
    opacity: '0',
    offset: 0
  }, {
    transform: 'translate3d(-25px, 0, 0)',
    opacity: '1',
    offset: 0.6
  }, {
    transform: 'translate3d(100px, 0, 0)',
    offset: 0.75
  }, {
    transform: 'translate3d(-5px, 0, 0)',
    offset: 0.9
  }, {
    transform: 'none',
    opacity: '1',
    offset: 1
  }],
  bounceOutRight: [{
    transform: 'none',
    opacity: '1',
    offset: 0
  }, {
    transform: 'translate3d(100px, 0, 0)',
    opacity: '1',
    offset: 0.2
  }, {
    transform: 'translate3d(-20px, 0, 0)',
    opacity: '1',
    offset: 0.4
  }, {
    transform: 'translate3d(-20px, 0, 0)',
    opacity: '1',
    offset: 0.45
  }, {
    transform: 'translate3d(2000px, 0, 0)',
    opacity: '0',
    offset: 1
  }],
  flip: [{
    transform: 'perspective(400px) rotate3d(0, 1, 0, -360deg)',
    offset: 0
  }, {
    transform: 'perspective(400px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -190deg)',
    offset: 0.4
  }, {
    transform: 'perspective(400px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -170deg)',
    offset: 0.5
  }, {
    transform: 'perspective(400px) scale3d(.95, .95, .95)',
    offset: 0.8
  }, {
    transform: 'perspective(400px)',
    offset: 1
  }],
  flipInX: [{
    transform: 'perspective(400px) rotate3d(1, 0, 0, 90deg)',
    opacity: '0',
    offset: 0
  }, {
    transform: 'perspective(400px) rotate3d(1, 0, 0, -20deg)',
    offset: 0.4
  }, {
    transform: 'perspective(400px) rotate3d(1, 0, 0, 10deg)',
    opacity: '1',
    offset: 0.6
  }, {
    transform: 'perspective(400px) rotate3d(1, 0, 0, -5deg)',
    opacity: '1',
    offset: 0.8
  }, {
    transform: 'perspective(400px)',
    opacity: '1',
    offset: 1
  }],
  flipOutX: [{
    transform: 'perspective(400px)',
    opacity: '1',
    offset: 0
  }, {
    transform: 'perspective(400px) rotate3d(1, 0, 0, -20deg)',
    opacity: '1',
    offset: 0.3
  }, {
    transform: 'perspective(400px) rotate3d(1, 0, 0, 90deg)',
    opacity: '0',
    offset: 1
  }],
  flipInY: [{
    transform: 'perspective(400px) rotate3d(0, 1, 0, 90deg)',
    opacity: '0',
    offset: 0
  }, {
    transform: 'perspective(400px) rotate3d(0, 1, 0, -20deg)',
    offset: 0.4
  }, {
    transform: 'perspective(400px) rotate3d(0, 1, 0, 10deg)',
    opacity: '1',
    offset: 0.6
  }, {
    transform: 'perspective(400px) rotate3d(0, 1, 0, -5deg)',
    opacity: '1',
    offset: 0.8
  }, {
    transform: 'perspective(400px)',
    opacity: '1',
    offset: 1
  }],
  flipOutY: [{
    transform: 'perspective(400px)',
    opacity: '1',
    offset: 0
  }, {
    transform: 'perspective(400px) rotate3d(0, 1, 0, -20deg)',
    opacity: '1',
    offset: 0.3
  }, {
    transform: 'perspective(400px) rotate3d(0, 1, 0, 90deg)',
    opacity: '0',
    offset: 1
  }],
  flash: [{
    opacity: '1',
    offset: 0
  }, {
    opacity: '0',
    offset: 0.25
  }, {
    opacity: '1',
    offset: 0.5
  }, {
    opacity: '0',
    offset: 0.75
  }, {
    opacity: '1',
    offset: 1
  }],
  pulse: [{
    transform: 'scale3d(1, 1, 1)',
    offset: 0
  }, {
    transform: 'scale3d(1.05, 1.05, 1.05)',
    offset: 0.5
  }, {
    transform: 'scale3d(1, 1, 1)',
    offset: 1
  }],
  rubberBand: [{
    transform: 'scale3d(1, 1, 1)',
    offset: 0
  }, {
    transform: 'scale3d(1.25, 0.75, 1)',
    offset: 0.3
  }, {
    transform: 'scale3d(0.75, 1.25, 1)',
    offset: 0.4
  }, {
    transform: 'scale3d(1.15, 0.85, 1)',
    offset: 0.5
  }, {
    transform: 'scale3d(.95, 1.05, 1)',
    offset: 0.65
  }, {
    transform: 'scale3d(1.05, .95, 1)',
    offset: 0.75
  }, {
    transform: 'scale3d(1, 1, 1)',
    offset: 1
  }],
  lightSpeedInRight: [{
    transform: 'translate3d(100%, 0, 0) skewX(-30deg)',
    opacity: '0',
    offset: 0
  }, {
    transform: 'skewX(20deg)',
    opacity: '1',
    offset: 0.6
  }, {
    transform: 'skewX(-5deg)',
    opacity: '1',
    offset: 0.8
  }, {
    transform: 'none',
    opacity: '1 ',
    offset: 1
  }],
  lightSpeedOutRight: [{
    transform: 'none',
    opacity: '1 ',
    offset: 0
  }, {
    transform: 'translate3d(100%, 0, 0) skewX(30deg)',
    opacity: '0',
    offset: 1
  }],
  lightSpeedInLeft: [{
    transform: 'translate3d(-100%, 0, 0) skewX(-30deg)',
    opacity: '0',
    offset: 0
  }, {
    transform: 'skewX(20deg)',
    opacity: '1',
    offset: 0.6
  }, {
    transform: 'skewX(-5deg)',
    opacity: '1',
    offset: 0.8
  }, {
    transform: 'none',
    opacity: '1 ',
    offset: 1
  }],
  lightSpeedOutLeft: [{
    transform: 'none',
    opacity: '1 ',
    offset: 0
  }, {
    transform: 'translate3d(-100%, 0, 0) skewX(30deg)',
    opacity: '0',
    offset: 1
  }],
  shake: [{
    transform: 'translate3d(0, 0, 0)',
    offset: 0
  }, {
    transform: 'translate3d(-10px, 0, 0)',
    offset: 0.1
  }, {
    transform: 'translate3d(10px, 0, 0)',
    offset: 0.2
  }, {
    transform: 'translate3d(-10px, 0, 0)',
    offset: 0.3
  }, {
    transform: 'translate3d(10px, 0, 0)',
    offset: 0.4
  }, {
    transform: 'translate3d(-10px, 0, 0)',
    offset: 0.5
  }, {
    transform: 'translate3d(10px, 0, 0)',
    offset: 0.6
  }, {
    transform: 'translate3d(-10px, 0, 0)',
    offset: 0.7
  }, {
    transform: 'translate3d(10px, 0, 0)',
    offset: 0.8
  }, {
    transform: 'translate3d(-10px, 0, 0)',
    offset: 0.9
  }, {
    transform: 'translate3d(0, 0, 0)',
    offset: 1
  }],
  swing: [{
    transform: 'translate(0%)',
    offset: 0
  }, {
    transform: 'rotate3d(0, 0, 1, 15deg)',
    offset: 0.2
  }, {
    transform: 'rotate3d(0, 0, 1, -10deg)',
    offset: 0.4
  }, {
    transform: 'rotate3d(0, 0, 1, 5deg)',
    offset: 0.6
  }, {
    transform: 'rotate3d(0, 0, 1, -5deg)',
    offset: 0.8
  }, {
    transform: 'rotate3d(0, 0, 1, 0deg)',
    offset: 1
  }],
  tada: [{
    transform: 'scale3d(1, 1, 1)',
    offset: 0
  }, {
    transform: 'scale3d(.9, .9, .9) rotate3d(0, 0, 1, -3deg)',
    offset: 0.1
  }, {
    transform: 'scale3d(.9, .9, .9) rotate3d(0, 0, 1, -3deg)',
    offset: 0.2
  }, {
    transform: 'scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, 3deg)',
    offset: 0.3
  }, {
    transform: 'scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, -3deg)',
    offset: 0.4
  }, {
    transform: 'scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, 3deg)',
    offset: 0.5
  }, {
    transform: 'scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, -3deg)',
    offset: 0.6
  }, {
    transform: 'scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, 3deg)',
    offset: 0.7
  }, {
    transform: 'scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, -3deg)',
    offset: 0.8
  }, {
    transform: 'scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, 3deg)',
    offset: 0.9
  }, {
    transform: 'scale3d(1, 1, 1)',
    offset: 1
  }],
  wobble: [{
    transform: 'translate(0%)',
    offset: 0
  }, {
    transform: 'translate3d(20%, 0, 0) rotate3d(0, 0, 1, 3deg)',
    offset: 0.15
  }, {
    transform: 'translate3d(-15%, 0, 0) rotate3d(0, 0, 1, -3deg)',
    offset: 0.45
  }, {
    transform: 'translate3d(10%, 0, 0) rotate3d(0, 0, 1, 2deg)',
    offset: 0.6
  }, {
    transform: 'translate3d(-5%, 0, 0) rotate3d(0, 0, 1, -1deg)',
    offset: 0.75
  }, {
    transform: 'translateX(0%)',
    offset: 1
  }],
  fadeIn: [{
    opacity: '0',
    offset: 0
  }, {
    opacity: '1',
    offset: 1
  }],
  fadeOut: [{
    opacity: '1',
    offset: 0
  }, {
    opacity: '0',
    offset: 1
  }],
  fadeInDown: [{
    opacity: '0',
    transform: 'translate3d(0, -100%, 0)',
    offset: 0
  }, {
    opacity: '1',
    transform: 'none',
    offset: 1
  }],
  fadeOutDown: [{
    opacity: '1',
    transform: 'none',
    offset: 0
  }, {
    opacity: '0',
    transform: 'translate3d(0, 100%, 0)',
    offset: 1
  }],
  fadeOutUp: [{
    opacity: '1',
    transform: 'none',
    offset: 0
  }, {
    opacity: '0',
    transform: 'translate3d(0, -100%, 0)',
    offset: 1
  }],
  fadeOutUpBig: [{
    opacity: '1',
    transform: 'none',
    offset: 0
  }, {
    opacity: '0',
    transform: 'translate3d(0, -2000px, 0)',
    offset: 1
  }],
  fadeInUp: [{
    opacity: '0',
    transform: 'translate3d(0, 100%, 0)',
    offset: 0
  }, {
    opacity: '1',
    transform: 'none',
    offset: 1
  }],
  fadeInDownBig: [{
    opacity: '0',
    transform: 'translate3d(0, -2000px, 0)',
    offset: 0
  }, {
    opacity: '1',
    transform: 'none',
    offset: 1
  }],
  fadeOutDownBig: [{
    opacity: '1',
    transform: 'none',
    offset: 0
  }, {
    opacity: '0',
    transform: 'translate3d(0, 2000px, 0)',
    offset: 1
  }],
  fadeInUpBig: [{
    opacity: '0',
    transform: 'translate3d(0, 2000px, 0)',
    offset: 0
  }, {
    opacity: '1',
    transform: 'none',
    offset: 1
  }],
  fadeInRightBig: [{
    opacity: '0',
    transform: 'translate3d(2000px, 0, 0)',
    offset: 0
  }, {
    opacity: '1',
    transform: 'none',
    offset: 1
  }],
  fadeOutLeftBig: [{
    opacity: '1',
    transform: 'none',
    offset: 0
  }, {
    opacity: '0',
    transform: 'translate3d(-2000px, 0, 0)',
    offset: 1
  }],
  fadeInLeft: [{
    opacity: '0',
    transform: 'translate3d(-100%, 0, 0)',
    offset: 0
  }, {
    opacity: '1',
    transform: 'none',
    offset: 1
  }],
  fadeInLeftBig: [{
    opacity: '0',
    transform: 'translate3d(-2000px, 0, 0)',
    offset: 0
  }, {
    opacity: '1',
    transform: 'none',
    offset: 1
  }],
  fadeInRight: [{
    opacity: '0',
    transform: 'translate3d(100%, 0, 0)',
    offset: 0
  }, {
    opacity: '1',
    transform: 'none',
    offset: 1
  }],
  fadeOutLeft: [{
    opacity: '1',
    transform: 'none',
    offset: 0
  }, {
    opacity: '0',
    transform: 'translate3d(-100%, 0, 0)',
    offset: 1
  }],
  fadeOutRight: [{
    opacity: '1',
    transform: 'none',
    offset: 0
  }, {
    opacity: '0',
    transform: 'translate3d(100%, 0, 0)',
    offset: 1
  }],
  fadeOutRightBig: [{
    opacity: '1',
    transform: 'none',
    offset: 0
  }, {
    opacity: '0',
    transform: 'translate3d(2000px, 0, 0)',
    offset: 1
  }],
  rollIn: [{
    transform: 'translate3d(-100%, 0, 0) rotate3d(0, 0, 1, -120deg)',
    opacity: '0',
    offset: 0
  }, {
    transform: 'none',
    opacity: '1',
    offset: 1
  }],
  rollOut: [{
    transform: 'none',
    opacity: '1',
    offset: 0
  }, {
    transform: 'translate3d(100%, 0, 0) rotate3d(0, 0, 1, -120deg)',
    opacity: '0',
    offset: 1
  }],
  zoomIn: [{
    transform: 'scale3d(.3, .3, .3)  ',
    opacity: '0',
    offset: 0
  }, {
    transform: 'none',
    opacity: '1',
    offset: 1
  }],
  zoomOutDown: [{
    transform: 'none',
    opacity: '1',
    transformOrigin: 'center bottom',
    offset: 0
  }, {
    transform: 'scale3d(.475, .475, .475) translate3d(0, -60px, 0)',
    opacity: '1',
    transformOrigin: 'center bottom',
    offset: 0.4
  }, {
    transform: 'scale3d(.1, .1, .1) translate3d(0, 2000px, 0)',
    opacity: '0',
    transformOrigin: 'center bottom',
    offset: 1
  }],
  zoomOutUp: [{
    transform: 'none',
    opacity: '1',
    transformOrigin: 'center bottom',
    offset: 0
  }, {
    transform: 'scale3d(.475, .475, .475) translate3d(0, 60px, 0)',
    opacity: '1',
    transformOrigin: 'center bottom',
    offset: 0.4
  }, {
    transform: 'scale3d(.1, .1, .1) translate3d(0, -2000px, 0)',
    opacity: '0',
    transformOrigin: 'center bottom',
    offset: 1
  }],
  zoomOutRight: [{
    transform: 'none',
    opacity: '1',
    transformOrigin: 'right center',
    offset: 0
  }, {
    transform: 'scale3d(.475, .475, .475) translate3d(-42px, 0, 0)',
    opacity: '1',
    transformOrigin: 'right center',
    offset: 0.4
  }, {
    transform: 'scale(.1) translate3d(2000px, 0, 0)',
    opacity: '0',
    transformOrigin: 'right center',
    offset: 1
  }],
  zoomOutLeft: [{
    transform: 'none',
    opacity: '1',
    transformOrigin: 'left center',
    offset: 0
  }, {
    transform: 'scale3d(.475, .475, .475) translate3d(42px, 0, 0)',
    opacity: '1',
    transformOrigin: 'left center',
    offset: 0.4
  }, {
    transform: 'scale(.1) translate3d(-2000px, 0, 0)',
    opacity: '0',
    transformOrigin: 'left center',
    offset: 1
  }],
  zoomInDown: [{
    transform: 'scale3d(.1, .1, .1) translate3d(0, -1000px, 0)',
    opacity: '0',
    offset: 0
  }, {
    transform: 'scale3d(.475, .475, .475) translate3d(0, 60px, 0)',
    opacity: '1',
    offset: 0.6
  }, {
    transform: 'none',
    opacity: '1',
    offset: 1
  }],
  zoomInLeft: [{
    transform: 'scale3d(.1, .1, .1) translate3d(-1000px, 0, 0)',
    opacity: '0',
    offset: 0
  }, {
    transform: 'scale3d(.475, .475, .475) translate3d(10px, 0, 0)',
    opacity: '1',
    offset: 0.6
  }, {
    transform: 'none',
    opacity: '1',
    offset: 1
  }],
  zoomInRight: [{
    transform: 'scale3d(.1, .1, .1) translate3d(1000px, 0, 0)',
    opacity: '0',
    offset: 0
  }, {
    transform: 'scale3d(.475, .475, .475) translate3d(-10px, 0, 0)',
    opacity: '1',
    offset: 0.6
  }, {
    transform: 'none',
    opacity: '1',
    offset: 1
  }],
  zoomInUp: [{
    transform: 'scale3d(.1, .1, .1) translate3d(0, 1000px, 0)',
    opacity: '0',
    offset: 0
  }, {
    transform: 'scale3d(.475, .475, .475) translate3d(0, -60px, 0)',
    opacity: '1',
    offset: 0.6
  }, {
    transform: 'none',
    opacity: '1',
    offset: 1
  }],
  zoomOut: [{
    transform: 'none',
    opacity: '1',
    offset: 0
  }, {
    transform: 'scale3d(.3, .3, .3)  ',
    opacity: '0',
    offset: 1
  }],
  rotateIn: [{
    transform: 'rotate3d(0, 0, 1, -200deg)',
    opacity: '0',
    transformOrigin: 'center',
    offset: 0
  }, {
    transform: 'none',
    opacity: '1',
    transformOrigin: 'center',
    offset: 1
  }],
  rotateInDownLeft: [{
    transform: 'rotate3d(0, 0, 1, -45deg)',
    opacity: '0',
    transformOrigin: 'left bottom',
    offset: 0
  }, {
    transform: 'none',
    opacity: '1',
    transformOrigin: 'left bottom',
    offset: 1
  }],
  rotateInDownRight: [{
    transform: 'rotate3d(0, 0, 1, 45deg)',
    opacity: '0',
    transformOrigin: 'right bottom',
    offset: 0
  }, {
    transform: 'none',
    opacity: '1',
    transformOrigin: 'right bottom',
    offset: 1
  }],
  rotateInUpLeft: [{
    transform: 'rotate3d(0, 0, 1, 45deg)',
    opacity: '0',
    transformOrigin: 'left bottom',
    offset: 0
  }, {
    transform: 'none',
    opacity: '1',
    transformOrigin: 'left bottom',
    offset: 1
  }],
  rotateInUpRight: [{
    transform: 'rotate3d(0, 0, 1, -45deg)',
    opacity: '0',
    transformOrigin: 'right bottom',
    offset: 0
  }, {
    transform: 'none',
    opacity: '1',
    transformOrigin: 'right bottom',
    offset: 1
  }],
  rotateOutDownLeft: [{
    transform: 'none',
    opacity: '1',
    transformOrigin: 'left bottom',
    offset: 0
  }, {
    transform: 'rotate3d(0, 0, 1, 45deg)',
    opacity: '0',
    transformOrigin: 'left bottom',
    offset: 1
  }],
  rotateOutDownRight: [{
    transform: 'none',
    opacity: '1',
    transformOrigin: 'right bottom',
    offset: 0
  }, {
    transform: 'rotate3d(0, 0, 1, -45deg)',
    opacity: '0',
    transformOrigin: 'right bottom',
    offset: 1
  }],
  rotateOutUpLeft: [{
    transform: 'none',
    opacity: '1',
    transformOrigin: 'left bottom',
    offset: 0
  }, {
    transform: 'rotate3d(0, 0, 1, -45deg)',
    opacity: '0',
    transformOrigin: 'left bottom',
    offset: 1
  }],
  rotateOutUpRight: [{
    transform: 'none',
    opacity: '1',
    transformOrigin: 'right bottom',
    offset: 0
  }, {
    transform: 'rotate3d(0, 0, 1, 45deg)',
    opacity: '0',
    transformOrigin: 'right bottom',
    offset: 1
  }],
  rotateOut: [{
    transform: 'none',
    opacity: '1',
    transformOrigin: 'center',
    offset: 0
  }, {
    transform: 'rotate3d(0, 0, 1, 200deg)',
    opacity: '0',
    transformOrigin: 'center',
    offset: 1
  }]
};

exports['default'] = Keyframes;

Object.defineProperty(exports, '__esModule', { value: true });

})));

(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@pluginjs/pluginjs')) :
	typeof define === 'function' && define.amd ? define(['exports', '@pluginjs/pluginjs'], factory) :
	(factory((global['@pluginjs/match-sorter'] = {}),global['@pluginjs/pluginjs']));
}(this, (function (exports,Pj) { 'use strict';

Pj = Pj && Pj.hasOwnProperty('default') ? Pj['default'] : Pj;

function createCommonjsModule(fn, module) {
	return module = { exports: {} }, fn(module, module.exports), module.exports;
}

var diacritics = createCommonjsModule(function (module) {
// Diacritics.js
// 
// Started as something to be an equivalent of the Google Java Library diacritics library for JavaScript.
// Found this: http://jsperf.com/diacritics/6 and converted it into a reusable module.
// 
// @author Nijiko Yonskai
// @license MIT
// @copyright Nijikokun 2013 <nijikokun@gmail.com>
(function (name, definition) {
  if ('object' != 'undefined' && module.exports) module.exports = definition();
  else if (typeof undefined == 'function' && undefined.amd) undefined(definition);
  else this[name] = definition();
})('Diacritics', function () {
  // Create public object
  var output = {
    map: {}
  };

  // Create private reference map.
  var reference = [
    {'base':' ',    'letters':'\u00A0'},
    {'base':'A',    'letters':'\u0041\u24B6\uFF21\u00C0\u00C1\u00C2\u1EA6\u1EA4\u1EAA\u1EA8\u00C3\u0100\u0102\u1EB0\u1EAE\u1EB4\u1EB2\u0226\u01E0\u00C4\u01DE\u1EA2\u00C5\u01FA\u01CD\u0200\u0202\u1EA0\u1EAC\u1EB6\u1E00\u0104\u023A\u2C6F'},
    {'base':'AA',   'letters':'\uA732'},
    {'base':'AE',   'letters':'\u00C6\u01FC\u01E2'},
    {'base':'AO',   'letters':'\uA734'},
    {'base':'AU',   'letters':'\uA736'},
    {'base':'AV',   'letters':'\uA738\uA73A'},
    {'base':'AY',   'letters':'\uA73C'},
    {'base':'B',    'letters':'\u0042\u24B7\uFF22\u1E02\u1E04\u1E06\u0243\u0182\u0181'},
    {'base':'C',    'letters':'\u0043\u24B8\uFF23\u0106\u0108\u010A\u010C\u00C7\u1E08\u0187\u023B\uA73E'},
    {'base':'D',    'letters':'\u0044\u24B9\uFF24\u1E0A\u010E\u1E0C\u1E10\u1E12\u1E0E\u0110\u018B\u018A\u0189\uA779'},
    {'base':'DZ',   'letters':'\u01F1\u01C4'},
    {'base':'Dz',   'letters':'\u01F2\u01C5'},
    {'base':'E',    'letters':'\u0045\u24BA\uFF25\u00C8\u00C9\u00CA\u1EC0\u1EBE\u1EC4\u1EC2\u1EBC\u0112\u1E14\u1E16\u0114\u0116\u00CB\u1EBA\u011A\u0204\u0206\u1EB8\u1EC6\u0228\u1E1C\u0118\u1E18\u1E1A\u0190\u018E'},
    {'base':'F',    'letters':'\u0046\u24BB\uFF26\u1E1E\u0191\uA77B'},
    {'base':'G',    'letters':'\u0047\u24BC\uFF27\u01F4\u011C\u1E20\u011E\u0120\u01E6\u0122\u01E4\u0193\uA7A0\uA77D\uA77E'},
    {'base':'H',    'letters':'\u0048\u24BD\uFF28\u0124\u1E22\u1E26\u021E\u1E24\u1E28\u1E2A\u0126\u2C67\u2C75\uA78D'},
    {'base':'I',    'letters':'\u0049\u24BE\uFF29\u00CC\u00CD\u00CE\u0128\u012A\u012C\u0130\u00CF\u1E2E\u1EC8\u01CF\u0208\u020A\u1ECA\u012E\u1E2C\u0197'},
    {'base':'J',    'letters':'\u004A\u24BF\uFF2A\u0134\u0248'},
    {'base':'K',    'letters':'\u004B\u24C0\uFF2B\u1E30\u01E8\u1E32\u0136\u1E34\u0198\u2C69\uA740\uA742\uA744\uA7A2'},
    {'base':'L',    'letters':'\u004C\u24C1\uFF2C\u013F\u0139\u013D\u1E36\u1E38\u013B\u1E3C\u1E3A\u0141\u023D\u2C62\u2C60\uA748\uA746\uA780'},
    {'base':'LJ',   'letters':'\u01C7'},
    {'base':'Lj',   'letters':'\u01C8'},
    {'base':'M',    'letters':'\u004D\u24C2\uFF2D\u1E3E\u1E40\u1E42\u2C6E\u019C'},
    {'base':'N',    'letters':'\u004E\u24C3\uFF2E\u01F8\u0143\u00D1\u1E44\u0147\u1E46\u0145\u1E4A\u1E48\u0220\u019D\uA790\uA7A4'},
    {'base':'NJ',   'letters':'\u01CA'},
    {'base':'Nj',   'letters':'\u01CB'},
    {'base':'O',    'letters':'\u004F\u24C4\uFF2F\u00D2\u00D3\u00D4\u1ED2\u1ED0\u1ED6\u1ED4\u00D5\u1E4C\u022C\u1E4E\u014C\u1E50\u1E52\u014E\u022E\u0230\u00D6\u022A\u1ECE\u0150\u01D1\u020C\u020E\u01A0\u1EDC\u1EDA\u1EE0\u1EDE\u1EE2\u1ECC\u1ED8\u01EA\u01EC\u00D8\u01FE\u0186\u019F\uA74A\uA74C'},
    {'base':'OI',   'letters':'\u01A2'},
    {'base':'OO',   'letters':'\uA74E'},
    {'base':'OU',   'letters':'\u0222'},
    {'base':'P',    'letters':'\u0050\u24C5\uFF30\u1E54\u1E56\u01A4\u2C63\uA750\uA752\uA754'},
    {'base':'Q',    'letters':'\u0051\u24C6\uFF31\uA756\uA758\u024A'},
    {'base':'R',    'letters':'\u0052\u24C7\uFF32\u0154\u1E58\u0158\u0210\u0212\u1E5A\u1E5C\u0156\u1E5E\u024C\u2C64\uA75A\uA7A6\uA782'},
    {'base':'S',    'letters':'\u0053\u24C8\uFF33\u1E9E\u015A\u1E64\u015C\u1E60\u0160\u1E66\u1E62\u1E68\u0218\u015E\u2C7E\uA7A8\uA784'},
    {'base':'T',    'letters':'\u0054\u24C9\uFF34\u1E6A\u0164\u1E6C\u021A\u0162\u1E70\u1E6E\u0166\u01AC\u01AE\u023E\uA786'},
    {'base':'Th',   'letters':'\u00DE'},
    {'base':'TZ',   'letters':'\uA728'},
    {'base':'U',    'letters':'\u0055\u24CA\uFF35\u00D9\u00DA\u00DB\u0168\u1E78\u016A\u1E7A\u016C\u00DC\u01DB\u01D7\u01D5\u01D9\u1EE6\u016E\u0170\u01D3\u0214\u0216\u01AF\u1EEA\u1EE8\u1EEE\u1EEC\u1EF0\u1EE4\u1E72\u0172\u1E76\u1E74\u0244'},
    {'base':'V',    'letters':'\u0056\u24CB\uFF36\u1E7C\u1E7E\u01B2\uA75E\u0245'},
    {'base':'VY',   'letters':'\uA760'},
    {'base':'W',    'letters':'\u0057\u24CC\uFF37\u1E80\u1E82\u0174\u1E86\u1E84\u1E88\u2C72'},
    {'base':'X',    'letters':'\u0058\u24CD\uFF38\u1E8A\u1E8C'},
    {'base':'Y',    'letters':'\u0059\u24CE\uFF39\u1EF2\u00DD\u0176\u1EF8\u0232\u1E8E\u0178\u1EF6\u1EF4\u01B3\u024E\u1EFE'},
    {'base':'Z',    'letters':'\u005A\u24CF\uFF3A\u0179\u1E90\u017B\u017D\u1E92\u1E94\u01B5\u0224\u2C7F\u2C6B\uA762'},
    {'base':'a',    'letters':'\u0061\u24D0\uFF41\u1E9A\u00E0\u00E1\u00E2\u1EA7\u1EA5\u1EAB\u1EA9\u00E3\u0101\u0103\u1EB1\u1EAF\u1EB5\u1EB3\u0227\u01E1\u00E4\u01DF\u1EA3\u00E5\u01FB\u01CE\u0201\u0203\u1EA1\u1EAD\u1EB7\u1E01\u0105\u2C65\u0250\u0251'},
    {'base':'aa',   'letters':'\uA733'},
    {'base':'ae',   'letters':'\u00E6\u01FD\u01E3'},
    {'base':'ao',   'letters':'\uA735'},
    {'base':'au',   'letters':'\uA737'},
    {'base':'av',   'letters':'\uA739\uA73B'},
    {'base':'ay',   'letters':'\uA73D'},
    {'base':'b',    'letters':'\u0062\u24D1\uFF42\u1E03\u1E05\u1E07\u0180\u0183\u0253'},
    {'base':'c',    'letters':'\u0063\u24D2\uFF43\u0107\u0109\u010B\u010D\u00E7\u1E09\u0188\u023C\uA73F\u2184'},
    {'base':'d',    'letters':'\u0064\u24D3\uFF44\u1E0B\u010F\u1E0D\u1E11\u1E13\u1E0F\u0111\u018C\u0256\u0257\uA77A'},
    {'base':'dz',   'letters':'\u01F3\u01C6'},
    {'base':'e',    'letters':'\u0065\u24D4\uFF45\u00E8\u00E9\u00EA\u1EC1\u1EBF\u1EC5\u1EC3\u1EBD\u0113\u1E15\u1E17\u0115\u0117\u00EB\u1EBB\u011B\u0205\u0207\u1EB9\u1EC7\u0229\u1E1D\u0119\u1E19\u1E1B\u0247\u025B\u01DD'},
    {'base':'f',    'letters':'\u0066\u24D5\uFF46\u1E1F\u0192\uA77C'},
    {'base':'ff',   'letters':'\uFB00'},
    {'base':'fi',   'letters':'\uFB01'},
    {'base':'fl',   'letters':'\uFB02'},
    {'base':'ffi',  'letters':'\uFB03'},
    {'base':'ffl',  'letters':'\uFB04'},
    {'base':'g',    'letters':'\u0067\u24D6\uFF47\u01F5\u011D\u1E21\u011F\u0121\u01E7\u0123\u01E5\u0260\uA7A1\u1D79\uA77F'},
    {'base':'h',    'letters':'\u0068\u24D7\uFF48\u0125\u1E23\u1E27\u021F\u1E25\u1E29\u1E2B\u1E96\u0127\u2C68\u2C76\u0265'},
    {'base':'hv',   'letters':'\u0195'},
    {'base':'i',    'letters':'\u0069\u24D8\uFF49\u00EC\u00ED\u00EE\u0129\u012B\u012D\u00EF\u1E2F\u1EC9\u01D0\u0209\u020B\u1ECB\u012F\u1E2D\u0268\u0131'},
    {'base':'j',    'letters':'\u006A\u24D9\uFF4A\u0135\u01F0\u0249'},
    {'base':'k',    'letters':'\u006B\u24DA\uFF4B\u1E31\u01E9\u1E33\u0137\u1E35\u0199\u2C6A\uA741\uA743\uA745\uA7A3'},
    {'base':'l',    'letters':'\u006C\u24DB\uFF4C\u0140\u013A\u013E\u1E37\u1E39\u013C\u1E3D\u1E3B\u017F\u0142\u019A\u026B\u2C61\uA749\uA781\uA747'},
    {'base':'lj',   'letters':'\u01C9'},
    {'base':'m',    'letters':'\u006D\u24DC\uFF4D\u1E3F\u1E41\u1E43\u0271\u026F'},
    {'base':'n',    'letters':'\x6E\xF1\u006E\u24DD\uFF4E\u01F9\u0144\u00F1\u1E45\u0148\u1E47\u0146\u1E4B\u1E49\u019E\u0272\u0149\uA791\uA7A5\u043B\u0509'},
    {'base':'nj',   'letters':'\u01CC'},
    {'base':'o',    'letters':'\u07C0\u006F\u24DE\uFF4F\u00F2\u00F3\u00F4\u1ED3\u1ED1\u1ED7\u1ED5\u00F5\u1E4D\u022D\u1E4F\u014D\u1E51\u1E53\u014F\u022F\u0231\u00F6\u022B\u1ECF\u0151\u01D2\u020D\u020F\u01A1\u1EDD\u1EDB\u1EE1\u1EDF\u1EE3\u1ECD\u1ED9\u01EB\u01ED\u00F8\u01FF\u0254\uA74B\uA74D\u0275'},
    {'base':'oe',   'letters':'\u0152\u0153'},
    {'base':'oi',   'letters':'\u01A3'},
    {'base':'ou',   'letters':'\u0223'},
    {'base':'oo',   'letters':'\uA74F'},
    {'base':'p',    'letters':'\u0070\u24DF\uFF50\u1E55\u1E57\u01A5\u1D7D\uA751\uA753\uA755'},
    {'base':'q',    'letters':'\u0071\u24E0\uFF51\u024B\uA757\uA759'},
    {'base':'r',    'letters':'\u0072\u24E1\uFF52\u0155\u1E59\u0159\u0211\u0213\u1E5B\u1E5D\u0157\u1E5F\u024D\u027D\uA75B\uA7A7\uA783'},
    {'base':'s',    'letters':'\u0073\u24E2\uFF53\u00DF\u015B\u1E65\u015D\u1E61\u0161\u1E67\u1E63\u1E69\u0219\u015F\u023F\uA7A9\uA785\u1E9B'},
    {'base':'ss',   'letters':'\xDF'},
    {'base':'t',    'letters':'\u0074\u24E3\uFF54\u1E6B\u1E97\u0165\u1E6D\u021B\u0163\u1E71\u1E6F\u0167\u01AD\u0288\u2C66\uA787'},
    {'base':'th',   'letters':'\u00FE'},
    {'base':'tz',   'letters':'\uA729'},
    {'base':'u',    'letters': '\u0075\u24E4\uFF55\u00F9\u00FA\u00FB\u0169\u1E79\u016B\u1E7B\u016D\u00FC\u01DC\u01D8\u01D6\u01DA\u1EE7\u016F\u0171\u01D4\u0215\u0217\u01B0\u1EEB\u1EE9\u1EEF\u1EED\u1EF1\u1EE5\u1E73\u0173\u1E77\u1E75\u0289'},
    {'base':'v',    'letters':'\u0076\u24E5\uFF56\u1E7D\u1E7F\u028B\uA75F\u028C'},
    {'base':'vy',   'letters':'\uA761'},
    {'base':'w',    'letters':'\u0077\u24E6\uFF57\u1E81\u1E83\u0175\u1E87\u1E85\u1E98\u1E89\u2C73'},
    {'base':'x',    'letters':'\u0078\u24E7\uFF58\u1E8B\u1E8D'},
    {'base':'y',    'letters':'\u0079\u24E8\uFF59\u1EF3\u00FD\u0177\u1EF9\u0233\u1E8F\u00FF\u1EF7\u1E99\u1EF5\u01B4\u024F\u1EFF'},
    {'base':'z',    'letters':'\u007A\u24E9\uFF5A\u017A\u1E91\u017C\u017E\u1E93\u1E95\u01B6\u0225\u0240\u2C6C\uA763'}
  ];

  // Generate reference mapping
  for (var i = 0, refLength = reference.length; i < refLength; i++){
    var letters = reference[i].letters.split("");

    for (var j = 0, letLength = letters.length; j < letLength; j++){
      output.map[letters[j]] = reference[i].base;
    }
  }

  /**
   * Clean accents (diacritics) from string.
   * 
   * @param  {String} input String to be cleaned of diacritics.
   * @return {String}
   */
  output.clean = function (input) {
    if (!input || !input.length || input.length < 1) {
      return "";
    }

    var string = "";
    var letters = input.split("");
    var index = 0;
    var length = letters.length;
    var letter;

    for (; index < length; index++) {
      letter = letters[index];
      string += letter in output.map ? output.map[letter] : letter;
    }

    return string;
  };

  return output;
});
});

/* eslint object-property-newline: "off" */
/* eslint no-else-return: "off" */

/* Credit to https://github.com/kentcdodds/match-sorter MIT */
var matchSorter = function () {
  var rankings = {
    CASE_SENSITIVE_EQUAL: 7,
    EQUAL: 6,
    STARTS_WITH: 5,
    WORD_STARTS_WITH: 4,
    CONTAINS: 3,
    ACRONYM: 2,
    MATCHES: 1,
    NO_MATCH: 0

    /**
     * Takes an array of items and a value and returns a new array with the items that match the given value
     * @param {Array} items - the items to sort
     * @param {String} value - the value to use for ranking
     * @param {Object} options - Some options to configure the sorter
     * @return {Array} - the new sorted array
     */
  };function matchSorter(items, value) {
    var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    var keys = options.keys,
        _options$threshold = options.threshold,
        threshold = _options$threshold === undefined ? rankings.MATCHES : _options$threshold;

    var matchedItems = items.reduce(reduceItemsToRanked, []);
    return matchedItems.sort(sortRankedItems).map(function (_ref) {
      var item = _ref.item;
      return item;
    });

    function reduceItemsToRanked(matches, item, index) {
      var _getHighestRanking = getHighestRanking(item, keys, value, options),
          rank = _getHighestRanking.rank,
          keyIndex = _getHighestRanking.keyIndex;

      if (rank >= threshold) {
        matches.push({
          item: item,
          rank: rank,
          index: index,
          keyIndex: keyIndex
        });
      }
      return matches;
    }
  }

  /**
   * Gets the highest ranking for value for the given item based on its values for the given keys
   * @param {*} item - the item to rank
   * @param {Array} keys - the keys to get values from the item for the ranking
   * @param {String} value - the value to rank against
   * @param {Object} options - options to control the ranking
   * @return {Number} - the highest ranking
   */
  function getHighestRanking(item, keys, value, options) {
    if (!keys) {
      return {
        rank: getMatchRanking(item, value, options),
        keyIndex: -1
      };
    }
    var valuesToRank = getAllValuesToRank(item, keys);
    return valuesToRank.reduce(function (_ref2, itemValue, i) {
      var rank = _ref2.rank,
          keyIndex = _ref2.keyIndex;

      var newRank = getMatchRanking(itemValue, value, options);
      if (newRank > rank) {
        rank = newRank;
        keyIndex = i;
      }
      return {
        rank: rank,
        keyIndex: keyIndex
      };
    }, {
      rank: rankings.NO_MATCH,
      keyIndex: -1
    });
  }

  /**
   * Gives a rankings score based on how well the two strings match.
   * @param {String} testString - the string to test against
   * @param {String} stringToRank - the string to rank
   * @param {Object} options - options for the match (like keepDiacritics for comparison)
   * @returns {Number} the ranking for how well stringToRank matches testString
   */
  function getMatchRanking(testString, stringToRank, options) {
    /* eslint complexity:[2, 9] */
    testString = prepareValueForComparison(testString, options);
    stringToRank = prepareValueForComparison(stringToRank, options);

    // too long
    if (stringToRank.length > testString.length) {
      return rankings.NO_MATCH;
    }

    // case sensitive equals
    if (testString === stringToRank) {
      return rankings.CASE_SENSITIVE_EQUAL;
    }

    // Lowercasing before further comparison
    testString = testString.toLowerCase();
    stringToRank = stringToRank.toLowerCase();

    // case insensitive equals
    if (testString === stringToRank) {
      return rankings.EQUAL;
    }

    // starts with
    if (testString.indexOf(stringToRank) === 0) {
      return rankings.STARTS_WITH;
    }

    // word starts with
    if (testString.indexOf(' ' + stringToRank) !== -1) {
      return rankings.WORD_STARTS_WITH;
    }

    // contains
    if (testString.indexOf(stringToRank) !== -1) {
      return rankings.CONTAINS;
    } else if (stringToRank.length === 1) {
      // If the only character in the given stringToRank
      //   isn't even contained in the testString, then
      //   it's definitely not a match.
      return rankings.NO_MATCH;
    }

    // acronym
    if (getAcronym(testString).indexOf(stringToRank) !== -1) {
      return rankings.ACRONYM;
    }

    return stringsByCharOrder(testString, stringToRank);
  }

  /**
   * Generates an acronym for a string.
   *
   * @param {String} string the string for which to produce the acronym
   * @returns {String} the acronym
   */
  function getAcronym(string) {
    var acronym = '';
    var wordsInString = string.split(' ');
    wordsInString.forEach(function (wordInString) {
      var splitByHyphenWords = wordInString.split('-');
      splitByHyphenWords.forEach(function (splitByHyphenWord) {
        acronym += splitByHyphenWord.substr(0, 1);
      });
    });
    return acronym;
  }

  /**
   * Returns a rankings.matches or noMatch score based on whether
   * the characters in the stringToRank are found in order in the
   * testString
   * @param {String} testString - the string to test against
   * @param {String} stringToRank - the string to rank
   * @returns {Number} the ranking for how well stringToRank matches testString
   */
  function stringsByCharOrder(testString, stringToRank) {
    var charNumber = 0;

    function findMatchingCharacter(matchChar, string) {
      var found = false;
      for (var j = charNumber; j < string.length; j++) {
        var stringChar = string[j];
        if (stringChar === matchChar) {
          found = true;
          charNumber = j + 1;
          break;
        }
      }
      return found;
    }

    for (var i = 0; i < stringToRank.length; i++) {
      var matchChar = stringToRank[i];
      var found = findMatchingCharacter(matchChar, testString);
      if (!found) {
        return rankings.NO_MATCH;
      }
    }
    return rankings.MATCHES;
  }

  /**
   * Sorts items that have a rank, index, and keyIndex
   * @param {Object} a - the first item to sort
   * @param {Object} b - the second item to sort
   * @return {Number} -1 if a should come first, 1 if b should come first
   * Note: will never return 0
   */
  function sortRankedItems(a, b) {
    var aFirst = -1;
    var bFirst = 1;
    var aRank = a.rank,
        aIndex = a.index,
        aKeyIndex = a.keyIndex;
    var bRank = b.rank,
        bIndex = b.index,
        bKeyIndex = b.keyIndex;

    var same = aRank === bRank;
    if (same) {
      if (aKeyIndex === bKeyIndex) {
        return aIndex < bIndex ? aFirst : bFirst;
      } else {
        return aKeyIndex < bKeyIndex ? aFirst : bFirst;
      }
    } else {
      return aRank > bRank ? aFirst : bFirst;
    }
  }

  /**
   * Prepares value for comparison by stringifying it, removing diacritics (if specified)
   * @param {String} value - the value to clean
   * @param {Object} options - {keepDiacritics: whether to remove diacritics}
   * @return {String} the prepared value
   */
  function prepareValueForComparison(value, _ref3) {
    var keepDiacritics = _ref3.keepDiacritics;

    value = '' + value; // toString
    if (!keepDiacritics) {
      value = diacritics.clean(value);
    }
    return value;
  }

  /**
   * Gets value for key in item at arbitrarily nested keypath
   * @param {Object} item - the item
   * @param {Object|Function} key - the potentially nested keypath or property callback
   * @return {String} - the value at nested keypath
   */
  function getItemValue(item, key) {
    if (typeof key === 'function') {
      return key(item);
    }
    var isNested = key.indexOf('.') !== -1;
    if (!isNested) {
      return item[key];
    }
    return key.split('.').reduce(function (itemObj, nestedKey) {
      return itemObj[nestedKey];
    }, item);
  }

  /**
   * Gets all the values for the given keys in the given item and returns an array of those values
   * @param {Object} item - the item from which the values will be retrieved
   * @param {Array} keys - the keys to use to retrieve the values
   * @return {Array} the values in an array
   */
  function getAllValuesToRank(item, keys) {
    return keys.reduce(function (allVals, key) {
      return allVals.concat(getItemValue(item, key));
    }, []);
  }

  matchSorter.rankings = rankings;

  return matchSorter;
}();

Pj.matchSorter = matchSorter;

exports['default'] = matchSorter;

Object.defineProperty(exports, '__esModule', { value: true });

})));

(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@pluginjs/utils')) :
	typeof define === 'function' && define.amd ? define(['exports', '@pluginjs/utils'], factory) :
	(factory((global['@pluginjs/viewport'] = {}),global['@pluginjs/utils']));
}(this, (function (exports,utils) { 'use strict';

var asyncGenerator = function () {
  function AwaitValue(value) {
    this.value = value;
  }

  function AsyncGenerator(gen) {
    var front, back;

    function send(key, arg) {
      return new Promise(function (resolve, reject) {
        var request = {
          key: key,
          arg: arg,
          resolve: resolve,
          reject: reject,
          next: null
        };

        if (back) {
          back = back.next = request;
        } else {
          front = back = request;
          resume(key, arg);
        }
      });
    }

    function resume(key, arg) {
      try {
        var result = gen[key](arg);
        var value = result.value;

        if (value instanceof AwaitValue) {
          Promise.resolve(value.value).then(function (arg) {
            resume("next", arg);
          }, function (arg) {
            resume("throw", arg);
          });
        } else {
          settle(result.done ? "return" : "normal", result.value);
        }
      } catch (err) {
        settle("throw", err);
      }
    }

    function settle(type, value) {
      switch (type) {
        case "return":
          front.resolve({
            value: value,
            done: true
          });
          break;

        case "throw":
          front.reject(value);
          break;

        default:
          front.resolve({
            value: value,
            done: false
          });
          break;
      }

      front = front.next;

      if (front) {
        resume(front.key, front.arg);
      } else {
        back = null;
      }
    }

    this._invoke = send;

    if (typeof gen.return !== "function") {
      this.return = undefined;
    }
  }

  if (typeof Symbol === "function" && Symbol.asyncIterator) {
    AsyncGenerator.prototype[Symbol.asyncIterator] = function () {
      return this;
    };
  }

  AsyncGenerator.prototype.next = function (arg) {
    return this._invoke("next", arg);
  };

  AsyncGenerator.prototype.throw = function (arg) {
    return this._invoke("throw", arg);
  };

  AsyncGenerator.prototype.return = function (arg) {
    return this._invoke("return", arg);
  };

  return {
    wrap: function (fn) {
      return function () {
        return new AsyncGenerator(fn.apply(this, arguments));
      };
    },
    await: function (value) {
      return new AwaitValue(value);
    }
  };
}();





var classCallCheck = function (instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
};

var createClass = function () {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  return function (Constructor, protoProps, staticProps) {
    if (protoProps) defineProperties(Constructor.prototype, protoProps);
    if (staticProps) defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();

var Viewport = function () {
  function Viewport(el, options) {
    var _this = this;

    classCallCheck(this, Viewport);
    this.isIntersecting = false;
    this.enterMiddleware = [];
    this.exitMiddleware = [];
    this.instance = null;

    this.element = el;
    this.options = options;
    this.observer = new IntersectionObserver(function (event) {
      if (event[0].isIntersecting) {
        _this.isIntersecting = true;
        return _this.enterMiddleware.map(function (fn) {
          return fn();
        });
      }
      _this.isIntersecting = false;
      return _this.exitMiddleware.map(function (fn) {
        return fn();
      });
    });
    this.observer.observe(this.element);
  }

  createClass(Viewport, [{
    key: 'on',
    value: function on(eventName, func, instance) {
      this.instance = instance;
      var adder = utils.curry(function (func, middleware) {
        return middleware.concat(func);
      });
      this.eventMapper(eventName, adder(func.bind(this.instance)));
    }
  }, {
    key: 'off',
    value: function off(eventName, func) {
      var filter = utils.curry(function (func, middleware) {
        return middleware.filter(function (fn) {
          return fn === func;
        });
      });
      this.eventMapper(eventName, filter(func.bind(this.instance)));
    }
  }, {
    key: 'eventMapper',
    value: function eventMapper(eventName, func) {
      if (eventName === 'enter') {
        this.enterMiddleware = func(this.enterMiddleware);
      }

      if (eventName === 'exit') {
        this.exitMiddleware = func(this.exitMiddleware);
      }
    }
  }, {
    key: 'isVisible',
    value: function isVisible() {
      return this.isIntersecting;
    }
  }, {
    key: 'destroy',
    value: function destroy() {
      this.observer.disconnect();
      this.enterMiddleware = [];
      this.isIntersecting = false;
      this.enterMiddleware = [];
      this.exitMiddleware = [];
      this.instance = null;
    }
  }], [{
    key: 'of',
    value: function of() {
      for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      return new (Function.prototype.bind.apply(Viewport, [null].concat(args)))();
    }
  }]);
  return Viewport;
}();

var viewport = function viewport() {
  return Viewport.of.apply(Viewport, arguments);
};

exports['default'] = viewport;

Object.defineProperty(exports, '__esModule', { value: true });

})));
