import { parseHTML } from '@pluginjs/dom'

export default () => parseHTML`<div><div>`
